var __getOwnPropNames = Object.getOwnPropertyNames;
var __esm = (fn, res) => function __init() {
  return fn && (res = (0, fn[__getOwnPropNames(fn)[0]])(fn = 0)), res;
};

// src/shared/types.ts
function providerFromUrl(url) {
  try {
    const u = new URL(url ?? "");
    if (u.protocol !== "https:") return null;
    if (u.hostname === "claude.ai") return "claude";
    if (u.hostname === "gemini.google.com") return "gemini";
    if (u.hostname === "chatgpt.com") return /^\/(codex|work)(?:\/|$)/.test(u.pathname) ? "codex" : "chatgpt";
    return null;
  } catch {
    return null;
  }
}
var PROVIDERS, PAGE_PROVIDERS, ORIGINS, NAMES, HOME_URLS, isProvider, SITE_GROUPS;
var init_types = __esm({
  "src/shared/types.ts"() {
    "use strict";
    PROVIDERS = ["chatgpt", "claude", "gemini"];
    PAGE_PROVIDERS = ["chatgpt", "codex", "claude", "gemini"];
    ORIGINS = { chatgpt: "https://chatgpt.com/*", claude: "https://claude.ai/*", gemini: "https://gemini.google.com/*" };
    NAMES = { chatgpt: "ChatGPT", claude: "Claude", gemini: "Gemini" };
    HOME_URLS = { chatgpt: "https://chatgpt.com/", claude: "https://claude.ai/", gemini: "https://gemini.google.com/" };
    isProvider = (v) => PROVIDERS.includes(v);
    SITE_GROUPS = [
      { id: "openai", origin: ORIGINS.chatgpt, providers: ["chatgpt", "codex"] },
      { id: "claude", origin: ORIGINS.claude, providers: ["claude"] },
      { id: "gemini", origin: ORIGINS.gemini, providers: ["gemini"] }
    ];
  }
});

// src/popup/index.ts
init_types();

// src/shared/contracts.ts
init_types();

// src/shared/validation.ts
function record(v) {
  return v !== null && typeof v === "object" && !Array.isArray(v) ? v : null;
}
var finite = (v) => typeof v === "number" && Number.isFinite(v);
var percent = (v) => finite(v) && v >= 0 && v <= 100 ? v : null;
var nonnegative = (v) => finite(v) && v >= 0 ? v : null;
function label(v) {
  return typeof v === "string" && v.trim().length > 0 && v.length <= 120 && !/[\u0000-\u001f\u007f]/.test(v) ? v.trim() : null;
}
function resetTime(v) {
  if (typeof v !== "string") return null;
  const parts = /^(\d{4})-(\d{2})-(\d{2})T(\d{2}):(\d{2}):(\d{2})(?:\.\d+)?(?:Z|[+-]\d{2}:\d{2})$/.exec(v);
  if (!parts) return null;
  const [year, month, day, hour, minute, second] = parts.slice(1, 7).map(Number);
  if (month < 1 || month > 12 || day < 1 || day > new Date(Date.UTC(year, month, 0)).getUTCDate() || hour > 23 || minute > 59 || second > 59) return null;
  const ms = Date.parse(v);
  return Number.isFinite(ms) && ms > 0 && ms < 41024448e5 ? new Date(ms).toISOString() : null;
}

// src/storage/settings.ts
init_types();
function isSettings(value) {
  const r = record(value);
  if (!r || !isProvider(r.defaultProvider) || typeof r.followTab !== "boolean") return false;
  if (!finite(r.warning) || !finite(r.danger) || r.warning < 0 || r.warning >= r.danger || r.danger > 100) return false;
  return PROVIDERS.every((p) => typeof record(r.enabled)?.[p] === "boolean" && (record(r.selectedLimit)?.[p] === null || typeof record(r.selectedLimit)?.[p] === "string" && String(record(r.selectedLimit)?.[p]).length <= 200)) && PAGE_PROVIDERS.every((p) => typeof record(r.strips)?.[p] === "boolean");
}

// src/storage/snapshots.ts
init_types();

// src/shared/errors.ts
var INVALID_RESPONSE_TEXT = "\uC0AC\uC6A9\uB7C9 \uC751\uB2F5 \uD615\uC2DD\uC744 \uD655\uC778\uD560 \uC218 \uC5C6\uC2B5\uB2C8\uB2E4.";
var ERROR_TEXT = {
  not_collected: "\uC544\uC9C1 \uC218\uC9D1\uD558\uC9C0 \uC54A\uC558\uC2B5\uB2C8\uB2E4.",
  signed_out: "\uC0AC\uC774\uD2B8\uC5D0 \uB85C\uADF8\uC778\uD55C \uB4A4 \uC218\uB3D9 \uAC31\uC2E0\uD574 \uC8FC\uC138\uC694.",
  access_denied: "\uC0AC\uC774\uD2B8\uAC00 \uC811\uADFC\uC744 \uAC70\uBD80\uD588\uC2B5\uB2C8\uB2E4. \uBCF4\uD638\uC7A5\uCE58\uB97C \uC6B0\uD68C\uD558\uC9C0 \uC54A\uC2B5\uB2C8\uB2E4.",
  rate_limited: "\uC694\uCCAD \uD55C\uB3C4\uC5D0 \uB3C4\uB2EC\uD588\uC2B5\uB2C8\uB2E4. \uC7AC\uC2DC\uB3C4 \uC2DC\uAC01\uAE4C\uC9C0 \uAE30\uB2E4\uB824 \uC8FC\uC138\uC694.",
  network: "\uC5F0\uACB0 \uB610\uB294 \uC694\uCCAD \uC2DC\uAC04\uC774 \uCD08\uACFC\uB418\uC5C8\uC2B5\uB2C8\uB2E4.",
  invalid_response: INVALID_RESPONSE_TEXT,
  gemini_response_type: INVALID_RESPONSE_TEXT,
  gemini_response_read: INVALID_RESPONSE_TEXT,
  gemini_frame_invalid: INVALID_RESPONSE_TEXT,
  gemini_rpc_missing: INVALID_RESPONSE_TEXT,
  gemini_rpc_invalid: INVALID_RESPONSE_TEXT,
  gemini_quota_invalid: INVALID_RESPONSE_TEXT,
  open_tab: "\uB85C\uADF8\uC778\uD55C \uC11C\uBE44\uC2A4 \uD0ED\uC744 \uC5F4\uACE0 \uAC31\uC2E0\uD574 \uC8FC\uC138\uC694.",
  ambiguous_account: "\uC5EC\uB7EC Claude \uC870\uC9C1\uC774 \uD655\uC778\uB418\uC5B4 \uC120\uD0DD\uD560 \uC218 \uC5C6\uC2B5\uB2C8\uB2E4. \uACC4\uC815\uC758 \uC0AC\uC6A9\uB7C9 \uD654\uBA74\uC744 \uD655\uC778\uD574 \uC8FC\uC138\uC694.",
  tab_access_failed: "\uC5F4\uB9B0 \uC11C\uBE44\uC2A4 \uD0ED\uC5D0\uC11C \uC218\uC9D1 \uCF54\uB4DC\uB97C \uC2E4\uD589\uD558\uC9C0 \uBABB\uD588\uC2B5\uB2C8\uB2E4. Chrome \uD655\uC7A5 \uD504\uB85C\uADF8\uB7A8\uC758 \uD574\uB2F9 \uC0AC\uC774\uD2B8 \uC811\uADFC \uC124\uC815\uC744 \uD655\uC778\uD55C \uB4A4 \uD655\uC7A5\uACFC \uD0ED\uC744 \uC0C8\uB85C\uACE0\uCE68\uD574 \uC8FC\uC138\uC694.",
  unsupported: "\uC548\uC804\uD55C \uC218\uC9D1 \uACC4\uC57D\uC744 \uAC80\uC99D\uD558\uC9C0 \uBABB\uD574 \uBBF8\uC9C0\uC6D0\uC785\uB2C8\uB2E4.",
  permission_required: "\uC774 \uC11C\uBE44\uC2A4\uC758 \uC0AC\uC774\uD2B8 \uC811\uADFC \uAD8C\uD55C\uC774 \uD544\uC694\uD569\uB2C8\uB2E4.",
  server: "\uC11C\uBE44\uC2A4 \uC624\uB958\uC785\uB2C8\uB2E4. \uC7A0\uC2DC \uD6C4 \uB2E4\uC2DC \uC2DC\uB3C4\uD569\uB2C8\uB2E4.",
  reset_pending: "\uCD08\uAE30\uD654 \uD6C4 \uD655\uC778 \uC911"
};

// src/storage/snapshots.ts
var FRESH_MS = 10 * 6e4;
function emptySnapshot(provider) {
  return { provider, state: "error", limits: [], collectedAt: null, checkedAt: null, nextAttemptAt: 0, failures: 0, errorCode: "not_collected" };
}
function validLimits(input) {
  return Array.isArray(input) && input.length <= 150 && input.every((x) => {
    const r = record(x);
    return r && typeof r.id === "string" && r.id.length > 0 && r.id.length <= 200 && label(r.label) && ["window", "model", "product"].includes(String(r.category)) && r.source === "api" && (r.percent === null || percent(r.percent) !== null) && (r.resetsAt === null || resetTime(r.resetsAt) !== null) && (r.windowSeconds === null || nonnegative(r.windowSeconds) !== null) && (r.remaining === null || nonnegative(r.remaining) !== null) && (r.unit === null || label(r.unit));
  }) && new Set(input.map((x) => x.id)).size === input.length;
}
function parseSnapshot(input, provider) {
  const r = record(input);
  if (!r || r.provider !== provider || !["ok", "stale", "signed_out", "permission_required", "rate_limited", "unsupported", "error"].includes(String(r.state)) || !validLimits(r.limits) || !(r.collectedAt === null || finite(r.collectedAt)) || !(r.checkedAt === null || finite(r.checkedAt)) || !finite(r.nextAttemptAt) || !finite(r.failures) || !(r.errorCode === null || typeof r.errorCode === "string" && Object.hasOwn(ERROR_TEXT, r.errorCode))) return emptySnapshot(provider);
  if (r.state === "ok" && (r.collectedAt === null || r.limits.length === 0)) return emptySnapshot(provider);
  const limits = r.limits.map((limit) => ({
    id: limit.id,
    label: label(limit.label),
    category: limit.category,
    percent: limit.percent,
    resetsAt: limit.resetsAt === null ? null : resetTime(limit.resetsAt),
    windowSeconds: limit.windowSeconds,
    remaining: limit.remaining,
    unit: limit.unit === null ? null : label(limit.unit),
    source: "api"
  }));
  return { provider, state: r.state, limits, collectedAt: r.collectedAt, checkedAt: r.checkedAt, nextAttemptAt: Math.max(0, r.nextAttemptAt), failures: Math.max(0, r.failures), errorCode: r.errorCode };
}
function hasElapsedReset(snapshot, now = Date.now()) {
  return snapshot.limits.some((limit) => {
    const reset = resetTime(limit.resetsAt);
    return reset !== null && Date.parse(reset) <= now;
  });
}
function effectiveSnapshot(snapshot, now = Date.now()) {
  const firstTransient = snapshot.failures === 1 && (snapshot.errorCode === "network" || snapshot.errorCode === "server");
  const legacyAgeOnly = snapshot.state === "stale" && snapshot.errorCode === null && snapshot.failures === 0;
  const current = snapshot.state === "ok";
  if (!current && !legacyAgeOnly && !(snapshot.state === "error" && firstTransient)) return snapshot;
  if (current && snapshot.errorCode !== null && !firstTransient) return { ...snapshot, state: "error" };
  const usable = finite(now) && finite(snapshot.collectedAt) && snapshot.collectedAt > 0 && snapshot.collectedAt <= now + 6e4 && snapshot.limits.length > 0 && validLimits(snapshot.limits);
  if (!usable) return current || legacyAgeOnly ? { ...snapshot, state: "error", errorCode: "invalid_response" } : snapshot;
  if (hasElapsedReset(snapshot, now)) return { ...snapshot, state: "error", errorCode: "reset_pending" };
  return current ? snapshot : { ...snapshot, state: "ok" };
}

// src/shared/display-policy.ts
var displayProvider = (page) => page === "codex" ? "chatgpt" : page;

// src/shared/contracts.ts
function sameFields(left, right) {
  if (left === right) return true;
  if (Array.isArray(left)) return Array.isArray(right) && left.length === right.length && left.every((value, index) => sameFields(value, right[index]));
  const a = record(left), b = record(right);
  return !!a && !!b && Object.keys(a).length === Object.keys(b).length && Object.keys(a).every((key) => Object.hasOwn(b, key) && sameFields(a[key], b[key]));
}
function isReply(input) {
  const r = record(input), view2 = record(r?.view);
  if (r?.ok !== true || !view2 || !isSettings(view2.settings)) return false;
  return PROVIDERS.every((p) => {
    const raw = record(record(view2.snapshots)?.[p]);
    if (!raw || typeof record(view2.permissions)?.[p] !== "boolean") return false;
    const clean = parseSnapshot(raw, p);
    return sameFields(clean, raw);
  });
}
async function request(message) {
  const reply = await chrome.runtime.sendMessage(message);
  if (!isReply(reply)) throw new Error("invalid_extension_response");
  return reply.view;
}

// src/popup/render.ts
init_types();

// src/shared/format.ts
var DAYS = ["\uC77C", "\uC6D4", "\uD654", "\uC218", "\uBAA9", "\uAE08", "\uD1A0"];
var twoDigits = (value) => String(value).padStart(2, "0");
function resetValue(value, now) {
  const reset = resetTime(value);
  if (reset === null) return "\uD655\uC778 \uBD88\uAC00";
  const at = new Date(reset);
  const local = `${at.getMonth() + 1}/${at.getDate()}(${DAYS[at.getDay()]}) ${twoDigits(at.getHours())}:${twoDigits(at.getMinutes())}`;
  const remaining = at.getTime() - now;
  if (!Number.isFinite(remaining)) return `${local}, \uB0A8\uC740 \uC2DC\uAC04 \uD655\uC778 \uBD88\uAC00`;
  if (remaining <= 0) return `${local}, \uCD08\uAE30\uD654 \uD6C4 \uD655\uC778 \uC911`;
  const hours = Math.floor(remaining / 36e5), days = Math.floor(hours / 24);
  return `${local}, ${days > 0 ? `${days}d ` : ""}${hours % 24}h \uB0A8\uC74C`;
}
var resetLabel = (reset, now = Date.now()) => `\u{1F552} \uC0AC\uC6A9\uB7C9 \uCD08\uAE30\uD654: ${resetValue(reset, now)}`;
function usagePercentLabel(value) {
  const used = percent(value);
  return `\uC0AC\uC6A9\uB7C9: ${used === null ? "\uD655\uC778 \uBD88\uAC00" : `${Math.round(used)}%`}`;
}
var STATUS_TEXT = {
  not_collected: "\uC0AC\uC6A9\uB7C9 \uD655\uC778 \uC911",
  signed_out: "\uB85C\uADF8\uC778 \uD544\uC694",
  access_denied: "\uC0AC\uC774\uD2B8 \uC811\uADFC \uAC70\uBD80",
  rate_limited: "\uC7A0\uC2DC \uD6C4 \uB2E4\uC2DC \uD655\uC778",
  network: "\uC5F0\uACB0 \uD655\uC778 \uC911",
  server: "\uC11C\uBE44\uC2A4 \uC751\uB2F5 \uB300\uAE30",
  invalid_response: "\uC0AC\uC6A9\uB7C9 \uD655\uC778 \uBD88\uAC00",
  gemini_response_type: "\uC0AC\uC6A9\uB7C9 \uD655\uC778 \uBD88\uAC00",
  gemini_response_read: "\uC0AC\uC6A9\uB7C9 \uD655\uC778 \uBD88\uAC00",
  gemini_frame_invalid: "\uC0AC\uC6A9\uB7C9 \uD655\uC778 \uBD88\uAC00",
  gemini_rpc_missing: "\uC0AC\uC6A9\uB7C9 \uD655\uC778 \uBD88\uAC00",
  gemini_rpc_invalid: "\uC0AC\uC6A9\uB7C9 \uD655\uC778 \uBD88\uAC00",
  gemini_quota_invalid: "\uC0AC\uC6A9\uB7C9 \uD655\uC778 \uBD88\uAC00",
  open_tab: "\uC11C\uBE44\uC2A4 \uD0ED \uC5F4\uAE30 \uD544\uC694",
  tab_access_failed: "\uC0AC\uC774\uD2B8 \uC811\uADFC \uC124\uC815 \uD655\uC778",
  ambiguous_account: "Claude \uC870\uC9C1 \uC120\uD0DD \uD544\uC694",
  unsupported: "\uC0AC\uC6A9\uB7C9 \uC218\uC9D1 \uBBF8\uC9C0\uC6D0",
  permission_required: "\uC0AC\uC774\uD2B8 \uAD8C\uD55C \uD544\uC694",
  reset_pending: "\uCD08\uAE30\uD654 \uD6C4 \uD655\uC778 \uC911"
};
function statusText(snapshot) {
  if (snapshot.state === "ok") return "\uCD5C\uADFC \uC218\uC9D1 \uC131\uACF5";
  if (snapshot.state === "stale") return "\uC0AC\uC6A9\uB7C9 \uD655\uC778 \uC911";
  return snapshot.errorCode ? STATUS_TEXT[snapshot.errorCode] : "\uD655\uC778 \uBD88\uAC00";
}

// src/popup/render.ts
var limitLabel = (provider, label2) => provider === "chatgpt" ? label2.replace(/^Work\s*\/\s*Codex\s*공유\s*(?:[·:–—-]\s*)?/, "").trim() || "\uC0AC\uC6A9\uB7C9" : label2;
function renderCards(container, view2, actions, now = Date.now()) {
  const d = container.ownerDocument;
  const el = (tag, text, cls) => {
    const e = d.createElement(tag);
    if (text) e.textContent = text;
    if (cls) e.className = cls;
    return e;
  };
  const cards2 = PROVIDERS.map((p) => {
    const s = effectiveSnapshot(view2.snapshots[p], now), enabled = view2.settings.enabled[p];
    const card = el("section", void 0, "card");
    card.dataset.provider = p;
    const title = NAMES[p];
    card.setAttribute("aria-label", `${title} \uC0AC\uC6A9\uB7C9`);
    card.append(el("h2", title));
    if (!enabled || s.state !== "ok") card.append(el("p", enabled ? statusText(s) : "\uAEBC\uC9D0", "status"));
    else if (!s.limits.length) card.append(el("p", "\uC0AC\uC6A9\uB7C9 \uD655\uC778 \uBD88\uAC00", "status"));
    if (enabled && s.limits.length) {
      if (s.state !== "ok") card.append(el("p", "\uC774\uC804 \uC218\uC9D1\uAC12", "status"));
      for (const limit of s.limits) {
        const name = limitLabel(p, limit.label);
        const row = el("div", void 0, `limit ${s.state === "ok" ? "" : "old"}`), line = el("div", void 0, "limit-line");
        line.append(el("span", name), el("span", usagePercentLabel(limit.percent), "percent"));
        row.append(line);
        const used = percent(limit.percent);
        if (used !== null) {
          const bar = el("progress");
          bar.max = 100;
          bar.value = used;
          bar.setAttribute("aria-label", `${name} \uC0AC\uC6A9\uB7C9${s.state === "ok" ? "" : " (\uC774\uC804 \uAC12)"}`);
          row.append(bar);
        }
        row.append(el("div", resetLabel(limit.resetsAt, now), "reset"));
        card.append(row);
      }
    }
    const controls = el("div", void 0, "actions");
    const button = (parent, text, fn, cls) => {
      const b = el("button", text, cls);
      b.type = "button";
      b.addEventListener("click", fn);
      parent.append(b);
      return b;
    };
    if (!enabled || !view2.permissions[p]) button(controls, view2.permissions[p] ? "\uCF1C\uAE30" : "\uAD8C\uD55C \uC2B9\uC778 \uBC0F \uCF1C\uAE30", () => actions.enable(p), "grant");
    if (enabled) {
      const refresh = button(controls, "\uC0C8\uB85C\uACE0\uCE68", () => actions.refresh(p));
      refresh.disabled = !view2.permissions[p] || s.nextAttemptAt > now;
      button(controls, "\uB044\uAE30", () => actions.disable(p));
    }
    if (view2.permissions[p]) button(controls, "\uAD8C\uD55C \uCCA0\uD68C", () => actions.revoke(p));
    const link = el("a", "\uC0AC\uC774\uD2B8 \uC5F4\uAE30");
    link.href = HOME_URLS[p];
    link.target = "_blank";
    link.rel = "noopener noreferrer";
    controls.append(link);
    card.append(controls);
    return card;
  });
  container.replaceChildren(...cards2);
}

// src/popup/diagnostics.ts
init_types();
function createDiagnosticReport(view2, extensionVersion2) {
  const providers = {};
  for (const p of PROVIDERS) {
    const snapshot = view2.snapshots[p];
    providers[p] = {
      enabled: view2.settings.enabled[p],
      permission: view2.permissions[p],
      state: snapshot.state,
      errorCode: snapshot.errorCode,
      checkedAt: snapshot.checkedAt,
      collectedAt: snapshot.collectedAt,
      nextAttemptAt: snapshot.nextAttemptAt
    };
  }
  const strips = Object.fromEntries(PAGE_PROVIDERS.map((p) => [p, view2.settings.strips[p]]));
  return { extensionVersion: extensionVersion2, providers, strips };
}
function cleanDisplayReply(value, provider) {
  if (typeof value !== "object" || value === null) return null;
  const raw = value;
  const resolved = raw.provider === provider ? provider : provider === "chatgpt" && raw.provider === "codex" ? "codex" : null;
  if (raw.status !== "ready" || !resolved || raw.contentReady !== true || typeof raw.targetFound !== "boolean" || typeof raw.stripVisible !== "boolean") return null;
  const count = (value2) => typeof value2 === "number" && Number.isSafeInteger(value2) && value2 >= 0 && value2 <= 1e4;
  if (!count(raw.editableCount) || !count(raw.iframeCount) || !count(raw.stripCount)) return null;
  return {
    status: "ready",
    provider: resolved,
    contentReady: true,
    editableCount: raw.editableCount,
    iframeCount: raw.iframeCount,
    targetFound: raw.targetFound,
    stripCount: raw.stripCount,
    stripVisible: raw.stripVisible
  };
}
async function readActiveDisplayDiagnostic(view2, api = chrome) {
  let provider = null;
  try {
    const [tab] = await api.tabs.query({ active: true, lastFocusedWindow: true });
    provider = providerFromUrl(tab?.url);
    if (!provider || typeof tab?.id !== "number") return { status: "no_site" };
    const source = displayProvider(provider);
    if (!view2.permissions[source] || !await api.permissions.contains({ origins: [ORIGINS[source]] })) return { status: "permission_required", provider };
    const reply = await api.tabs.sendMessage(tab.id, { type: "display-diagnostics" }, { frameId: 0 });
    return cleanDisplayReply(reply, provider) ?? { status: "content_unavailable", provider };
  } catch {
    return provider ? { status: "content_unavailable", provider } : { status: "content_unavailable" };
  }
}
function bindDiagnostics(doc, getView, extensionVersion2, copy = (text) => doc.defaultView.navigator.clipboard.writeText(text), readDisplay = typeof chrome !== "undefined" && chrome.tabs ? readActiveDisplayDiagnostic : void 0) {
  const output = doc.getElementById("diagnostics-output");
  const feedback2 = doc.getElementById("diagnostics-feedback");
  let revision = 0;
  const show = async () => {
    const currentRevision = ++revision;
    const view2 = getView();
    if (!view2) {
      feedback2.textContent = "\uC0C1\uD0DC\uB97C \uC544\uC9C1 \uC77D\uC9C0 \uBABB\uD588\uC2B5\uB2C8\uB2E4. \uC7A0\uC2DC \uD6C4 \uB2E4\uC2DC \uB20C\uB7EC \uC8FC\uC138\uC694.";
      return null;
    }
    const report = createDiagnosticReport(view2, extensionVersion2);
    output.value = JSON.stringify(report, null, 2);
    output.hidden = false;
    if (readDisplay) {
      feedback2.textContent = "\uD604\uC7AC \uD0ED\uC758 \uD45C\uC2DC \uC0C1\uD0DC\uB97C \uD655\uC778\uD558\uACE0 \uC788\uC2B5\uB2C8\uB2E4.";
      try {
        report.display = await readDisplay(view2);
      } catch {
        report.display = { status: "content_unavailable" };
      }
      if (revision !== currentRevision) return null;
    }
    const text = JSON.stringify(report, null, 2);
    output.value = text;
    feedback2.textContent = "\uD604\uC7AC \uC0C1\uD0DC\uB97C \uD45C\uC2DC\uD588\uC2B5\uB2C8\uB2E4. \uC790\uB3D9\uC73C\uB85C \uC804\uC1A1\uB418\uC9C0 \uC54A\uC2B5\uB2C8\uB2E4.";
    return text;
  };
  doc.getElementById("diagnostics-show").addEventListener("click", () => {
    void show();
  });
  doc.getElementById("diagnostics-copy").addEventListener("click", () => {
    void (async () => {
      const text = await show();
      if (text === null) return;
      try {
        await copy(text);
        feedback2.textContent = "\uC9C4\uB2E8 \uC815\uBCF4\uB97C \uBCF5\uC0AC\uD588\uC2B5\uB2C8\uB2E4.";
      } catch {
        output.focus();
        output.select();
        feedback2.textContent = "\uC790\uB3D9 \uBCF5\uC0AC\uAC00 \uD5C8\uC6A9\uB418\uC9C0 \uC54A\uC544 \uB0B4\uC6A9\uC744 \uC120\uD0DD\uD588\uC2B5\uB2C8\uB2E4. \uC9C1\uC811 \uBCF5\uC0AC\uD574 \uC8FC\uC138\uC694.";
      }
    })();
  });
}

// src/shared/build-mode.ts
var DEVELOPMENT = true;

// src/popup/index.ts
var view = null;
var busy = false;
var settingsDirty = false;
var viewDirty = false;
var installedManifest = chrome.runtime.getManifest();
var extensionVersion = installedManifest.version_name ?? installedManifest.version;
document.getElementById("extension-version").textContent = `AI Gauge ${extensionVersion}`;
if (DEVELOPMENT) bindDiagnostics(document, () => view, extensionVersion);
var cards = document.getElementById("cards");
var feedback = document.getElementById("feedback");
var field = (id) => document.getElementById(id);
var displayNames = { chatgpt: "ChatGPT", codex: "Codex", claude: "Claude", gemini: "Gemini" };
for (const p of PAGE_PROVIDERS) {
  const label2 = document.createElement("label");
  label2.className = "toggle";
  const checkbox = document.createElement("input");
  checkbox.type = "checkbox";
  checkbox.id = `strip-${p}`;
  label2.append(checkbox, document.createTextNode(`${displayNames[p]} \uC785\uB825\uCC3D\uC5D0 \uD45C\uC2DC`));
  document.getElementById("strip-settings").append(label2);
}
function render() {
  if (!view) return;
  renderCards(cards, view, { enable: (p) => {
    void enable(p);
  }, disable: (p) => {
    void run(() => request({ type: "disable", provider: p }));
  }, revoke: (p) => {
    void run(async () => {
      await chrome.permissions.remove({ origins: [ORIGINS[p]] });
      return request({ type: "view" });
    });
  }, refresh: (p) => {
    void run(() => request({ type: "refresh", provider: p, trigger: "manual" }));
  } });
  if (!settingsDirty) {
    for (const p of PAGE_PROVIDERS) field(`strip-${p}`).checked = view.settings.strips[p];
  }
}
async function run(action) {
  if (busy) return;
  busy = true;
  try {
    view = await action();
    render();
    feedback.textContent = "";
  } catch {
    feedback.textContent = "\uD655\uC7A5 \uD504\uB85C\uADF8\uB7A8\uACFC \uD1B5\uC2E0\uD560 \uC218 \uC5C6\uC2B5\uB2C8\uB2E4. \uD655\uC7A5\uC744 \uB2E4\uC2DC \uB85C\uB4DC\uD574 \uC8FC\uC138\uC694.";
  } finally {
    busy = false;
    if (viewDirty) {
      viewDirty = false;
      void run(() => request({ type: "view" }));
    }
  }
}
async function enable(p) {
  if (busy) return;
  let canceled = false;
  await run(async () => {
    if (!await chrome.permissions.request({ origins: [ORIGINS[p]] })) {
      canceled = true;
      return request({ type: "view" });
    }
    return request({ type: "enable", provider: p });
  });
  if (canceled) feedback.textContent = "\uAD8C\uD55C \uC2B9\uC778\uC774 \uCDE8\uC18C\uB418\uC5C8\uC2B5\uB2C8\uB2E4.";
}
document.getElementById("settings-form").addEventListener("input", () => {
  settingsDirty = true;
});
document.getElementById("settings-form").addEventListener("submit", (event) => {
  event.preventDefault();
  const strips = Object.fromEntries(PAGE_PROVIDERS.map((p) => [p, field(`strip-${p}`).checked]));
  settingsDirty = false;
  void run(() => request({ type: "strips", strips }));
});
chrome.storage.onChanged.addListener(() => {
  if (busy) viewDirty = true;
  else void run(() => request({ type: "view" }));
});
void run(() => request({ type: "view" }));
setInterval(render, 15e3);
