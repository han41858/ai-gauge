var __defProp = Object.defineProperty;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __esm = (fn, res) => function __init() {
  return fn && (res = (0, fn[__getOwnPropNames(fn)[0]])(fn = 0)), res;
};
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};

// src/shared/types.ts
var types_exports = {};
__export(types_exports, {
  HOME_URLS: () => HOME_URLS,
  NAMES: () => NAMES,
  ORIGINS: () => ORIGINS,
  PROVIDERS: () => PROVIDERS,
  SITE_GROUPS: () => SITE_GROUPS,
  isProvider: () => isProvider,
  providerFromUrl: () => providerFromUrl
});
function providerFromUrl(url) {
  try {
    const u = new URL(url ?? "");
    if (u.protocol !== "https:") return null;
    if (u.hostname === "claude.ai") return "claude";
    if (u.hostname === "chatgpt.com") return /^\/(codex|work)(?:\/|$)/.test(u.pathname) ? "work_codex" : "chatgpt";
    return null;
  } catch {
    return null;
  }
}
var PROVIDERS, ORIGINS, NAMES, HOME_URLS, isProvider, SITE_GROUPS;
var init_types = __esm({
  "src/shared/types.ts"() {
    "use strict";
    PROVIDERS = ["chatgpt", "work_codex", "claude"];
    ORIGINS = { chatgpt: "https://chatgpt.com/*", work_codex: "https://chatgpt.com/*", claude: "https://claude.ai/*" };
    NAMES = { chatgpt: "ChatGPT", work_codex: "Work / Codex", claude: "Claude" };
    HOME_URLS = { chatgpt: "https://chatgpt.com/", work_codex: "https://chatgpt.com/codex", claude: "https://claude.ai/" };
    isProvider = (v) => PROVIDERS.includes(v);
    SITE_GROUPS = [
      { id: "openai", origin: ORIGINS.chatgpt, providers: ["chatgpt", "work_codex"] },
      { id: "claude", origin: ORIGINS.claude, providers: ["claude"] }
    ];
  }
});

// src/background/index.ts
init_types();

// src/shared/contracts.ts
init_types();

// src/shared/validation.ts
function record(v) {
  return v !== null && typeof v === "object" && !Array.isArray(v) ? v : null;
}
var finite = (v) => typeof v === "number" && Number.isFinite(v);
var percent = (v) => finite(v) && v >= 0 && v <= 100 ? v : null;
var nonnegative = (v) => finite(v) && v >= 0 ? v : null;
function label(v) {
  return typeof v === "string" && v.trim().length > 0 && v.length <= 120 && !/[\u0000-\u001f\u007f]/.test(v) ? v.trim() : null;
}
function resetTime(v) {
  if (typeof v !== "string") return null;
  const parts = /^(\d{4})-(\d{2})-(\d{2})T(\d{2}):(\d{2}):(\d{2})(?:\.\d+)?(?:Z|[+-]\d{2}:\d{2})$/.exec(v);
  if (!parts) return null;
  const [year, month, day, hour, minute, second] = parts.slice(1, 7).map(Number);
  if (month < 1 || month > 12 || day < 1 || day > new Date(Date.UTC(year, month, 0)).getUTCDate() || hour > 23 || minute > 59 || second > 59) return null;
  const ms = Date.parse(v);
  return Number.isFinite(ms) && ms > 0 && ms < 41024448e5 ? new Date(ms).toISOString() : null;
}
function unixReset(v) {
  return finite(v) && v > 0 && v < 4102444800 ? new Date(v * 1e3).toISOString() : null;
}

// src/storage/settings.ts
init_types();
function defaults() {
  return { enabled: { chatgpt: false, work_codex: false, claude: false }, strips: { chatgpt: true, work_codex: true, claude: true }, defaultProvider: "chatgpt", selectedLimit: { chatgpt: null, work_codex: null, claude: null }, followTab: false, warning: 70, danger: 90 };
}
function parseSettings(value) {
  const out = defaults(), r = record(value);
  if (!r) return out;
  for (const p of PROVIDERS) {
    for (const key of ["enabled", "strips"]) {
      const v = record(r[key])?.[p];
      if (typeof v === "boolean") out[key][p] = v;
    }
    const selected = record(r.selectedLimit)?.[p];
    if (selected === null || typeof selected === "string" && selected.length <= 200) out.selectedLimit[p] = selected;
  }
  if (isProvider(r.defaultProvider)) out.defaultProvider = r.defaultProvider;
  if (typeof r.followTab === "boolean") out.followTab = r.followTab;
  if (finite(r.warning) && finite(r.danger) && r.warning >= 0 && r.warning < r.danger && r.danger <= 100) {
    out.warning = r.warning;
    out.danger = r.danger;
  }
  return out;
}
function isSettings(value) {
  const r = record(value);
  if (!r || !isProvider(r.defaultProvider) || typeof r.followTab !== "boolean") return false;
  if (!finite(r.warning) || !finite(r.danger) || r.warning < 0 || r.warning >= r.danger || r.danger > 100) return false;
  return PROVIDERS.every((p) => typeof record(r.enabled)?.[p] === "boolean" && typeof record(r.strips)?.[p] === "boolean" && (record(r.selectedLimit)?.[p] === null || typeof record(r.selectedLimit)?.[p] === "string" && String(record(r.selectedLimit)?.[p]).length <= 200));
}

// src/storage/snapshots.ts
init_types();

// src/shared/errors.ts
var CollectionError = class extends Error {
  constructor(code, state = "error", retryAfterMs = 0) {
    super(code);
    this.code = code;
    this.state = state;
    this.retryAfterMs = retryAfterMs;
  }
};
function retryAfter(value, now = Date.now()) {
  if (!value) return 0;
  if (/^\d+(?:\.\d+)?$/.test(value)) {
    const ms = Number(value) * 1e3;
    return Number.isFinite(ms) && ms <= Number.MAX_SAFE_INTEGER ? Math.max(0, ms) : 0;
  }
  const time = Date.parse(value);
  return Number.isFinite(time) ? Math.max(0, time - now) : 0;
}
function httpError(status, wait = 0) {
  if (status === 401) return new CollectionError("signed_out", "signed_out");
  if (status === 429) return new CollectionError("rate_limited", "rate_limited", wait);
  if (status === 403) return new CollectionError("access_denied");
  return new CollectionError(status >= 500 ? "server" : "invalid_response");
}
var ERROR_TEXT = {
  not_collected: "\uC544\uC9C1 \uC218\uC9D1\uD558\uC9C0 \uC54A\uC558\uC2B5\uB2C8\uB2E4.",
  signed_out: "\uC0AC\uC774\uD2B8\uC5D0 \uB85C\uADF8\uC778\uD55C \uB4A4 \uC218\uB3D9 \uAC31\uC2E0\uD574 \uC8FC\uC138\uC694.",
  access_denied: "\uC0AC\uC774\uD2B8\uAC00 \uC811\uADFC\uC744 \uAC70\uBD80\uD588\uC2B5\uB2C8\uB2E4. \uBCF4\uD638\uC7A5\uCE58\uB97C \uC6B0\uD68C\uD558\uC9C0 \uC54A\uC2B5\uB2C8\uB2E4.",
  rate_limited: "\uC694\uCCAD \uD55C\uB3C4\uC5D0 \uB3C4\uB2EC\uD588\uC2B5\uB2C8\uB2E4. \uC7AC\uC2DC\uB3C4 \uC2DC\uAC01\uAE4C\uC9C0 \uAE30\uB2E4\uB824 \uC8FC\uC138\uC694.",
  network: "\uC5F0\uACB0 \uB610\uB294 \uC694\uCCAD \uC2DC\uAC04\uC774 \uCD08\uACFC\uB418\uC5C8\uC2B5\uB2C8\uB2E4.",
  invalid_response: "\uC0AC\uC6A9\uB7C9 \uC751\uB2F5 \uD615\uC2DD\uC744 \uD655\uC778\uD560 \uC218 \uC5C6\uC2B5\uB2C8\uB2E4.",
  open_tab: "\uB85C\uADF8\uC778\uD55C \uC11C\uBE44\uC2A4 \uD0ED\uC744 \uC5F4\uACE0 \uAC31\uC2E0\uD574 \uC8FC\uC138\uC694.",
  ambiguous_account: "\uC5EC\uB7EC Claude \uC870\uC9C1\uC774 \uD655\uC778\uB418\uC5B4 \uC120\uD0DD\uD560 \uC218 \uC5C6\uC2B5\uB2C8\uB2E4. \uACC4\uC815\uC758 \uC0AC\uC6A9\uB7C9 \uD654\uBA74\uC744 \uD655\uC778\uD574 \uC8FC\uC138\uC694.",
  tab_access_failed: "\uC5F4\uB9B0 \uC11C\uBE44\uC2A4 \uD0ED\uC5D0\uC11C \uC218\uC9D1 \uCF54\uB4DC\uB97C \uC2E4\uD589\uD558\uC9C0 \uBABB\uD588\uC2B5\uB2C8\uB2E4. Chrome \uD655\uC7A5 \uD504\uB85C\uADF8\uB7A8\uC758 \uD574\uB2F9 \uC0AC\uC774\uD2B8 \uC811\uADFC \uC124\uC815\uC744 \uD655\uC778\uD55C \uB4A4 \uD655\uC7A5\uACFC \uD0ED\uC744 \uC0C8\uB85C\uACE0\uCE68\uD574 \uC8FC\uC138\uC694.",
  chatgpt_usage_unverified: "\uC77C\uBC18 \uCC44\uD305\uC758 \uBAA8\uB378\uBCC4 \uC0AC\uC6A9\uB7C9\uC744 \uAC80\uC99D\uD558\uC9C0 \uBABB\uD588\uC2B5\uB2C8\uB2E4. Work / Codex\uC640 \uBCC4\uAC1C\uC785\uB2C8\uB2E4.",
  unsupported: "\uC548\uC804\uD55C \uC218\uC9D1 \uACC4\uC57D\uC744 \uAC80\uC99D\uD558\uC9C0 \uBABB\uD574 \uBBF8\uC9C0\uC6D0\uC785\uB2C8\uB2E4.",
  permission_required: "\uC774 \uC11C\uBE44\uC2A4\uC758 \uC0AC\uC774\uD2B8 \uC811\uADFC \uAD8C\uD55C\uC774 \uD544\uC694\uD569\uB2C8\uB2E4.",
  server: "\uC11C\uBE44\uC2A4 \uC624\uB958\uC785\uB2C8\uB2E4. \uC7A0\uC2DC \uD6C4 \uB2E4\uC2DC \uC2DC\uB3C4\uD569\uB2C8\uB2E4.",
  chatgpt_usage_pending: "\uC77C\uBC18 ChatGPT \uBAA8\uB378\uBCC4 \uC0AC\uC6A9\uB7C9\uC740 \uD655\uC778 \uBD88\uAC00\uC785\uB2C8\uB2E4. \uC0AC\uC774\uD2B8\uAC00 \uC81C\uACF5\uD55C \uAE30\uB2A5\uBCC4 \uC794\uC5EC \uC218\uCE58\uAC00 \uC788\uC744 \uB54C\uB9CC \uD45C\uC2DC\uD569\uB2C8\uB2E4.",
  chatgpt_quota_absent: "\uC0AC\uC774\uD2B8 \uC751\uB2F5\uC5D0 \uD45C\uC2DC\uD560 \uC794\uC5EC \uC0AC\uC6A9\uB7C9\uC774 \uC5C6\uC2B5\uB2C8\uB2E4. \uBAA8\uB378\uBCC4 \uC0AC\uC6A9\uB960\uC740 \uD655\uC778 \uBD88\uAC00\uC785\uB2C8\uB2E4."
};

// src/storage/snapshots.ts
var FRESH_MS = 10 * 6e4;
function emptySnapshot(provider) {
  return { provider, state: "error", limits: [], collectedAt: null, checkedAt: null, nextAttemptAt: 0, failures: 0, errorCode: provider === "chatgpt" ? "chatgpt_usage_pending" : "not_collected" };
}
function validLimits(input) {
  return Array.isArray(input) && input.length <= 150 && input.every((x) => {
    const r = record(x);
    return r && typeof r.id === "string" && r.id.length > 0 && r.id.length <= 200 && label(r.label) && ["window", "model", "product"].includes(String(r.category)) && r.source === "api" && (r.percent === null || percent(r.percent) !== null) && (r.resetsAt === null || resetTime(r.resetsAt) !== null) && (r.windowSeconds === null || nonnegative(r.windowSeconds) !== null) && (r.remaining === null || nonnegative(r.remaining) !== null) && (r.unit === null || label(r.unit));
  }) && new Set(input.map((x) => x.id)).size === input.length;
}
function parseSnapshot(input, provider) {
  const r = record(input);
  if (!r || r.provider !== provider || !["ok", "stale", "signed_out", "permission_required", "rate_limited", "unsupported", "error"].includes(String(r.state)) || !validLimits(r.limits) || !(r.collectedAt === null || finite(r.collectedAt)) || !(r.checkedAt === null || finite(r.checkedAt)) || !finite(r.nextAttemptAt) || !finite(r.failures) || !(r.errorCode === null || typeof r.errorCode === "string" && Object.hasOwn(ERROR_TEXT, r.errorCode))) return emptySnapshot(provider);
  if (r.state === "ok" && (r.collectedAt === null || r.limits.length === 0)) return emptySnapshot(provider);
  return { provider, state: r.state, limits: r.limits, collectedAt: r.collectedAt, checkedAt: r.checkedAt, nextAttemptAt: Math.max(0, r.nextAttemptAt), failures: Math.max(0, r.failures), errorCode: r.errorCode };
}
function effectiveSnapshot(snapshot, now = Date.now()) {
  return snapshot.state === "ok" && (snapshot.collectedAt === null || now - snapshot.collectedAt >= FRESH_MS || snapshot.collectedAt > now + 6e4) ? { ...snapshot, state: "stale" } : snapshot;
}
async function readSnapshot(provider) {
  const key = snapshotKey(provider);
  return parseSnapshot((await chrome.storage.local.get(key))[key], provider);
}
var snapshotKey = (provider) => `snapshot:${provider === "chatgpt" ? "v3" : "v2"}:${provider}`;
async function writeSnapshot(snapshot) {
  await chrome.storage.local.set({ [snapshotKey(snapshot.provider)]: snapshot });
}
async function readSettings() {
  return parseSettings((await chrome.storage.local.get("settings")).settings);
}
async function readView() {
  const settings = await readSettings();
  const permissions = {}, snapshots = {};
  const { ORIGINS: ORIGINS2 } = await Promise.resolve().then(() => (init_types(), types_exports));
  await Promise.all(PROVIDERS.map(async (p) => {
    permissions[p] = await chrome.permissions.contains({ origins: [ORIGINS2[p]] });
    const s = effectiveSnapshot(await readSnapshot(p));
    snapshots[p] = permissions[p] ? s : { ...s, state: "permission_required", errorCode: "permission_required" };
  }));
  return { settings, snapshots, permissions };
}

// src/shared/display-policy.ts
var displayProvider = (page) => page === "chatgpt" ? "work_codex" : page;
function shouldShowStrip(view, page) {
  const source = displayProvider(page);
  return view.permissions[source] && view.settings.enabled[source] && view.settings.strips[page];
}
function needsContent(view, pages) {
  const observeChatGPT = pages.includes("chatgpt") && view.permissions.chatgpt && view.settings.enabled.chatgpt;
  return observeChatGPT || pages.some((page) => shouldShowStrip(view, page));
}
var canRefreshFromPage = (page, source) => page === source || displayProvider(page) === source;

// src/shared/contracts.ts
function parseMessage(input) {
  const r = record(input);
  if (!r) return null;
  const keys = Object.keys(r).sort().join(",");
  if (r.type === "view" && keys === "type") return { type: "view" };
  if ((r.type === "enable" || r.type === "disable") && keys === "provider,type" && isProvider(r.provider)) return { type: r.type, provider: r.provider };
  if (r.type === "strips" && keys === "strips,type") {
    const strips = record(r.strips);
    if (strips && Object.keys(strips).length === PROVIDERS.length && PROVIDERS.every((p) => typeof strips[p] === "boolean")) {
      return { type: "strips", strips: Object.fromEntries(PROVIDERS.map((p) => [p, strips[p]])) };
    }
  }
  if (r.type === "refresh" && keys === "provider,trigger,type" && isProvider(r.provider) && (r.trigger === "manual" || r.trigger === "event")) return { type: "refresh", provider: r.provider, trigger: r.trigger };
  if (r.type === "settings" && keys === "settings,type" && isSettings(r.settings)) return { type: "settings", settings: r.settings };
  return null;
}
function authorized(message, sender, extensionId) {
  if (sender.id !== extensionId) return false;
  if (sender.tab) {
    const p = providerFromUrl(sender.url);
    return p !== null && providerFromUrl(sender.tab.url) === p && sender.frameId === 0 && (message.type === "view" || message.type === "refresh" && canRefreshFromPage(p, message.provider) && message.trigger === "event");
  }
  return sender.url === `chrome-extension://${extensionId}/popup.html`;
}

// src/providers/tab-transport.ts
init_types();

// src/providers/chatgpt-observer.ts
function installChatGPTObserver() {
  if (location.origin !== "https://chatgpt.com") return;
  const host = globalThis;
  const stateKey = "__AI_GAUGE_CHATGPT_OBSERVER_V1__";
  const cacheKey = "__AI_GAUGE_CHATGPT_QUOTA_V1__";
  if (host[stateKey]) return;
  const state = {};
  host[stateKey] = state;
  const originalFetch = globalThis.fetch;
  let active = true, requestOrder = 0, publishedOrder = 0;
  const allowedPage = () => location.origin === "https://chatgpt.com" && !/^\/(?:codex|work)(?:\/|$)/.test(location.pathname);
  const object = (value) => value !== null && typeof value === "object" && !Array.isArray(value) ? value : null;
  const shortText = (value) => typeof value === "string" && value.length <= 120 ? value : null;
  const endpoint = (value) => {
    try {
      const url = new URL(value, location.href);
      return url.origin === "https://chatgpt.com" && url.pathname === "/backend-api/conversation/init";
    } catch {
      return false;
    }
  };
  const publish2 = (order, value) => {
    if (!active || !allowedPage() || order < publishedOrder) return;
    const raw = object(value);
    const rows = Array.isArray(raw?.limits_progress) ? raw.limits_progress.slice(0, 50).map((value2) => {
      const row = object(value2);
      return { feature_name: shortText(row?.feature_name), remaining: typeof row?.remaining === "number" && Number.isSafeInteger(row.remaining) && row.remaining >= 0 ? row.remaining : null, reset_after: shortText(row?.reset_after) };
    }) : raw && (raw.limits_progress === void 0 || raw.limits_progress === null) ? [] : null;
    publishedOrder = order;
    host[cacheKey] = { version: 1, observedAt: Date.now(), data: { limits_progress: rows } };
    document.dispatchEvent(new Event("ai-gauge-chatgpt-quota"));
  };
  const wrappedFetch = function(...args) {
    let matches = false;
    try {
      const input = args[0];
      matches = active && allowedPage() && endpoint(typeof input === "string" ? input : input instanceof URL ? input.href : input instanceof Request ? input.url : "");
    } catch {
    }
    const responsePromise = Reflect.apply(originalFetch, this, args);
    if (matches) {
      const order = ++requestOrder;
      void responsePromise.then(async (response) => {
        if (!active || !allowedPage()) return;
        if (!response.ok) {
          publish2(order, null);
          return;
        }
        if (response.url && !endpoint(response.url)) return;
        if (!response.headers.get("content-type")?.toLowerCase().includes("application/json")) return;
        const length = Number(response.headers.get("content-length"));
        if (Number.isFinite(length) && length > 262144) return;
        const clone = response.clone();
        publish2(order, await clone.json());
      }).catch(() => {
      });
    }
    return responsePromise;
  };
  const stop = () => {
    active = false;
    if (globalThis.fetch === wrappedFetch) globalThis.fetch = originalFetch;
    if (host[stateKey] === state) {
      delete host[stateKey];
      delete host[cacheKey];
    }
    document.removeEventListener("ai-gauge-chatgpt-stop", stop);
  };
  document.addEventListener("ai-gauge-chatgpt-stop", stop);
  globalThis.fetch = wrappedFetch;
}
function readChatGPTObservation() {
  if (location.origin !== "https://chatgpt.com" || /^\/(?:codex|work)(?:\/|$)/.test(location.pathname)) return null;
  const host = globalThis;
  const object = (value) => value !== null && typeof value === "object" && !Array.isArray(value) ? value : null;
  const shortText = (value) => typeof value === "string" && value.length <= 120 ? value : null;
  const observation = object(host.__AI_GAUGE_CHATGPT_QUOTA_V1__);
  if (!observation || observation.version !== 1 || typeof observation.observedAt !== "number" || !Number.isSafeInteger(observation.observedAt) || observation.observedAt <= 0) return null;
  const raw = object(observation.data);
  const rows = Array.isArray(raw?.limits_progress) ? raw.limits_progress.slice(0, 50).map((value) => {
    const row = object(value);
    return { feature_name: shortText(row?.feature_name), remaining: typeof row?.remaining === "number" && Number.isSafeInteger(row.remaining) && row.remaining >= 0 ? row.remaining : null, reset_after: shortText(row?.reset_after) };
  }) : null;
  return { version: 1, observedAt: observation.observedAt, data: { limits_progress: rows } };
}
function stopChatGPTObserver() {
  if (location.origin !== "https://chatgpt.com") return;
  document.dispatchEvent(new Event("ai-gauge-chatgpt-stop"));
}

// src/providers/tab-transport.ts
async function collectInPage(provider) {
  if (location.origin !== (provider === "work_codex" ? "https://chatgpt.com" : "https://claude.ai")) return { status: 0, code: "open_tab", retryAfter: null, data: null };
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 15e3);
  const result = (status, code = null, wait = null, data = null) => ({ status, code, retryAfter: wait, data });
  const object = (v) => v !== null && typeof v === "object" && !Array.isArray(v) ? v : null;
  const numeric = (v) => typeof v === "number" && Number.isFinite(v) ? v : null;
  const text = (v) => typeof v === "string" && v.length <= 120 ? v : null;
  const get = (path, headers = {}) => fetch(path, { method: "GET", credentials: "include", cache: "no-store", redirect: "error", signal: controller.signal, headers: { Accept: "application/json", ...headers } });
  const errorResult = (r) => result(r.status, null, r.headers.get("Retry-After"));
  const read = async (r) => {
    if (!r.headers.get("content-type")?.includes("application/json")) throw new Error("invalid_response");
    return r.json();
  };
  const chatRate = (value) => {
    const raw = object(value), out = {};
    for (const key of ["primary_window", "secondary_window"]) {
      const w = object(raw?.[key]);
      if (w && ("used_percent" in w || "reset_at" in w)) out[key] = { used_percent: numeric(w.used_percent), reset_at: numeric(w.reset_at), limit_window_seconds: numeric(w.limit_window_seconds) };
    }
    return out;
  };
  try {
    if (provider === "work_codex") {
      const sessionResp = await get("/api/auth/session");
      if (!sessionResp.ok) return errorResult(sessionResp);
      const session = object(await read(sessionResp));
      if (typeof session?.accessToken !== "string" || !session.accessToken || session.accessToken.length > 16384) return result(401);
      const usageResp2 = await get("/backend-api/wham/usage", { Authorization: `Bearer ${session.accessToken}` });
      if (!usageResp2.ok) return errorResult(usageResp2);
      const raw2 = object(await read(usageResp2));
      if (!raw2) return result(200, "invalid_response");
      return result(200, null, null, { rate_limit: chatRate(raw2.rate_limit), additional_rate_limits: Array.isArray(raw2.additional_rate_limits) ? raw2.additional_rate_limits.slice(0, 50).map((v) => {
        const r = object(v);
        return { limit_name: text(r?.limit_name), metered_feature: text(r?.metered_feature), rate_limit: chatRate(r?.rate_limit) };
      }) : [] });
    }
    const orgResp = await get("/api/organizations");
    if (!orgResp.ok) return errorResult(orgResp);
    const orgs = await read(orgResp);
    if (!Array.isArray(orgs)) return result(200, "invalid_response");
    if (!orgs.length) return result(200, "invalid_response");
    if (orgs.length !== 1) return result(200, "ambiguous_account");
    const uuid = object(orgs[0])?.uuid;
    if (typeof uuid !== "string" || !/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(uuid)) return result(200, "invalid_response");
    const usageResp = await get(`/api/organizations/${uuid}/usage`);
    if (!usageResp.ok) return errorResult(usageResp);
    const raw = object(await read(usageResp)), out = {};
    if (!raw) return result(200, "invalid_response");
    for (const [key, value] of Object.entries(raw).slice(0, 100)) {
      if (!/^(five_hour|seven_day(?:_[a-z0-9_]+)?)$/.test(key)) continue;
      const w = object(value);
      if (w && ("utilization" in w || "resets_at" in w)) out[key] = { utilization: numeric(w.utilization), resets_at: text(w.resets_at) };
    }
    out.limits = Array.isArray(raw.limits) ? raw.limits.slice(0, 50).map((v) => {
      const w = object(v);
      return { kind: text(w?.kind), percent: numeric(w?.percent), resets_at: text(w?.resets_at), scope: { model: { display_name: text(object(object(w?.scope)?.model)?.display_name) } } };
    }) : [];
    return result(200, null, null, out);
  } catch (e) {
    return result(0, e instanceof Error && e.message === "invalid_response" ? "invalid_response" : "network");
  } finally {
    clearTimeout(timeout);
  }
}
function unwrapTransport(value) {
  const r = record(value);
  if (!r || typeof r.status !== "number" || !Number.isInteger(r.status) || r.status < 0 || r.status > 599) throw new CollectionError("invalid_response");
  if (r.code !== null) {
    if (r.code === "network" || r.code === "invalid_response" || r.code === "open_tab" || r.code === "ambiguous_account") throw new CollectionError(r.code);
    throw new CollectionError("invalid_response");
  }
  if (r.status !== 200) throw httpError(r.status, retryAfter(typeof r.retryAfter === "string" && r.retryAfter.length <= 100 ? r.retryAfter : null));
  return r.data;
}
async function collectionTab(provider) {
  const eligible = (await chrome.tabs.query({ url: ORIGINS[provider] })).filter((tab) => !tab.discarded && !tab.frozen && typeof tab.id === "number" && (provider !== "chatgpt" || providerFromUrl(tab.url) === "chatgpt"));
  if (eligible.length <= 1) return eligible[0];
  const focused = await chrome.tabs.query({ url: ORIGINS[provider], active: true, lastFocusedWindow: true });
  return eligible.find((tab) => focused.some((candidate) => candidate.id === tab.id && candidate.active)) ?? eligible.sort((a, b) => Number(b.active) - Number(a.active))[0];
}
async function collectFromTab(provider) {
  if (!await chrome.permissions.contains({ origins: [ORIGINS[provider]] })) throw new CollectionError("permission_required", "permission_required");
  const tab = await collectionTab(provider);
  if (typeof tab?.id !== "number") throw new CollectionError("open_tab");
  let results;
  try {
    results = await chrome.scripting.executeScript({ target: { tabId: tab.id }, world: "MAIN", func: collectInPage, args: [provider] });
  } catch {
    throw new CollectionError("tab_access_failed");
  }
  return unwrapTransport(results[0]?.result);
}
async function collectChatGPTFromTab() {
  if (!await chrome.permissions.contains({ origins: [ORIGINS.chatgpt] })) throw new CollectionError("permission_required", "permission_required");
  const tab = await collectionTab("chatgpt");
  if (typeof tab?.id !== "number") throw new CollectionError("open_tab");
  try {
    const results = await chrome.scripting.executeScript({ target: { tabId: tab.id }, world: "MAIN", func: readChatGPTObservation });
    if (!results.length) throw new Error("missing_result");
    return results[0]?.result ?? null;
  } catch {
    throw new CollectionError("tab_access_failed");
  }
}

// src/providers/parsers.ts
var InvalidResponse = class extends Error {
  constructor() {
    super("invalid_response");
  }
};
var item = (id, name, category, value, reset, span) => ({ id, label: name, category, percent: percent(value), resetsAt: reset, windowSeconds: span, remaining: null, unit: null, source: "api" });
function parseClaude(input) {
  const data = record(input);
  if (!data) throw new InvalidResponse();
  const items = [];
  for (const [key, raw] of Object.entries(data).slice(0, 100)) {
    if (!/^(five_hour|seven_day(?:_[a-z0-9_]+)?)$/.test(key)) continue;
    const w = record(raw);
    if (!w || !("utilization" in w) && !("resets_at" in w)) continue;
    const name = key === "five_hour" ? "5\uC2DC\uAC04" : key === "seven_day" ? "7\uC77C" : `7\uC77C \xB7 ${key.slice(10)}`;
    items.push(item(key, name, key === "five_hour" || key === "seven_day" ? "window" : "model", w.utilization, resetTime(w.resets_at), key === "five_hour" ? 18e3 : 604800));
  }
  if (Array.isArray(data.limits)) {
    for (const raw of data.limits.slice(0, 50)) {
      const w = record(raw), model = record(record(w?.scope)?.model);
      const modelName = label(model?.display_name);
      if (w?.kind !== "weekly_scoped" || !modelName || modelName.length > 100) continue;
      const id = `weekly_scoped:${modelName}`;
      if (items.some((v) => v.id === id)) continue;
      items.push(item(id, `7\uC77C \xB7 ${modelName}`, "model", w.percent, resetTime(w.resets_at), 604800));
    }
  }
  if (!items.length) throw new InvalidResponse();
  return items;
}
function chatWindows(raw, prefix, title, category) {
  const rate = record(raw);
  if (!rate) return [];
  const result = [];
  for (const key of ["primary_window", "secondary_window"]) {
    const w = record(rate[key]);
    if (!w || !("used_percent" in w || "reset_at" in w)) continue;
    const span = nonnegative(w.limit_window_seconds);
    const windowLabel = span === 18e3 ? "5\uC2DC\uAC04" : span === 604800 ? "7\uC77C" : span ? `${span / 3600}\uC2DC\uAC04` : key === "primary_window" ? "\uAE30\uBCF8 \uC81C\uD55C" : "\uCD94\uAC00 \uC81C\uD55C";
    result.push(item(`${prefix}:${key}`, `${title} \xB7 ${windowLabel}`, category, w.used_percent, unixReset(w.reset_at), span));
  }
  return result;
}
function parseWorkCodex(input) {
  const data = record(input);
  if (!data) throw new InvalidResponse();
  const items = chatWindows(data.rate_limit, "shared", "Work / Codex \uACF5\uC720", "product");
  if (Array.isArray(data.additional_rate_limits)) {
    for (const raw of data.additional_rate_limits.slice(0, 50)) {
      const bucket = record(raw);
      const name = label(bucket?.limit_name) ?? label(bucket?.metered_feature);
      if (!name || name.length > 100) continue;
      for (const limit of chatWindows(bucket?.rate_limit, `product:${name}`, name, "product")) if (!items.some((i) => i.id === limit.id)) items.push(limit);
    }
  }
  if (!items.length) throw new InvalidResponse();
  return items;
}

// src/providers/chatgpt-parser.ts
function parseChatGPT(input) {
  const data = record(input);
  if (!data || !Array.isArray(data.limits_progress)) throw new InvalidResponse();
  const limits = /* @__PURE__ */ new Map();
  const duplicates = /* @__PURE__ */ new Set();
  for (const raw of data.limits_progress.slice(0, 50)) {
    const row = record(raw);
    if (!row || typeof row.feature_name !== "string" || !/^[a-zA-Z0-9][a-zA-Z0-9_.:-]{0,79}$/.test(row.feature_name)) continue;
    const id = `feature:${row.feature_name}`;
    if (limits.has(id)) {
      duplicates.add(id);
      continue;
    }
    const remaining = typeof row.remaining === "number" && Number.isSafeInteger(row.remaining) && row.remaining >= 0 ? row.remaining : null;
    const resetsAt = resetTime(row.reset_after);
    if (remaining === null && resetsAt === null) continue;
    limits.set(id, { id, label: `\uAE30\uB2A5 \xB7 ${row.feature_name}`, category: "product", percent: null, remaining, unit: null, resetsAt, windowSeconds: null, source: "api" });
  }
  return [...limits.values()].filter((limit) => !duplicates.has(limit.id));
}
function parseChatGPTObservation(input, now = Date.now()) {
  const observation = record(input);
  if (!observation || observation.version !== 1 || typeof observation.observedAt !== "number" || !Number.isSafeInteger(observation.observedAt) || observation.observedAt <= 0 || observation.observedAt > now + 6e4) throw new InvalidResponse();
  return { limits: parseChatGPT(observation.data), observedAt: observation.observedAt };
}

// src/providers/chatgpt.ts
async function collectChatGPT() {
  const observation = await collectChatGPTFromTab();
  if (observation === null) throw new CollectionError("chatgpt_usage_pending");
  return parseChatGPTObservation(observation);
}

// src/providers/work-codex.ts
async function collectWorkCodex() {
  return parseWorkCodex(await collectFromTab("work_codex"));
}

// src/providers/claude.ts
async function collectClaude() {
  return parseClaude(await collectFromTab("claude"));
}

// src/providers/index.ts
var collect = (p) => ({ chatgpt: collectChatGPT, work_codex: collectWorkCodex, claude: collectClaude })[p]();

// src/background/scheduler.ts
function backoff(failures) {
  return Math.min(60 * 6e4, 6e4 * 2 ** Math.min(6, Math.max(0, failures - 1)));
}
function due(s, trigger, now) {
  if (s.state === "error" && s.errorCode === "open_tab" && trigger === "tab") return true;
  if (now < s.nextAttemptAt) return false;
  if (s.checkedAt !== null && now - s.checkedAt < 6e4) return false;
  if (trigger !== "manual" && ["signed_out", "permission_required", "unsupported"].includes(s.state)) return false;
  return trigger === "manual" || s.collectedAt === null || now - s.collectedAt >= (trigger === "periodic" ? FRESH_MS : 6e4);
}
function success(previous, limits, now) {
  return { ...previous, limits, state: "ok", collectedAt: now, checkedAt: now, failures: 0, nextAttemptAt: now + 6e4, errorCode: null };
}
function failure(previous, error, now) {
  const e = error instanceof CollectionError ? error : new CollectionError("invalid_response");
  if (e.code === "chatgpt_usage_pending" || e.code === "open_tab") return { ...previous, state: "error", checkedAt: now, nextAttemptAt: now + 6e4, failures: 0, errorCode: e.code };
  const failures = previous.failures + 1;
  return { ...previous, state: e.state, checkedAt: now, failures, nextAttemptAt: now + Math.max(backoff(failures), e.retryAfterMs), errorCode: e.code };
}
var Scheduler = class {
  constructor(io) {
    this.io = io;
  }
  flights = /* @__PURE__ */ new Map();
  refresh(p, trigger) {
    const active = this.flights.get(p);
    if (active) return active;
    const task = this.run(p, trigger).finally(() => this.flights.delete(p));
    this.flights.set(p, task);
    return task;
  }
  async run(p, trigger) {
    const before = await this.io.read(p);
    if (!await this.io.enabled(p) || !due(before, trigger, this.io.now())) return before;
    await this.io.write({ ...before, checkedAt: this.io.now(), nextAttemptAt: this.io.now() + 6e4, errorCode: before.errorCode === "open_tab" ? "not_collected" : before.errorCode });
    let after;
    try {
      const result = await this.io.collect(p), now = this.io.now();
      if (Array.isArray(result)) after = success(before, result, now);
      else {
        if (p !== "chatgpt" || !Number.isFinite(result.observedAt) || result.observedAt <= 0 || result.observedAt > now + 6e4 || !validLimits(result.limits)) throw new CollectionError("invalid_response");
        after = effectiveSnapshot({ ...success(before, result.limits, now), collectedAt: result.observedAt }, now);
        if (!result.limits.length) after = { ...after, state: "error", collectedAt: before.collectedAt, errorCode: "chatgpt_quota_absent" };
      }
    } catch (e) {
      after = failure(before, e, this.io.now());
    }
    if (!await this.io.enabled(p)) return before;
    await this.io.write(after);
    return after;
  }
};

// src/background/badge.ts
init_types();

// src/shared/usage-selection.ts
function highestUsageLimit(limits) {
  let highest = null;
  let highestPercent = -1;
  for (const limit of limits) {
    const used = percent(limit.percent);
    if (used !== null && used > highestPercent) {
      highest = limit;
      highestPercent = used;
    }
  }
  return highest;
}

// src/shared/format.ts
var usageValue = (limit) => limit.percent !== null ? `${Math.round(limit.percent)}%` : limit.remaining !== null ? `${limit.remaining.toLocaleString()}${limit.unit ?? ""} \uB0A8\uC74C` : "\uD655\uC778 \uBD88\uAC00";
var usageText = (limit) => `${limit.label}: ${usageValue(limit)}`;
function statusText(snapshot) {
  if (snapshot.state === "ok") return "\uCD5C\uADFC \uC218\uC9D1 \uC131\uACF5";
  if (snapshot.state === "stale") return "\uC624\uB798\uB41C \uC815\uBCF4 \xB7 \uAC31\uC2E0 \uD544\uC694";
  return snapshot.errorCode ? ERROR_TEXT[snapshot.errorCode] : "\uD655\uC778 \uBD88\uAC00";
}

// src/background/badge.ts
function selectedLimit(snapshot, _settings) {
  return highestUsageLimit(snapshot.limits);
}
function badge(view, activeUrl, now = Date.now()) {
  const page = providerFromUrl(activeUrl);
  if (!page) return { text: "", color: "#697386", textColor: "#FFFFFF", title: "AI Gauge" };
  const p = displayProvider(page);
  const s = effectiveSnapshot(view.snapshots[p], now), limit = selectedLimit(s, view.settings);
  if (!view.settings.enabled[p] || !view.permissions[p] || s.state !== "ok" || !limit || limit.percent === null) {
    const reason = !view.settings.enabled[p] ? "\uBE44\uD65C\uC131" : !view.permissions[p] ? "\uAD8C\uD55C \uD544\uC694" : s.state !== "ok" ? statusText(s) : "\uC0AC\uC6A9\uB960 \uD655\uC778 \uBD88\uAC00";
    return { text: "\u2014", color: "#697386", textColor: "#FFFFFF", title: `AI Gauge \xB7 ${NAMES[p]} \xB7 ${reason}` };
  }
  return { text: `${Math.round(limit.percent)}%`, color: p === "claude" ? "#B16046" : "#0D8669", textColor: "#FFFFFF", title: `AI Gauge \xB7 ${NAMES[p]} \xB7 ${usageText(limit)}` };
}
async function renderBadges(view) {
  await Promise.allSettled([
    chrome.action.setBadgeText({ text: "" }),
    chrome.action.setBadgeBackgroundColor({ color: "#697386" }),
    chrome.action.setBadgeTextColor({ color: "#FFFFFF" }),
    chrome.action.setTitle({ title: "AI Gauge" })
  ]);
  let tabs;
  try {
    tabs = await chrome.tabs.query({});
  } catch {
    return;
  }
  await Promise.all(tabs.filter((tab) => typeof tab.id === "number").map(async ({ id }) => {
    let tab;
    try {
      tab = await chrome.tabs.get(id);
    } catch {
      return;
    }
    const value = badge(view, tab.url);
    await Promise.allSettled([
      chrome.action.setBadgeText({ tabId: id, text: value.text }),
      chrome.action.setBadgeBackgroundColor({ tabId: id, color: value.color }),
      chrome.action.setBadgeTextColor({ tabId: id, color: value.textColor }),
      chrome.action.setTitle({ tabId: id, title: value.title })
    ]);
  }));
}
var pendingView = null;
var badgeFlight = null;
async function flushBadges() {
  try {
    while (pendingView) {
      const view = pendingView;
      pendingView = null;
      await renderBadges(view);
    }
  } finally {
    badgeFlight = null;
  }
}
function updateBadge(view) {
  pendingView = view;
  badgeFlight ??= flushBadges();
  return badgeFlight;
}

// src/background/content-registration.ts
init_types();
async function reconcileContent(view) {
  const existing = await chrome.scripting.getRegisteredContentScripts();
  const currentIds = new Set(SITE_GROUPS.map((site) => `ai-gauge-${site.id}`));
  const observerId = "ai-gauge-chatgpt-observer";
  currentIds.add(observerId);
  const retired = existing.filter((s) => s.id.startsWith("ai-gauge-") && !currentIds.has(s.id)).map((s) => s.id);
  if (retired.length) await chrome.scripting.unregisterContentScripts({ ids: retired });
  const observe = view.permissions.chatgpt && view.settings.enabled.chatgpt;
  const observing = existing.some((s) => s.id === observerId);
  if (observe && !observing) await chrome.scripting.registerContentScripts([{ id: observerId, matches: ["https://chatgpt.com/*"], js: ["chatgpt-observer.js"], world: "MAIN", runAt: "document_start", persistAcrossSessions: true }]);
  if (!observe && observing) await chrome.scripting.unregisterContentScripts({ ids: [observerId] });
  if (view.permissions.chatgpt && (observe || observing)) {
    const tabs = await chrome.tabs.query({ url: "https://chatgpt.com/*" });
    await Promise.all(tabs.filter((t) => typeof t.id === "number" && !t.discarded && !t.frozen).map((t) => chrome.scripting.executeScript({ target: { tabId: t.id }, world: "MAIN", func: observe ? installChatGPTObserver : stopChatGPTObserver }).catch(() => void 0)));
  }
  for (const site of SITE_GROUPS) {
    const id = `ai-gauge-${site.id}`, present = existing.some((s) => s.id === id);
    const enabled = needsContent(view, site.providers);
    if (!enabled && present) await chrome.scripting.unregisterContentScripts({ ids: [id] });
    if (enabled && !present) await chrome.scripting.registerContentScripts([{ id, matches: [site.origin], js: ["content.js"], runAt: "document_start", persistAcrossSessions: true }]);
    if (enabled && present && existing.find((s) => s.id === id)?.runAt === "document_idle") await chrome.scripting.updateContentScripts([{ id, js: ["content.js"], runAt: "document_start" }]);
    if (enabled) {
      const tabs = await chrome.tabs.query({ url: site.origin });
      await Promise.all(tabs.filter((t) => typeof t.id === "number" && !t.discarded && !t.frozen).map((t) => chrome.scripting.executeScript({ target: { tabId: t.id }, files: ["content.js"] }).catch(() => void 0)));
    }
  }
}

// src/background/index.ts
var scheduler = new Scheduler({ read: readSnapshot, write: writeSnapshot, collect, now: Date.now, enabled: async (p) => (await readSettings()).enabled[p] && await chrome.permissions.contains({ origins: [ORIGINS[p]] }) });
var ALARM = "ai-gauge-refresh";
var setupFlight = null;
var setupDirty = false;
function reconcile() {
  setupDirty = true;
  if (setupFlight) return setupFlight;
  setupFlight = (async () => {
    while (setupDirty) {
      setupDirty = false;
      await reconcileContent(await readView());
    }
  })().finally(() => {
    setupFlight = null;
  });
  return setupFlight;
}
async function publish() {
  const view = await readView();
  await updateBadge(view);
  await Promise.all(SITE_GROUPS.map(async (site) => {
    if (!site.providers.some((p) => view.permissions[p])) return;
    const tabs = await chrome.tabs.query({ url: site.origin });
    await Promise.all(tabs.filter((t) => typeof t.id === "number" && !t.discarded).map((t) => chrome.tabs.sendMessage(t.id, { type: "invalidate" }).catch(() => void 0)));
  }));
  return view;
}
async function refresh(p, trigger) {
  await scheduler.refresh(p, trigger);
}
async function refreshAll(trigger) {
  await Promise.all(PROVIDERS.map((p) => refresh(p, trigger)));
  await publish();
}
var settingsWrites = Promise.resolve();
function queueSettingsWrite(write) {
  const task = settingsWrites.then(write);
  settingsWrites = task.catch(() => void 0);
  return task;
}
function changeSettings(change) {
  return queueSettingsWrite(async () => {
    const settings = await readSettings();
    await change(settings);
    await chrome.storage.local.set({ settings: parseSettings(settings) });
  });
}
async function enableProvider(provider) {
  let granted = false;
  await changeSettings(async (settings) => {
    granted = await chrome.permissions.contains({ origins: [ORIGINS[provider]] });
    if (granted) settings.enabled[provider] = true;
  });
  if (!granted) return;
  await reconcile();
  await refresh(provider, "manual");
}
async function initialize() {
  if (!await chrome.alarms.get(ALARM)) await chrome.alarms.create(ALARM, { periodInMinutes: 10 });
  await queueSettingsWrite(async () => {
    const stored = await chrome.storage.local.get("settings");
    if (!stored.settings) await chrome.storage.local.set({ settings: parseSettings(null) });
  });
  await reconcile();
  await publish();
}
chrome.runtime.onMessage.addListener((input, sender, sendResponse) => {
  const message = parseMessage(input);
  if (!message || !authorized(message, sender, chrome.runtime.id)) {
    sendResponse({ ok: false });
    return false;
  }
  void (async () => {
    if (sender.tab) {
      const p = providerFromUrl(sender.url);
      if (!await chrome.permissions.contains({ origins: [ORIGINS[p]] })) return { ok: false };
    }
    if (message.type === "settings" || message.type === "strips" || message.type === "disable") {
      await changeSettings((settings) => {
        if (message.type === "strips") settings.strips = { ...message.strips };
        else if (message.type === "disable") settings.enabled[message.provider] = false;
        else Object.assign(settings, parseSettings(message.settings));
      });
      await reconcile();
    }
    if (message.type === "enable") await enableProvider(message.provider);
    if (message.type === "refresh") await refresh(message.provider, message.trigger);
    if (message.type === "view" && !sender.tab) void refreshAll("event").catch(() => void 0);
    const view = message.type === "view" ? await readView() : await publish();
    return { ok: true, view };
  })().then(sendResponse).catch(() => sendResponse({ ok: false }));
  return true;
});
chrome.alarms.onAlarm.addListener((a) => {
  if (a.name === ALARM) void refreshAll("periodic").catch(() => void 0);
});
chrome.runtime.onInstalled.addListener(() => {
  void initialize().catch(() => void 0);
});
chrome.runtime.onStartup.addListener(() => {
  void initialize().catch(() => void 0);
});
chrome.tabs.onActivated.addListener(({ tabId }) => {
  void chrome.tabs.get(tabId).then(async (tab) => {
    const p = providerFromUrl(tab.url);
    if (p) await refresh(displayProvider(p), "tab");
    await publish();
  }).catch(() => void 0);
});
chrome.tabs.onUpdated.addListener((_tabId, change, tab) => {
  if (change.status === "complete" || change.url) void (async () => {
    const p = providerFromUrl(tab.url);
    if (p && tab.active) await refresh(displayProvider(p), "tab");
    await publish();
  })().catch(() => void 0);
});
chrome.windows.onFocusChanged.addListener(() => {
  void updateBadgeFromFocus().catch(() => void 0);
});
async function updateBadgeFromFocus() {
  const tabs = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
  const p = providerFromUrl(tabs[0]?.url);
  if (p) await refresh(displayProvider(p), "tab");
  await publish();
}
chrome.permissions.onAdded.addListener((added) => {
  const providers = ["work_codex", "claude"].filter((provider) => added.origins?.includes(ORIGINS[provider]));
  void (async () => {
    await Promise.all(providers.map(enableProvider));
    await reconcile();
    await publish();
  })().catch(() => void 0);
});
chrome.permissions.onRemoved.addListener((removed) => {
  const origins = (removed?.origins ?? []).filter((origin) => SITE_GROUPS.some((site) => site.origin === origin));
  void chrome.tabs.query({}).then((tabs) => Promise.all(tabs.filter((t) => typeof t.id === "number").map((t) => chrome.tabs.sendMessage(t.id, { type: "permissions-revoked", origins }).catch(() => void 0)))).catch(() => void 0);
  void reconcile().then(publish).catch(() => void 0);
});
void initialize().catch(() => void 0);
