"use strict";
(() => {
  // src/providers/chatgpt-observer.ts
  function installChatGPTObserver() {
    if (location.origin !== "https://chatgpt.com") return;
    const host = globalThis;
    const stateKey = "__AI_GAUGE_CHATGPT_OBSERVER_V1__";
    const cacheKey = "__AI_GAUGE_CHATGPT_QUOTA_V1__";
    if (host[stateKey]) return;
    const state = {};
    host[stateKey] = state;
    const originalFetch = globalThis.fetch;
    let active = true, requestOrder = 0, publishedOrder = 0;
    const allowedPage = () => location.origin === "https://chatgpt.com" && !/^\/(?:codex|work)(?:\/|$)/.test(location.pathname);
    const object = (value) => value !== null && typeof value === "object" && !Array.isArray(value) ? value : null;
    const shortText = (value) => typeof value === "string" && value.length <= 120 ? value : null;
    const endpoint = (value) => {
      try {
        const url = new URL(value, location.href);
        return url.origin === "https://chatgpt.com" && url.pathname === "/backend-api/conversation/init";
      } catch {
        return false;
      }
    };
    const publish = (order, value) => {
      if (!active || !allowedPage() || order < publishedOrder) return;
      const raw = object(value);
      const rows = Array.isArray(raw?.limits_progress) ? raw.limits_progress.slice(0, 50).map((value2) => {
        const row = object(value2);
        return { feature_name: shortText(row?.feature_name), remaining: typeof row?.remaining === "number" && Number.isSafeInteger(row.remaining) && row.remaining >= 0 ? row.remaining : null, reset_after: shortText(row?.reset_after) };
      }) : raw && (raw.limits_progress === void 0 || raw.limits_progress === null) ? [] : null;
      publishedOrder = order;
      host[cacheKey] = { version: 1, observedAt: Date.now(), data: { limits_progress: rows } };
      document.dispatchEvent(new Event("ai-gauge-chatgpt-quota"));
    };
    const wrappedFetch = function(...args) {
      let matches = false;
      try {
        const input = args[0];
        matches = active && allowedPage() && endpoint(typeof input === "string" ? input : input instanceof URL ? input.href : input instanceof Request ? input.url : "");
      } catch {
      }
      const responsePromise = Reflect.apply(originalFetch, this, args);
      if (matches) {
        const order = ++requestOrder;
        void responsePromise.then(async (response) => {
          if (!active || !allowedPage()) return;
          if (!response.ok) {
            publish(order, null);
            return;
          }
          if (response.url && !endpoint(response.url)) return;
          if (!response.headers.get("content-type")?.toLowerCase().includes("application/json")) return;
          const length = Number(response.headers.get("content-length"));
          if (Number.isFinite(length) && length > 262144) return;
          const clone = response.clone();
          publish(order, await clone.json());
        }).catch(() => {
        });
      }
      return responsePromise;
    };
    const stop = () => {
      active = false;
      if (globalThis.fetch === wrappedFetch) globalThis.fetch = originalFetch;
      if (host[stateKey] === state) {
        delete host[stateKey];
        delete host[cacheKey];
      }
      document.removeEventListener("ai-gauge-chatgpt-stop", stop);
    };
    document.addEventListener("ai-gauge-chatgpt-stop", stop);
    globalThis.fetch = wrappedFetch;
  }

  // src/providers/chatgpt-observer-entry.ts
  installChatGPTObserver();
})();
