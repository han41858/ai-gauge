"use strict";
(() => {
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __esm = (fn, res) => function __init() {
    return fn && (res = (0, fn[__getOwnPropNames(fn)[0]])(fn = 0)), res;
  };

  // src/shared/types.ts
  function providerFromUrl(url) {
    try {
      const u = new URL(url ?? "");
      if (u.protocol !== "https:") return null;
      if (u.hostname === "claude.ai") return "claude";
      if (u.hostname === "chatgpt.com") return /^\/(codex|work)(?:\/|$)/.test(u.pathname) ? "work_codex" : "chatgpt";
      return null;
    } catch {
      return null;
    }
  }
  var PROVIDERS, ORIGINS, isProvider, SITE_GROUPS;
  var init_types = __esm({
    "src/shared/types.ts"() {
      "use strict";
      PROVIDERS = ["chatgpt", "work_codex", "claude"];
      ORIGINS = { chatgpt: "https://chatgpt.com/*", work_codex: "https://chatgpt.com/*", claude: "https://claude.ai/*" };
      isProvider = (v) => PROVIDERS.includes(v);
      SITE_GROUPS = [
        { id: "openai", origin: ORIGINS.chatgpt, providers: ["chatgpt", "work_codex"] },
        { id: "claude", origin: ORIGINS.claude, providers: ["claude"] }
      ];
    }
  });

  // src/content/index.ts
  init_types();

  // src/shared/contracts.ts
  init_types();

  // src/shared/validation.ts
  function record(v) {
    return v !== null && typeof v === "object" && !Array.isArray(v) ? v : null;
  }
  var finite = (v) => typeof v === "number" && Number.isFinite(v);
  var percent = (v) => finite(v) && v >= 0 && v <= 100 ? v : null;
  var nonnegative = (v) => finite(v) && v >= 0 ? v : null;
  function label(v) {
    return typeof v === "string" && v.trim().length > 0 && v.length <= 120 && !/[\u0000-\u001f\u007f]/.test(v) ? v.trim() : null;
  }
  function resetTime(v) {
    if (typeof v !== "string") return null;
    const parts = /^(\d{4})-(\d{2})-(\d{2})T(\d{2}):(\d{2}):(\d{2})(?:\.\d+)?(?:Z|[+-]\d{2}:\d{2})$/.exec(v);
    if (!parts) return null;
    const [year, month, day, hour, minute, second] = parts.slice(1, 7).map(Number);
    if (month < 1 || month > 12 || day < 1 || day > new Date(Date.UTC(year, month, 0)).getUTCDate() || hour > 23 || minute > 59 || second > 59) return null;
    const ms = Date.parse(v);
    return Number.isFinite(ms) && ms > 0 && ms < 41024448e5 ? new Date(ms).toISOString() : null;
  }

  // src/storage/settings.ts
  init_types();
  function isSettings(value) {
    const r = record(value);
    if (!r || !isProvider(r.defaultProvider) || typeof r.followTab !== "boolean") return false;
    if (!finite(r.warning) || !finite(r.danger) || r.warning < 0 || r.warning >= r.danger || r.danger > 100) return false;
    return PROVIDERS.every((p) => typeof record(r.enabled)?.[p] === "boolean" && typeof record(r.strips)?.[p] === "boolean" && (record(r.selectedLimit)?.[p] === null || typeof record(r.selectedLimit)?.[p] === "string" && String(record(r.selectedLimit)?.[p]).length <= 200));
  }

  // src/storage/snapshots.ts
  init_types();

  // src/shared/errors.ts
  var ERROR_TEXT = {
    not_collected: "\uC544\uC9C1 \uC218\uC9D1\uD558\uC9C0 \uC54A\uC558\uC2B5\uB2C8\uB2E4.",
    signed_out: "\uC0AC\uC774\uD2B8\uC5D0 \uB85C\uADF8\uC778\uD55C \uB4A4 \uC218\uB3D9 \uAC31\uC2E0\uD574 \uC8FC\uC138\uC694.",
    access_denied: "\uC0AC\uC774\uD2B8\uAC00 \uC811\uADFC\uC744 \uAC70\uBD80\uD588\uC2B5\uB2C8\uB2E4. \uBCF4\uD638\uC7A5\uCE58\uB97C \uC6B0\uD68C\uD558\uC9C0 \uC54A\uC2B5\uB2C8\uB2E4.",
    rate_limited: "\uC694\uCCAD \uD55C\uB3C4\uC5D0 \uB3C4\uB2EC\uD588\uC2B5\uB2C8\uB2E4. \uC7AC\uC2DC\uB3C4 \uC2DC\uAC01\uAE4C\uC9C0 \uAE30\uB2E4\uB824 \uC8FC\uC138\uC694.",
    network: "\uC5F0\uACB0 \uB610\uB294 \uC694\uCCAD \uC2DC\uAC04\uC774 \uCD08\uACFC\uB418\uC5C8\uC2B5\uB2C8\uB2E4.",
    invalid_response: "\uC0AC\uC6A9\uB7C9 \uC751\uB2F5 \uD615\uC2DD\uC744 \uD655\uC778\uD560 \uC218 \uC5C6\uC2B5\uB2C8\uB2E4.",
    open_tab: "\uB85C\uADF8\uC778\uD55C \uC11C\uBE44\uC2A4 \uD0ED\uC744 \uC5F4\uACE0 \uAC31\uC2E0\uD574 \uC8FC\uC138\uC694.",
    ambiguous_account: "\uC5EC\uB7EC Claude \uC870\uC9C1\uC774 \uD655\uC778\uB418\uC5B4 \uC120\uD0DD\uD560 \uC218 \uC5C6\uC2B5\uB2C8\uB2E4. \uACC4\uC815\uC758 \uC0AC\uC6A9\uB7C9 \uD654\uBA74\uC744 \uD655\uC778\uD574 \uC8FC\uC138\uC694.",
    tab_access_failed: "\uC5F4\uB9B0 \uC11C\uBE44\uC2A4 \uD0ED\uC5D0\uC11C \uC218\uC9D1 \uCF54\uB4DC\uB97C \uC2E4\uD589\uD558\uC9C0 \uBABB\uD588\uC2B5\uB2C8\uB2E4. Chrome \uD655\uC7A5 \uD504\uB85C\uADF8\uB7A8\uC758 \uD574\uB2F9 \uC0AC\uC774\uD2B8 \uC811\uADFC \uC124\uC815\uC744 \uD655\uC778\uD55C \uB4A4 \uD655\uC7A5\uACFC \uD0ED\uC744 \uC0C8\uB85C\uACE0\uCE68\uD574 \uC8FC\uC138\uC694.",
    chatgpt_usage_unverified: "\uC77C\uBC18 \uCC44\uD305\uC758 \uBAA8\uB378\uBCC4 \uC0AC\uC6A9\uB7C9\uC744 \uAC80\uC99D\uD558\uC9C0 \uBABB\uD588\uC2B5\uB2C8\uB2E4. Work / Codex\uC640 \uBCC4\uAC1C\uC785\uB2C8\uB2E4.",
    unsupported: "\uC548\uC804\uD55C \uC218\uC9D1 \uACC4\uC57D\uC744 \uAC80\uC99D\uD558\uC9C0 \uBABB\uD574 \uBBF8\uC9C0\uC6D0\uC785\uB2C8\uB2E4.",
    permission_required: "\uC774 \uC11C\uBE44\uC2A4\uC758 \uC0AC\uC774\uD2B8 \uC811\uADFC \uAD8C\uD55C\uC774 \uD544\uC694\uD569\uB2C8\uB2E4.",
    server: "\uC11C\uBE44\uC2A4 \uC624\uB958\uC785\uB2C8\uB2E4. \uC7A0\uC2DC \uD6C4 \uB2E4\uC2DC \uC2DC\uB3C4\uD569\uB2C8\uB2E4.",
    chatgpt_usage_pending: "\uC77C\uBC18 ChatGPT \uBAA8\uB378\uBCC4 \uC0AC\uC6A9\uB7C9\uC740 \uD655\uC778 \uBD88\uAC00\uC785\uB2C8\uB2E4. \uC0AC\uC774\uD2B8\uAC00 \uC81C\uACF5\uD55C \uAE30\uB2A5\uBCC4 \uC794\uC5EC \uC218\uCE58\uAC00 \uC788\uC744 \uB54C\uB9CC \uD45C\uC2DC\uD569\uB2C8\uB2E4.",
    chatgpt_quota_absent: "\uC0AC\uC774\uD2B8 \uC751\uB2F5\uC5D0 \uD45C\uC2DC\uD560 \uC794\uC5EC \uC0AC\uC6A9\uB7C9\uC774 \uC5C6\uC2B5\uB2C8\uB2E4. \uBAA8\uB378\uBCC4 \uC0AC\uC6A9\uB960\uC740 \uD655\uC778 \uBD88\uAC00\uC785\uB2C8\uB2E4."
  };

  // src/storage/snapshots.ts
  var FRESH_MS = 10 * 6e4;
  function emptySnapshot(provider) {
    return { provider, state: "error", limits: [], collectedAt: null, checkedAt: null, nextAttemptAt: 0, failures: 0, errorCode: provider === "chatgpt" ? "chatgpt_usage_pending" : "not_collected" };
  }
  function validLimits(input) {
    return Array.isArray(input) && input.length <= 150 && input.every((x) => {
      const r = record(x);
      return r && typeof r.id === "string" && r.id.length > 0 && r.id.length <= 200 && label(r.label) && ["window", "model", "product"].includes(String(r.category)) && r.source === "api" && (r.percent === null || percent(r.percent) !== null) && (r.resetsAt === null || resetTime(r.resetsAt) !== null) && (r.windowSeconds === null || nonnegative(r.windowSeconds) !== null) && (r.remaining === null || nonnegative(r.remaining) !== null) && (r.unit === null || label(r.unit));
    }) && new Set(input.map((x) => x.id)).size === input.length;
  }
  function parseSnapshot(input, provider) {
    const r = record(input);
    if (!r || r.provider !== provider || !["ok", "stale", "signed_out", "permission_required", "rate_limited", "unsupported", "error"].includes(String(r.state)) || !validLimits(r.limits) || !(r.collectedAt === null || finite(r.collectedAt)) || !(r.checkedAt === null || finite(r.checkedAt)) || !finite(r.nextAttemptAt) || !finite(r.failures) || !(r.errorCode === null || typeof r.errorCode === "string" && Object.hasOwn(ERROR_TEXT, r.errorCode))) return emptySnapshot(provider);
    if (r.state === "ok" && (r.collectedAt === null || r.limits.length === 0)) return emptySnapshot(provider);
    return { provider, state: r.state, limits: r.limits, collectedAt: r.collectedAt, checkedAt: r.checkedAt, nextAttemptAt: Math.max(0, r.nextAttemptAt), failures: Math.max(0, r.failures), errorCode: r.errorCode };
  }
  function effectiveSnapshot(snapshot, now = Date.now()) {
    return snapshot.state === "ok" && (snapshot.collectedAt === null || now - snapshot.collectedAt >= FRESH_MS || snapshot.collectedAt > now + 6e4) ? { ...snapshot, state: "stale" } : snapshot;
  }

  // src/shared/display-policy.ts
  var displayProvider = (page) => page === "chatgpt" ? "work_codex" : page;
  function shouldShowStrip(view, page) {
    const source = displayProvider(page);
    return view.permissions[source] && view.settings.enabled[source] && view.settings.strips[page];
  }
  function needsContent(view, pages) {
    const observeChatGPT = pages.includes("chatgpt") && view.permissions.chatgpt && view.settings.enabled.chatgpt;
    return observeChatGPT || pages.some((page) => shouldShowStrip(view, page));
  }
  var canRefreshFromPage = (page, source) => page === source || displayProvider(page) === source;

  // src/shared/contracts.ts
  function isReply(input) {
    const r = record(input), view = record(r?.view);
    if (r?.ok !== true || !view || !isSettings(view.settings)) return false;
    return ["chatgpt", "work_codex", "claude"].every((p) => {
      const raw = record(record(view.snapshots)?.[p]);
      if (!raw || typeof record(view.permissions)?.[p] !== "boolean") return false;
      const clean = parseSnapshot(raw, p);
      return JSON.stringify(clean) === JSON.stringify(raw);
    });
  }
  async function request(message) {
    const reply = await chrome.runtime.sendMessage(message);
    if (!isReply(reply)) throw new Error("invalid_extension_response");
    return reply.view;
  }

  // src/background/badge.ts
  init_types();

  // src/shared/usage-selection.ts
  function highestUsageLimit(limits) {
    let highest = null;
    let highestPercent = -1;
    for (const limit of limits) {
      const used = percent(limit.percent);
      if (used !== null && used > highestPercent) {
        highest = limit;
        highestPercent = used;
      }
    }
    return highest;
  }

  // src/shared/format.ts
  var DAYS = ["\uC77C", "\uC6D4", "\uD654", "\uC218", "\uBAA9", "\uAE08", "\uD1A0"];
  var twoDigits = (value) => String(value).padStart(2, "0");
  function resetValue(value, now) {
    const reset = resetTime(value);
    if (reset === null) return "\uD655\uC778 \uBD88\uAC00";
    const at = new Date(reset);
    const local = `${at.getMonth() + 1}/${at.getDate()}(${DAYS[at.getDay()]}) ${twoDigits(at.getHours())}:${twoDigits(at.getMinutes())}`;
    const remaining = at.getTime() - now;
    if (!Number.isFinite(remaining)) return `${local}, \uB0A8\uC740 \uC2DC\uAC04 \uD655\uC778 \uBD88\uAC00`;
    if (remaining <= 0) return `${local}, \uCD08\uAE30\uD654 \uC2DC\uAC01 \uC9C0\uB0A8 \xB7 \uAC31\uC2E0 \uD544\uC694`;
    const hours = Math.floor(remaining / 36e5), days = Math.floor(hours / 24);
    return `${local}, ${days > 0 ? `${days}d ` : ""}${hours % 24}h \uB0A8\uC74C`;
  }
  var resetLabel = (reset, now = Date.now()) => `\u{1F552} \uC0AC\uC6A9\uB7C9 \uCD08\uAE30\uD654: ${resetValue(reset, now)}`;
  function usagePercentLabel(value) {
    const used = percent(value);
    return `\uC0AC\uC6A9\uB7C9: ${used === null ? "\uD655\uC778 \uBD88\uAC00" : `${Math.round(used)}%`}`;
  }
  function statusText(snapshot) {
    if (snapshot.state === "ok") return "\uCD5C\uADFC \uC218\uC9D1 \uC131\uACF5";
    if (snapshot.state === "stale") return "\uC624\uB798\uB41C \uC815\uBCF4 \xB7 \uAC31\uC2E0 \uD544\uC694";
    return snapshot.errorCode ? ERROR_TEXT[snapshot.errorCode] : "\uD655\uC778 \uBD88\uAC00";
  }

  // src/background/badge.ts
  function selectedLimit(snapshot, _settings) {
    return highestUsageLimit(snapshot.limits);
  }

  // src/content/usage-label.ts
  function usageParts(snapshot, limit, now = Date.now()) {
    const currentData = snapshot.state === "ok";
    const used = currentData ? percent(limit?.percent) : null;
    const current = usagePercentLabel(used);
    const reset = resetLabel(currentData ? limit?.resetsAt : null, now);
    const status = currentData ? null : statusText(snapshot);
    return { current, reset, status, percent: used, label: [current, reset, status].filter((value) => value !== null).join("  ") };
  }

  // src/content/selectors.ts
  var EDITABLE = "[contenteditable],textarea";
  var COMPOSER = 'form[data-chatgpt-composer],form[data-type="unified-composer"],[data-testid="codex-composer"],[data-testid="composer"]';
  var EXPLICIT_INPUT = `#prompt-textarea,${COMPOSER.split(",").flatMap((container) => [`${container} textarea`, `${container} [contenteditable]`]).join(",")}`;
  var OWN_UI = "#ai-gauge-usage-strip";
  var EXCLUDED = `[hidden],[inert],[aria-hidden="true"],dialog,[role="dialog"],[role="search"],nav,[data-message-author-role],[data-testid="user-message"],[data-testid^="conversation-turn-"],${OWN_UI}`;
  var SHELL = 'html,body,main,[role="main"],[role="application"],article,aside';
  var UNRELATED_REGION = 'main,[role="main"],[role="application"],article,aside,nav,header,[role="search"],[data-message-author-role],[data-testid="user-message"],[data-testid^="conversation-turn-"]';
  var STOP = 'button[data-testid="stop-button"],button[aria-label="Stop response" i],button[aria-label="\uC751\uB2F5 \uC911\uC9C0"]';
  var CLAUDE_STOP = `${STOP},button[data-testid="stop-response-button"],button[aria-label="Stop generating" i],button[aria-label="Stop generation" i],button[aria-label="\uC0DD\uC131 \uC911\uC9C0"]`;
  var SELECTORS = {
    chatgpt: { input: "#prompt-textarea", stop: STOP },
    work_codex: { input: EDITABLE, stop: STOP },
    claude: { input: EDITABLE, stop: CLAUDE_STOP }
  };
  function visible(element) {
    if (!element.isConnected || element.closest(EXCLUDED)) return false;
    for (let node = element; node; node = node.parentElement) {
      const style = node.ownerDocument.defaultView?.getComputedStyle(node);
      if (style?.display === "none" || style?.visibility === "hidden" || style?.visibility === "collapse" || style?.contentVisibility === "hidden" || style?.opacity === "0") return false;
    }
    return true;
  }
  function hasStreamingControl(doc, provider) {
    return [...doc.querySelectorAll(SELECTORS[provider].stop)].some(visible);
  }
  function editingHost(element) {
    if (element.tagName === "TEXTAREA") return true;
    const value = element.getAttribute("contenteditable")?.toLowerCase();
    return value === "" || value === "true" || value === "plaintext-only";
  }
  function onScreen(element) {
    const doc = element.ownerDocument, win = doc.defaultView;
    if (!win || !doc.documentElement.getClientRects().length) return true;
    return [...element.getClientRects()].some((rect) => rect.width > 1 && rect.height > 1 && rect.bottom > 0 && rect.right > 0 && rect.top < win.innerHeight && rect.left < win.innerWidth);
  }
  function eligibleInput(input) {
    if (!editingHost(input) || !visible(input) || !onScreen(input) || input.matches(':disabled,[readonly],[aria-readonly="true"],[role="searchbox"]')) return false;
    const editableParent = input.parentElement?.closest("[contenteditable]");
    return !editableParent || !editingHost(editableParent);
  }
  function inputsInside(element) {
    return [...element.querySelectorAll(EDITABLE)].filter(eligibleInput);
  }
  function shell(element) {
    return element.matches(SHELL) || !!element.closest(EXCLUDED);
  }
  function onlyEditor(element, input) {
    const inputs = inputsInside(element);
    return inputs.length === 1 && inputs[0] === input;
  }
  function bounded(element, input) {
    return !shell(element) && !element.querySelector(UNRELATED_REGION) && onlyEditor(element, input);
  }
  function claudeInnerAnchor(input) {
    const surface = input.closest("div.bg-surface-3");
    if (!surface || !bounded(surface, input) || surface.closest("[contenteditable]")) return null;
    for (let anchor = input.parentElement; anchor && anchor !== surface; anchor = anchor.parentElement) {
      if (!anchor.matches("div.relative.w-full.min-w-0,div.relative.w-full.mni-w-0")) continue;
      const parent = anchor.parentElement;
      if (!parent || !surface.contains(parent) || parent.closest("[contenteditable]")) continue;
      const style = parent.ownerDocument.defaultView?.getComputedStyle(parent);
      const row = (style?.display === "flex" || style?.display === "inline-flex") && !style.flexDirection.startsWith("column");
      if (row || style?.display === "grid" || style?.display === "inline-grid" || style?.display === "contents") continue;
      if (bounded(anchor, input)) return anchor;
    }
    return null;
  }
  function composerBoundary(input, provider) {
    for (const declared of [input.closest(COMPOSER), input.closest("form"), input.closest("fieldset")]) {
      if (declared && bounded(declared, input)) return declared;
    }
    if (provider === "chatgpt") return null;
    let branch = input;
    while (branch.parentElement) {
      const parent = branch.parentElement;
      if (!bounded(parent, input)) return null;
      const controls = [...parent.querySelectorAll('button,[role="button"],[role="toolbar"]')].filter((control) => !branch.contains(control) && visible(control));
      if (controls.length > 0) return parent;
      branch = parent;
    }
    return null;
  }
  function painted(style) {
    if (!style) return false;
    const border = [style.borderTopWidth, style.borderBottomWidth, style.borderLeftWidth, style.borderRightWidth].some((width) => Number.parseFloat(width) > 0);
    const shadow = !!style.boxShadow && style.boxShadow !== "none";
    const roundedBackground = Number.parseFloat(style.borderRadius) > 0 && !!style.backgroundColor && !["transparent", "rgba(0, 0, 0, 0)"].includes(style.backgroundColor);
    return border || shadow || roundedBackground;
  }
  function compactWrapper(parent, children, style) {
    if (!parent.ownerDocument.documentElement.getClientRects().length) return true;
    const parentRect = parent.getBoundingClientRect();
    const boxes = children.map((child) => child.getBoundingClientRect()).filter((box) => box.height > 0 && box.width > 0);
    if (!boxes.length || parentRect.height <= 0) return false;
    const contentHeight = Math.max(...boxes.map((box) => box.bottom)) - Math.min(...boxes.map((box) => box.top));
    const insets = [style?.paddingTop, style?.paddingBottom, style?.borderTopWidth, style?.borderBottomWidth].reduce((sum, value) => sum + (Number.parseFloat(value ?? "") || 0), 0);
    return parentRect.height <= contentHeight + insets + 2;
  }
  function outsideLayout(boundary, input) {
    let anchor = boundary;
    while (anchor.parentElement) {
      const parent = anchor.parentElement;
      if (parent.closest("[contenteditable]")) return null;
      const style = parent.ownerDocument.defaultView?.getComputedStyle(parent);
      const isRow = (style?.display === "flex" || style?.display === "inline-flex") && !style.flexDirection.startsWith("column");
      const grid = style?.display === "grid" || style?.display === "inline-grid";
      const constrained = isRow || grid || ["hidden", "clip"].includes(style?.overflowY ?? "") || ["hidden", "clip"].includes(style?.overflow ?? "");
      const contents = style?.display === "contents";
      if (shell(parent) || !onlyEditor(parent, input) || parent.querySelector(UNRELATED_REGION)) {
        return constrained || contents ? null : anchor;
      }
      const children = [...parent.children].filter((child) => !child.matches(OWN_UI) && visible(child));
      const singlePaintedWrapper = children.length === 1 && children[0] === anchor && painted(style);
      if (contents || (constrained || singlePaintedWrapper) && children.length <= 4 && compactWrapper(parent, children, style)) {
        anchor = parent;
        continue;
      }
      return constrained ? null : anchor;
    }
    return null;
  }
  function codexFooters(doc) {
    const prefix = "ComposerLayoutFooter-";
    return [...doc.querySelectorAll('div[class*="ComposerLayoutFooter-"]')].filter((footer) => [...footer.classList].some((token) => token.startsWith(prefix) && token.length > prefix.length) && visible(footer) && onScreen(footer) && !footer.closest("[contenteditable]") && !footer.querySelector(UNRELATED_REGION));
  }
  function hasCodexFooter(doc) {
    return codexFooters(doc).length > 0;
  }
  function codexFooterTargets(doc) {
    const footers = codexFooters(doc);
    return footers.map((anchor) => {
      let input = null;
      for (let scope = anchor; scope && !scope.matches("html,body"); scope = scope.parentElement) {
        if (scope.closest(EXCLUDED) || scope.querySelector(UNRELATED_REGION)) break;
        if (footers.filter((footer) => scope.contains(footer)).length !== 1) break;
        const inputs = inputsInside(scope);
        if (inputs.length === 1) {
          input = inputs[0];
          break;
        }
        if (inputs.length > 1) break;
      }
      return { input, anchor, placement: "append" };
    });
  }
  function preferredCodexFooter(targets, doc) {
    if (targets.length === 1) return targets[0];
    const focused = targets.filter(({ input, anchor }) => anchor.contains(doc.activeElement) || input === doc.activeElement || !!input?.contains(doc.activeElement));
    if (focused.length === 1) return focused[0];
    const associated = targets.filter(({ input }) => input !== null);
    return associated.length === 1 ? associated[0] : null;
  }
  function findComposerTarget(doc, provider) {
    if (provider === "work_codex") {
      const footers = codexFooterTargets(doc);
      if (footers.length) return preferredCodexFooter(footers, doc);
    }
    const selector = provider === "chatgpt" ? EXPLICIT_INPUT : SELECTORS[provider].input;
    const targets = [];
    for (const input of doc.querySelectorAll(selector)) {
      if (!eligibleInput(input)) continue;
      const inner = provider === "claude" ? claudeInnerAnchor(input) : null;
      const boundary = composerBoundary(input, provider);
      const anchor = inner ?? (boundary && outsideLayout(boundary, input));
      if (anchor) targets.push({ input, anchor });
    }
    if (targets.length === 1) return targets[0];
    const focused = targets.filter(({ input }) => input === doc.activeElement || !!input?.contains(doc.activeElement));
    if (focused.length === 1) return focused[0];
    const explicit = targets.filter(({ input }) => input?.matches(EXPLICIT_INPUT));
    return explicit.length === 1 ? explicit[0] : null;
  }

  // src/shared/icon.ts
  var ICON_DATA_URL = false ? "" : "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABQAAAAUCAYAAACNiR0NAAAD2klEQVR4nK1Uf0yUdRj/fL/vez849CAwylZ6pKkRLTFc0A/IwLaykhzgkJoMYau5ajSafzR3hwuXlivm5sxy6VaLHS3QOd0IO1FLSHDFBDPGhDT50QncXXfC3fu+n/44joaR9EfPX8/3eT57ns/z4/sA/7OIf3dRFLkh04ogHgIIAN2I6sWAASH4n7O4SWUujNPjUWcjNNNACgIQQhCgpeoHrDHdZTyhm41UCCkVHdfUMaO9d5/a0nBA+CAAGBSzs3VSxtS327WK7V790tYwuSFM5oyR2cPkmnFyY5B8a1S7+m5vuBpwSgBwu93TFYkYMyEFEwtHE17flXAomCoLzg0B3Ve0cDAgzdAlEATgB4BI5J5UqeZkKmKxT2/2+pSSg+liNBqKEFNlipStsJVt05sHFinZx77XQqGgarPbgUST3meV6IOG8M0AHAEv0sevK4AWvrm+xBy32hv5tvJE+Tumtbb+pMwDvukBvNGjuV/SSDRqf5q/Ix+4pJ8pGOazJK1yqhSSsng8vHpV++RRRxP56meDExcb3tf1jhLDtzsve7p9FWciL28Kk7IxErIcJx/u1feTf/cUpET0PT3E/UfOfjzYsj3CtpWhruYGlp5lRQytVF6NnF98kTq+JJd0aceVqSHleqiCFHBSut1uBTIaL7C3rIg/l13mhaf4dfUeLeMgjeLL2q9ZexiHypPhxwtGNF00asYdrXpo4ziXAAJF7tguUsZoXQGskSOvfWB0bSZPpHG09rGPUg5xALs05vYYLO+IrFPN98l8LxTJBcDCJL3FnSj64KbSUCx0AFAgDP0rOo6d3pHqKOzbAfu1J9HZhmCvWpe0s6fK8ePkfCEtW24YwLJE+YwqrUwbJbR4B3A/jY4eUjwKyE7S8ACWFz+f+LRyuKNw3aZhK66fAzoGoAXsh+ftHKxyOl3yZLzs+i0d2mQ8YDNxhUymsGSkQM27F+pyyiEIwXmn+hUhBJ/bO1adv9T6yoKnM00HvlkURr9fn/Dd2aq+t6HSw1NKTU2NsdQkvfkZUHMdUO8mFNU/pG1bYVE6Q5N60Nyt1ANA677zEQAwBfxrfx9PiDR9coFxpwNcVVqO2lBWbxPWR5zFY2YAsP1042iWNfnN+SoSRga0hn9+QQBwelQAsNcN1S3c7Wd8acvk8g9/Cb9Q56daO1BFQMQwt4pwOinhggSAGkCHEAQpAGBZAMn+L0bqbdTyrPEW4w+Y6p/fbN9y2OUKw+Vi9ChQOInoRrhgzM4wui4CAKQCrGzjIzmdfHDOmzanTDGdmeRW20y5rTOGcU4FrhHidiUBAP4CLW/g2Ciadq4AAAAASUVORK5CYII=";

  // src/content/usage-strip.ts
  var UsageStrip = class {
    constructor(provider, doc) {
      this.provider = provider;
      this.doc = doc;
    }
    host = null;
    view = null;
    target = null;
    footerLayout = null;
    update(view) {
      this.view = view;
      this.mount();
    }
    mount() {
      const view = this.view, p = this.provider;
      if (!view || !shouldShowStrip(view, p)) {
        this.remove();
        return;
      }
      if ([...this.doc.querySelectorAll("#ai-gauge-usage-strip")].some((node) => node !== this.host)) {
        this.remove();
        return;
      }
      const next = findComposerTarget(this.doc, p);
      if (next) this.target = next;
      else if (!this.target || !this.target.anchor.isConnected || this.hidden(this.target.anchor) || this.target.input && (!this.target.input.isConnected || this.hidden(this.target.input) || this.target.placement !== "append" && !this.target.anchor.contains(this.target.input))) {
        this.remove();
        return;
      }
      const anchor = this.target.anchor;
      if (!this.host) {
        this.host = this.doc.createElement("div");
        this.host.id = "ai-gauge-usage-strip";
        this.host.dataset.aiGaugeOwned = "usage-strip";
        const root = this.host.attachShadow({ mode: "closed" });
        const style = this.doc.createElement("style");
        style.textContent = ":host{display:block;position:static;box-sizing:border-box;width:100%;min-width:0;max-width:100%;flex:0 0 auto;align-self:stretch;grid-column:1/-1;margin:6px 0;border:0;background:transparent;font:12px/1.5 system-ui;color:inherit;}.usage{display:flex;align-items:center;flex-wrap:wrap;gap:4px 14px;box-sizing:border-box;padding:6px 10px;border:0;background:transparent;overflow-wrap:anywhere}.current{display:inline-flex;align-items:center;flex-wrap:wrap;gap:6px;min-width:0;max-width:100%}.current>span,.reset,.status{color:inherit;opacity:.8}.reset,.status{min-width:0;max-width:100%}progress{appearance:none;-webkit-appearance:none;width:80px;max-width:100%;height:6px;flex:0 0 80px;box-sizing:border-box;border:0;border-radius:999px;overflow:hidden;background:#8893a033;color:inherit;accent-color:currentColor}progress::-webkit-progress-bar{background:#8893a033;border-radius:999px}progress::-webkit-progress-value{background:currentColor;border-radius:999px}progress::-moz-progress-bar{background:currentColor;border-radius:999px}[hidden]{display:none!important}";
        const row = this.doc.createElement("div");
        row.className = "usage";
        row.setAttribute("role", "status");
        row.setAttribute("aria-live", "polite");
        row.setAttribute("aria-atomic", "true");
        const current = this.doc.createElement("span");
        current.className = "current";
        this.currentText = this.doc.createElement("span");
        this.progress = this.doc.createElement("progress");
        this.progress.max = 100;
        this.progress.hidden = true;
        this.progress.setAttribute("aria-label", "\uC0AC\uC6A9\uB7C9");
        current.append(this.currentText, this.progress);
        if (ICON_DATA_URL) {
          const icon = this.doc.createElement("img");
          icon.src = ICON_DATA_URL;
          icon.alt = "";
          icon.width = 20;
          icon.height = 20;
          icon.draggable = false;
          icon.className = "brand-icon";
          icon.style.cssText = "width:20px;height:20px;flex:0 0 20px;object-fit:contain";
          icon.setAttribute("aria-hidden", "true");
          current.prepend(icon);
        }
        this.resetText = this.doc.createElement("span");
        this.resetText.className = "reset";
        this.statusText = this.doc.createElement("span");
        this.statusText.className = "status";
        this.statusText.hidden = true;
        row.append(current, this.resetText, this.statusText);
        root.append(style, row);
      }
      this.prepareFooterLayout(this.target);
      if (this.target.placement === "append") {
        if (anchor.lastChild !== this.host) anchor.append(this.host);
      } else if (anchor.nextElementSibling !== this.host) anchor.after(this.host);
      const snapshot = effectiveSnapshot(view.snapshots[displayProvider(p)]), limit = selectedLimit(snapshot, view.settings) ?? snapshot.limits[0];
      const parts = usageParts(snapshot, limit);
      if (this.currentText.textContent !== parts.current) this.currentText.textContent = parts.current;
      if (this.resetText.textContent !== parts.reset) this.resetText.textContent = parts.reset;
      const status = parts.status ?? "";
      if (this.statusText.textContent !== status) this.statusText.textContent = status;
      if (this.statusText.hidden !== (parts.status === null)) this.statusText.hidden = parts.status === null;
      if (this.progress.hidden !== (parts.percent === null)) this.progress.hidden = parts.percent === null;
      if (parts.percent === null) {
        if (this.progress.hasAttribute("value")) this.progress.removeAttribute("value");
      } else if (this.progress.getAttribute("value") !== String(parts.percent)) this.progress.setAttribute("value", String(parts.percent));
      if (this.host.getAttribute("aria-label") !== parts.label) this.host.setAttribute("aria-label", parts.label);
    }
    prepareFooterLayout(target) {
      const style = this.doc.defaultView?.getComputedStyle(target.anchor);
      const row = this.provider === "work_codex" && target.placement === "append" && (style?.display === "flex" || style?.display === "inline-flex") && !style.flexDirection.startsWith("column");
      if (this.footerLayout && (this.footerLayout.element !== target.anchor || !row)) this.restoreFooterLayout();
      const basis = row ? "100%" : "";
      if (this.host.style.flexBasis !== basis) {
        if (basis) this.host.style.setProperty("flex-basis", basis);
        else this.host.style.removeProperty("flex-basis");
      }
      if (!row) return;
      const inline = target.anchor.style;
      if (this.footerLayout) {
        if (inline.getPropertyValue("flex-wrap") !== "wrap" || inline.getPropertyPriority("flex-wrap") !== this.footerLayout.appliedPriority) this.footerLayout.owned = false;
        return;
      }
      if (style.flexWrap && style.flexWrap !== "nowrap") return;
      const value = inline.getPropertyValue("flex-wrap"), priority = inline.getPropertyPriority("flex-wrap");
      inline.setProperty("flex-wrap", "wrap", priority);
      if (this.doc.defaultView?.getComputedStyle(target.anchor).flexWrap !== "wrap") inline.setProperty("flex-wrap", "wrap", "important");
      this.footerLayout = { element: target.anchor, value, priority, appliedPriority: inline.getPropertyPriority("flex-wrap"), owned: true };
    }
    restoreFooterLayout() {
      const previous = this.footerLayout;
      if (!previous) return;
      const inline = previous.element.style;
      if (previous.owned && inline.getPropertyValue("flex-wrap") === "wrap" && inline.getPropertyPriority("flex-wrap") === previous.appliedPriority) {
        if (previous.value) inline.setProperty("flex-wrap", previous.value, previous.priority);
        else inline.removeProperty("flex-wrap");
      }
      this.footerLayout = null;
    }
    hidden(input) {
      if (input.closest('[hidden],[inert],[aria-hidden="true"]')) return true;
      for (let node = input; node; node = node.parentElement) {
        const style = this.doc.defaultView?.getComputedStyle(node);
        if (style?.display === "none" || style?.visibility === "hidden" || style?.visibility === "collapse") return true;
      }
      return false;
    }
    currentText = null;
    resetText = null;
    statusText = null;
    progress = null;
    remove() {
      this.restoreFooterLayout();
      this.host?.remove();
      this.host = null;
      this.target = null;
      this.currentText = null;
      this.resetText = null;
      this.statusText = null;
      this.progress = null;
    }
  };

  // src/content/display-diagnostics.ts
  function authorizedDisplayRequest(message, sender, extensionId) {
    return sender.id === extensionId && !sender.tab && sender.url === `chrome-extension://${extensionId}/popup.html` && typeof message === "object" && message !== null && Object.keys(message).length === 1 && "type" in message && message.type === "display-diagnostics";
  }
  function visible2(element) {
    if (!element.isConnected || element.closest('[hidden],[inert],[aria-hidden="true"]')) return false;
    const win = element.ownerDocument.defaultView;
    if (!win) return false;
    for (let node = element; node; node = node.parentElement) {
      const style = win.getComputedStyle(node);
      if (style.display === "none" || style.visibility === "hidden" || style.visibility === "collapse" || style.contentVisibility === "hidden" || style.opacity === "0") return false;
    }
    return [...element.getClientRects()].some((box) => box.width > 1 && box.height > 1 && box.right > 0 && box.bottom > 0 && box.left < win.innerWidth && box.top < win.innerHeight);
  }
  function createDisplayDiagnostic(doc, provider) {
    const strips = [...doc.querySelectorAll("#ai-gauge-usage-strip")];
    return {
      status: "ready",
      provider,
      contentReady: true,
      editableCount: Math.min(1e4, doc.querySelectorAll("[contenteditable],textarea").length),
      iframeCount: Math.min(1e4, doc.querySelectorAll("iframe").length),
      targetFound: findComposerTarget(doc, provider) !== null,
      stripCount: Math.min(1e4, strips.length),
      stripVisible: strips.some(visible2)
    };
  }

  // src/content/page-provider.ts
  init_types();
  function resolvePageProvider(doc, url) {
    const provider = providerFromUrl(url);
    return provider === "chatgpt" && hasCodexFooter(doc) ? "work_codex" : provider;
  }

  // src/shared/build-mode.ts
  var DEVELOPMENT = true;

  // src/content/index.ts
  if (resolvePageProvider(document, location.href) && !window.__aiGaugeMounted) {
    window.__aiGaugeMounted = true;
    let provider = null, strip = null, view = null;
    let stopped = false, timer = null, wasStreaming = false, lastSignal = 0, pending = false, loadAgain = false;
    const refreshQueue = /* @__PURE__ */ new Set();
    let quotaTimer = null;
    let quotaInitialCheck = false;
    let viewRetryTimer = null, viewFailures = 0;
    let completionTimer = null, completionProvider = null;
    let routeUrl = null;
    const clearCompletion = () => {
      if (completionTimer) clearTimeout(completionTimer);
      completionTimer = null;
      completionProvider = null;
    };
    const stopQuotaObserver = () => {
      if (provider !== "claude") document.dispatchEvent(new Event("ai-gauge-chatgpt-stop"));
    };
    const route = () => {
      const next = resolvePageProvider(document, location.href);
      const navigated = routeUrl !== null && routeUrl !== location.href;
      routeUrl = location.href;
      if (navigated || next !== provider) clearCompletion();
      if (next === provider) {
        if (navigated) wasStreaming = next ? hasStreamingControl(document, next) : false;
        return navigated;
      }
      strip?.remove();
      provider = next;
      strip = next ? new UsageStrip(next, document) : null;
      wasStreaming = next ? hasStreamingControl(document, next) : false;
      if (view) strip?.update(view);
      return true;
    };
    const stop = () => {
      stopped = true;
      window.__aiGaugeMounted = false;
      strip?.remove();
      observer.disconnect();
      if (timer) clearTimeout(timer);
      if (viewRetryTimer) clearTimeout(viewRetryTimer);
      clearCompletion();
      stopQuotaObserver();
      if (quotaTimer) clearTimeout(quotaTimer);
      document.removeEventListener("ai-gauge-chatgpt-quota", onQuota);
      document.removeEventListener("focusin", scheduleCheck);
      document.removeEventListener("visibilitychange", onVisible);
      window.removeEventListener("popstate", onRoute);
      chrome.runtime.onMessage.removeListener(onMessage);
      chrome.storage.onChanged.removeListener(onStorage);
    };
    const scheduleCompletion = () => {
      if (stopped || !completionProvider || !view) return;
      const source = completionProvider, snapshot = view.snapshots[source];
      if (!view.settings.enabled[source] || !view.permissions[source] || ["signed_out", "permission_required", "unsupported"].includes(snapshot.state)) {
        clearCompletion();
        return;
      }
      const earliest = Math.max(snapshot.nextAttemptAt, snapshot.checkedAt === null ? 0 : snapshot.checkedAt + 6e4, lastSignal + 6e4);
      const delay = earliest - Date.now();
      if (completionTimer) {
        clearTimeout(completionTimer);
        completionTimer = null;
      }
      if (delay > 0) completionTimer = setTimeout(() => {
        completionTimer = null;
        scheduleCompletion();
      }, Math.min(delay + 100, 2147483647));
      else {
        completionProvider = null;
        lastSignal = Date.now();
        void load(source);
      }
    };
    const load = async (refresh) => {
      if (stopped) return;
      if (pending) {
        loadAgain = true;
        if (refresh) refreshQueue.add(refresh);
        return;
      }
      route();
      if (!provider) return;
      const current = provider;
      pending = true;
      try {
        const nextView = await request(refresh && canRefreshFromPage(current, refresh) ? { type: "refresh", provider: refresh, trigger: "event" } : { type: "view" });
        if (stopped) return;
        view = nextView;
        viewFailures = 0;
        if (viewRetryTimer) {
          clearTimeout(viewRetryTimer);
          viewRetryTimer = null;
        }
        route();
        strip?.update(view);
        if (provider === "chatgpt" && view.permissions.chatgpt && view.settings.enabled.chatgpt && !quotaInitialCheck) {
          quotaInitialCheck = true;
          if (!quotaTimer) quotaTimer = setTimeout(() => {
            quotaTimer = null;
            void load("chatgpt");
          }, 60100);
        }
        if (!view.permissions.chatgpt || !view.settings.enabled.chatgpt) stopQuotaObserver();
        const group = SITE_GROUPS.find((g) => g.providers.includes(current));
        if (!view.permissions[current] || !group || !needsContent(view, group.providers)) stop();
        else scheduleCompletion();
      } catch {
        if (stopped) return;
        let live = false;
        try {
          live = Boolean(chrome.runtime.id);
        } catch {
        }
        if (!live) stop();
        else {
          strip?.mount();
          viewFailures++;
          if (!viewRetryTimer) viewRetryTimer = setTimeout(() => {
            viewRetryTimer = null;
            void load();
          }, Math.min(3e4, 1e3 * 2 ** Math.min(viewFailures - 1, 5)));
        }
      } finally {
        pending = false;
        if (!stopped && (loadAgain || refreshQueue.size)) {
          loadAgain = false;
          const next = refreshQueue.values().next().value;
          if (next) refreshQueue.delete(next);
          void load(next);
        }
      }
    };
    const check = () => {
      timer = null;
      if (stopped) return;
      const changed = route();
      strip?.mount();
      if (!provider) return;
      if (changed) void load(displayProvider(provider));
      const streaming = hasStreamingControl(document, provider);
      if (wasStreaming && !streaming) {
        completionProvider = displayProvider(provider);
        scheduleCompletion();
      }
      wasStreaming = streaming;
    };
    const scheduleCheck = () => {
      if (!timer && !stopped) timer = setTimeout(check, 300);
    };
    const ownNode = (node) => {
      const element = node.nodeType === Node.ELEMENT_NODE ? node : node.parentElement;
      return !!element?.closest("#ai-gauge-usage-strip");
    };
    const observer = new MutationObserver((records) => {
      if (stopped) return;
      const externalChange = records.some((record2) => {
        if (ownNode(record2.target)) return false;
        const changed = [...record2.addedNodes, ...record2.removedNodes];
        return record2.type !== "childList" || changed.length === 0 || changed.some((node) => !ownNode(node)) || [...record2.removedNodes].some((node) => !node.isConnected);
      });
      if (externalChange) {
        if (provider && hasStreamingControl(document, provider)) wasStreaming = true;
        scheduleCheck();
      }
    });
    observer.observe(document, {
      childList: true,
      subtree: true,
      attributes: true,
      attributeFilter: ["hidden", "aria-hidden", "inert", "style", "class", "contenteditable", "aria-label", "data-testid"]
    });
    const onMessage = (message, sender, sendResponse) => {
      if (DEVELOPMENT && authorizedDisplayRequest(message, sender, chrome.runtime.id)) {
        const current = resolvePageProvider(document, location.href);
        if (!stopped && current) sendResponse?.(createDisplayDiagnostic(document, current));
        return;
      }
      if (sender.id !== chrome.runtime.id || typeof message !== "object" || message === null || !("type" in message)) return;
      if (message.type === "permissions-revoked" && "origins" in message && Array.isArray(message.origins)) {
        const origin = SITE_GROUPS.find((site) => provider && site.providers.includes(provider))?.origin;
        if (origin && message.origins.includes(origin)) stop();
      } else if (message.type === "invalidate") void load();
    };
    const onStorage = () => {
      void load();
    };
    const onVisible = () => {
      if (document.visibilityState === "visible") {
        check();
        void load(provider ? displayProvider(provider) : void 0);
      }
    };
    const onRoute = () => {
      check();
    };
    const onQuota = () => {
      if (provider !== "chatgpt" || !view?.settings.enabled.chatgpt || !view.permissions.chatgpt) return;
      void load("chatgpt");
      if (!quotaTimer) quotaTimer = setTimeout(() => {
        quotaTimer = null;
        void load("chatgpt");
      }, 60100);
    };
    chrome.runtime.onMessage.addListener(onMessage);
    chrome.storage.onChanged.addListener(onStorage);
    document.addEventListener("focusin", scheduleCheck);
    document.addEventListener("visibilitychange", onVisible);
    window.addEventListener("popstate", onRoute);
    document.addEventListener("ai-gauge-chatgpt-quota", onQuota);
    void load();
  }
})();
