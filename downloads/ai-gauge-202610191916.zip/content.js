"use strict";
(() => {
  // src/shared/types.ts
  var PROVIDERS = ["chatgpt", "claude", "gemini"];
  var PAGE_PROVIDERS = ["chatgpt", "codex", "claude", "gemini"];
  var ORIGINS = { chatgpt: "https://chatgpt.com/*", claude: "https://claude.ai/*", gemini: "https://gemini.google.com/*" };
  var GEMINI_RESPONSE_ERRORS = ["gemini_response_type", "gemini_response_read", "gemini_frame_invalid", "gemini_rpc_missing", "gemini_rpc_invalid", "gemini_quota_invalid"];
  var SITE_GROUPS = [
    { id: "openai", origin: ORIGINS.chatgpt, providers: ["chatgpt", "codex"] },
    { id: "claude", origin: ORIGINS.claude, providers: ["claude"] },
    { id: "gemini", origin: ORIGINS.gemini, providers: ["gemini"] }
  ];
  function providerFromUrl(url) {
    try {
      const u = new URL(url ?? "");
      if (u.protocol !== "https:") return null;
      if (u.hostname === "claude.ai") return "claude";
      if (u.hostname === "gemini.google.com") return "gemini";
      if (u.hostname === "chatgpt.com") return /^\/(codex|work)(?:\/|$)/.test(u.pathname) ? "codex" : "chatgpt";
      return null;
    } catch {
      return null;
    }
  }

  // src/shared/validation.ts
  function record(v) {
    return v !== null && typeof v === "object" && !Array.isArray(v) ? v : null;
  }
  var finite = (v) => typeof v === "number" && Number.isFinite(v);
  var percent = (v) => finite(v) && v >= 0 && v <= 100 ? v : null;
  var nonnegative = (v) => finite(v) && v >= 0 ? v : null;
  function label(v) {
    return typeof v === "string" && v.trim().length > 0 && v.length <= 120 && !/[\u0000-\u001f\u007f]/.test(v) ? v.trim() : null;
  }
  function resetTime(v) {
    if (typeof v !== "string") return null;
    const parts = /^(\d{4})-(\d{2})-(\d{2})T(\d{2}):(\d{2}):(\d{2})(?:\.\d+)?(?:Z|[+-]\d{2}:\d{2})$/.exec(v);
    if (!parts) return null;
    const [year, month, day, hour, minute, second] = parts.slice(1, 7).map(Number);
    if (month < 1 || month > 12 || day < 1 || day > new Date(Date.UTC(year, month, 0)).getUTCDate() || hour > 23 || minute > 59 || second > 59) return null;
    const ms = Date.parse(v);
    return Number.isFinite(ms) && ms > 0 && ms < 41024448e5 ? new Date(ms).toISOString() : null;
  }

  // src/storage/settings.ts
  var inRange = (value) => finite(value) && value >= 0 && value <= 100;
  function checkUsageThresholds(warning, danger) {
    const fields = ["warning", "danger"].filter((_, index) => !inRange(index === 0 ? warning : danger));
    if (fields.length) return { ok: false, reason: "range", fields };
    if (warning >= danger) return { ok: false, reason: "order", fields: ["warning", "danger"] };
    return { ok: true, value: { warning, danger } };
  }
  function parseUsageThresholds(warning, danger) {
    const result = checkUsageThresholds(warning, danger);
    return result.ok ? result.value : null;
  }
  function parseStrips(value) {
    const strips = record(value);
    return strips && Object.keys(strips).length === PAGE_PROVIDERS.length && PAGE_PROVIDERS.every((p) => typeof strips[p] === "boolean") ? Object.fromEntries(PAGE_PROVIDERS.map((p) => [p, strips[p]])) : null;
  }
  var isLanguagePreference = (value) => value === "system" || value === "en" || value === "ko";
  function isSettings(value) {
    const r = record(value), enabled = record(r?.enabled);
    return !!r && !!enabled && PROVIDERS.every((p) => typeof enabled[p] === "boolean") && isLanguagePreference(r.language) && parseStrips(r.strips) !== null && parseUsageThresholds(r.warning, r.danger) !== null;
  }

  // _locales/en/messages.json
  var messages_default = {
    badge_disabled: {
      message: "Disabled"
    },
    badge_permission_required: {
      message: "Permission required"
    },
    badge_usage_unknown: {
      message: "Usage unavailable"
    },
    diagnostics_checking_tab: {
      message: "Checking the display in the current tab."
    },
    diagnostics_copied: {
      message: "Diagnostics copied."
    },
    diagnostics_copy: {
      message: "Copy diagnostics"
    },
    diagnostics_copy_failed: {
      message: "Clipboard access was denied. The text is selected so you can copy it manually."
    },
    diagnostics_description: {
      message: "Shows the version, settings, errors, timestamps, and display target and element counts in the current tab. No input, account details, or URLs are included. Nothing is sent automatically."
    },
    diagnostics_not_ready: {
      message: "Status is not available yet. Please try again shortly."
    },
    diagnostics_output_label: {
      message: "Local diagnostics"
    },
    diagnostics_show: {
      message: "Show current status"
    },
    diagnostics_shown: {
      message: "Current status shown. Nothing is sent automatically."
    },
    diagnostics_title: {
      message: "Diagnostics"
    },
    error_access_denied: {
      message: "The site denied access. Security protections are not bypassed."
    },
    error_ambiguous_account: {
      message: "Multiple Claude organizations were found. Check usage settings in your account."
    },
    error_invalid_response: {
      message: "The usage response format could not be recognized."
    },
    error_network: {
      message: "The connection failed or the request timed out."
    },
    error_not_collected: {
      message: "Usage has not been collected yet."
    },
    error_open_tab: {
      message: "Open a signed-in service tab, then reopen the popup."
    },
    error_permission_required: {
      message: "Site access permission is required for this service."
    },
    error_rate_limited: {
      message: "Request limit reached. Please wait until the next retry."
    },
    error_server: {
      message: "The service returned an error. Another attempt will be made shortly."
    },
    error_signed_out: {
      message: "Sign in to the site, then reopen the popup."
    },
    error_tab_access_failed: {
      message: "Usage collection could not run in the open service tab. The last valid usage is kept while automatic retries continue."
    },
    error_unsupported: {
      message: "A safe collection method could not be verified. This service is unsupported."
    },
    extension_description: {
      message: "A local-only extension showing ChatGPT, Claude and Gemini usage and reset times."
    },
    format_duration_left: {
      message: "$1 left"
    },
    format_last_collected: {
      message: "Last successful collection: $1"
    },
    format_less_than_minute: {
      message: "in less than a minute"
    },
    format_not_collected: {
      message: "No successful collection yet"
    },
    format_relative_day_one: {
      message: "in $1 day"
    },
    format_relative_day_other: {
      message: "in $1 days"
    },
    format_relative_hour_one: {
      message: "in $1 hour"
    },
    format_relative_hour_other: {
      message: "in $1 hours"
    },
    format_relative_minute_one: {
      message: "in $1 minute"
    },
    format_relative_minute_other: {
      message: "in $1 minutes"
    },
    format_remaining: {
      message: "$1 remaining"
    },
    format_remaining_unknown: {
      message: "Time remaining unavailable"
    },
    format_reset_countdown: {
      message: "\u{1F552} Resets $1"
    },
    format_reset_pending: {
      message: "Checking after reset"
    },
    format_reset_popup: {
      message: "\u{1F552} Reset: $1"
    },
    format_reset_unavailable: {
      message: "\u{1F552} Reset: $1"
    },
    format_unknown: {
      message: "Unavailable"
    },
    format_usage: {
      message: "Usage: $1"
    },
    format_usage_name: {
      message: "Usage"
    },
    limit_additional: {
      message: "Additional limit"
    },
    limit_days_one: {
      message: "$1 day"
    },
    limit_days_other: {
      message: "$1 days"
    },
    limit_hours_one: {
      message: "$1 hour"
    },
    limit_hours_other: {
      message: "$1 hours"
    },
    limit_legacy_shared: {
      message: "Work / Codex shared"
    },
    limit_primary: {
      message: "Primary limit"
    },
    limit_weekly: {
      message: "Weekly"
    },
    popup_communication_failed: {
      message: "Cannot communicate with the extension. Please reload it."
    },
    popup_danger_threshold: {
      message: "Warning starts at"
    },
    popup_disable: {
      message: "Disable"
    },
    popup_disabled: {
      message: "Off"
    },
    popup_enable: {
      message: "Enable"
    },
    popup_grant_enable: {
      message: "Grant access and enable"
    },
    popup_language: {
      message: "Language"
    },
    popup_language_english: {
      message: "English"
    },
    popup_language_korean: {
      message: "Korean"
    },
    popup_language_system: {
      message: "System default"
    },
    popup_limit_previous_usage: {
      message: "$1 usage (previous value)"
    },
    popup_limit_usage: {
      message: "$1 usage"
    },
    popup_local_only: {
      message: "Local only"
    },
    popup_onboarding_description: {
      message: "Grant access to your selected services together to view usage."
    },
    popup_onboarding_start: {
      message: "Grant access and start"
    },
    popup_onboarding_title: {
      message: "Choose your services"
    },
    popup_open_site: {
      message: "Open $1 (new tab)"
    },
    popup_permission_canceled: {
      message: "Access request canceled."
    },
    popup_previous_usage: {
      message: "Previous usage"
    },
    popup_provider_plan: {
      message: "$1 plan: $2"
    },
    popup_provider_usage: {
      message: "$1 usage"
    },
    popup_revoke: {
      message: "Revoke access"
    },
    popup_settings: {
      message: "Settings"
    },
    popup_settings_saved: {
      message: "Settings saved."
    },
    popup_show_in_composer: {
      message: "Show below $1 input"
    },
    popup_threshold_order_error: {
      message: "The caution threshold must be lower than the warning threshold."
    },
    popup_threshold_range_error: {
      message: "Enter caution and warning thresholds between 0 and 100."
    },
    popup_usage_unavailable: {
      message: "Usage unavailable"
    },
    popup_warning_threshold: {
      message: "Caution starts at"
    },
    status_access_denied: {
      message: "Site access denied"
    },
    status_ambiguous_account: {
      message: "Select a Claude organization"
    },
    status_invalid_response: {
      message: "Usage unavailable"
    },
    status_network: {
      message: "Checking connection"
    },
    status_not_collected: {
      message: "Checking usage"
    },
    status_ok: {
      message: "Successfully collected"
    },
    status_open_tab: {
      message: "Open a service tab"
    },
    status_permission_required: {
      message: "Site permission required"
    },
    status_rate_limited: {
      message: "Check again shortly"
    },
    status_server: {
      message: "Waiting for service"
    },
    status_signed_out: {
      message: "Sign in required"
    },
    status_tab_access_failed: {
      message: "Rechecking usage"
    },
    status_unsupported: {
      message: "Usage collection unsupported"
    },
    ticket_availability_unknown: {
      message: "Availability unknown"
    },
    ticket_blocked: {
      message: "Currently restricted"
    },
    ticket_count_one: {
      message: "$1 ticket"
    },
    ticket_count_other: {
      message: "$1 tickets"
    },
    ticket_expiry: {
      message: "Expires $1"
    },
    ticket_inline: {
      message: "\u{1F3AB} Ticket expires $1"
    },
    ticket_kind_five_hour: {
      message: "5-hour limit"
    },
    ticket_kind_full: {
      message: "All limits"
    },
    ticket_kind_unspecified: {
      message: "Unknown type"
    },
    ticket_kind_weekly: {
      message: "Weekly limit"
    },
    ticket_management_action: {
      message: "Open official usage settings (new tab)"
    },
    ticket_other_first: {
      message: "Another ticket takes priority"
    },
    ticket_requires_limit: {
      message: "Limit must be reached"
    },
    ticket_starts: {
      message: "From $1"
    },
    ticket_total_one: {
      message: "\u{1F3AB} $1 reset ticket"
    },
    ticket_total_other: {
      message: "\u{1F3AB} $1 reset tickets"
    },
    ticket_unavailable_now: {
      message: "Not currently usable"
    }
  };

  // _locales/ko/messages.json
  var messages_default2 = {
    badge_disabled: {
      message: "\uBE44\uD65C\uC131"
    },
    badge_permission_required: {
      message: "\uAD8C\uD55C \uD544\uC694"
    },
    badge_usage_unknown: {
      message: "\uC0AC\uC6A9\uB960 \uD655\uC778 \uBD88\uAC00"
    },
    diagnostics_checking_tab: {
      message: "\uD604\uC7AC \uD0ED\uC758 \uD45C\uC2DC \uC0C1\uD0DC\uB97C \uD655\uC778\uD558\uACE0 \uC788\uC2B5\uB2C8\uB2E4."
    },
    diagnostics_copied: {
      message: "\uC9C4\uB2E8 \uC815\uBCF4\uB97C \uBCF5\uC0AC\uD588\uC2B5\uB2C8\uB2E4."
    },
    diagnostics_copy: {
      message: "\uC9C4\uB2E8 \uC815\uBCF4 \uBCF5\uC0AC"
    },
    diagnostics_copy_failed: {
      message: "\uC790\uB3D9 \uBCF5\uC0AC\uAC00 \uD5C8\uC6A9\uB418\uC9C0 \uC54A\uC544 \uB0B4\uC6A9\uC744 \uC120\uD0DD\uD588\uC2B5\uB2C8\uB2E4. \uC9C1\uC811 \uBCF5\uC0AC\uD574 \uC8FC\uC138\uC694."
    },
    diagnostics_description: {
      message: "\uBC84\uC804\xB7\uC124\uC815\xB7\uC624\uB958\xB7\uC2DC\uAC01\uACFC \uD604\uC7AC \uD0ED\uC758 \uD45C\uC2DC \uB300\uC0C1 \uBC1C\uACAC \uC5EC\uBD80\xB7\uC694\uC18C \uAC1C\uC218\uB9CC \uD655\uC778\uD569\uB2C8\uB2E4. \uC785\uB825 \uB0B4\uC6A9\xB7\uACC4\uC815\xB7URL\uC740 \uD3EC\uD568\uD558\uC9C0 \uC54A\uC73C\uBA70 \uC790\uB3D9\uC73C\uB85C \uC804\uC1A1\uB418\uC9C0 \uC54A\uC2B5\uB2C8\uB2E4."
    },
    diagnostics_not_ready: {
      message: "\uC0C1\uD0DC\uB97C \uC544\uC9C1 \uC77D\uC9C0 \uBABB\uD588\uC2B5\uB2C8\uB2E4. \uC7A0\uC2DC \uD6C4 \uB2E4\uC2DC \uB20C\uB7EC \uC8FC\uC138\uC694."
    },
    diagnostics_output_label: {
      message: "\uB85C\uCEEC \uC9C4\uB2E8 \uC815\uBCF4"
    },
    diagnostics_show: {
      message: "\uD604\uC7AC \uC0C1\uD0DC \uBCF4\uAE30"
    },
    diagnostics_shown: {
      message: "\uD604\uC7AC \uC0C1\uD0DC\uB97C \uD45C\uC2DC\uD588\uC2B5\uB2C8\uB2E4. \uC790\uB3D9\uC73C\uB85C \uC804\uC1A1\uB418\uC9C0 \uC54A\uC2B5\uB2C8\uB2E4."
    },
    diagnostics_title: {
      message: "\uC9C4\uB2E8 \uC815\uBCF4"
    },
    error_access_denied: {
      message: "\uC0AC\uC774\uD2B8\uAC00 \uC811\uADFC\uC744 \uAC70\uBD80\uD588\uC2B5\uB2C8\uB2E4. \uBCF4\uD638\uC7A5\uCE58\uB97C \uC6B0\uD68C\uD558\uC9C0 \uC54A\uC2B5\uB2C8\uB2E4."
    },
    error_ambiguous_account: {
      message: "\uC5EC\uB7EC Claude \uC870\uC9C1\uC774 \uD655\uC778\uB418\uC5B4 \uC120\uD0DD\uD560 \uC218 \uC5C6\uC2B5\uB2C8\uB2E4. \uACC4\uC815\uC758 \uC0AC\uC6A9\uB7C9 \uD654\uBA74\uC744 \uD655\uC778\uD574 \uC8FC\uC138\uC694."
    },
    error_invalid_response: {
      message: "\uC0AC\uC6A9\uB7C9 \uC751\uB2F5 \uD615\uC2DD\uC744 \uD655\uC778\uD560 \uC218 \uC5C6\uC2B5\uB2C8\uB2E4."
    },
    error_network: {
      message: "\uC5F0\uACB0 \uB610\uB294 \uC694\uCCAD \uC2DC\uAC04\uC774 \uCD08\uACFC\uB418\uC5C8\uC2B5\uB2C8\uB2E4."
    },
    error_not_collected: {
      message: "\uC544\uC9C1 \uC218\uC9D1\uD558\uC9C0 \uC54A\uC558\uC2B5\uB2C8\uB2E4."
    },
    error_open_tab: {
      message: "\uB85C\uADF8\uC778\uD55C \uC11C\uBE44\uC2A4 \uD0ED\uC744 \uC5F0 \uB4A4 \uD31D\uC5C5\uC744 \uB2E4\uC2DC \uC5F4\uC5B4 \uC8FC\uC138\uC694."
    },
    error_permission_required: {
      message: "\uC774 \uC11C\uBE44\uC2A4\uC758 \uC0AC\uC774\uD2B8 \uC811\uADFC \uAD8C\uD55C\uC774 \uD544\uC694\uD569\uB2C8\uB2E4."
    },
    error_rate_limited: {
      message: "\uC694\uCCAD \uD55C\uB3C4\uC5D0 \uB3C4\uB2EC\uD588\uC2B5\uB2C8\uB2E4. \uC7AC\uC2DC\uB3C4 \uC2DC\uAC01\uAE4C\uC9C0 \uAE30\uB2E4\uB824 \uC8FC\uC138\uC694."
    },
    error_server: {
      message: "\uC11C\uBE44\uC2A4 \uC624\uB958\uC785\uB2C8\uB2E4. \uC7A0\uC2DC \uD6C4 \uB2E4\uC2DC \uC2DC\uB3C4\uD569\uB2C8\uB2E4."
    },
    error_signed_out: {
      message: "\uC0AC\uC774\uD2B8\uC5D0 \uB85C\uADF8\uC778\uD55C \uB4A4 \uD31D\uC5C5\uC744 \uB2E4\uC2DC \uC5F4\uC5B4 \uC8FC\uC138\uC694."
    },
    error_tab_access_failed: {
      message: "\uC5F4\uB9B0 \uC11C\uBE44\uC2A4 \uD0ED\uC5D0\uC11C \uC218\uC9D1 \uCF54\uB4DC\uB97C \uC2E4\uD589\uD558\uC9C0 \uBABB\uD588\uC2B5\uB2C8\uB2E4. \uB9C8\uC9C0\uB9C9 \uC720\uD6A8 \uC0AC\uC6A9\uB7C9\uC744 \uC720\uC9C0\uD558\uBA70 \uC790\uB3D9\uC73C\uB85C \uB2E4\uC2DC \uC2DC\uB3C4\uD569\uB2C8\uB2E4."
    },
    error_unsupported: {
      message: "\uC548\uC804\uD55C \uC218\uC9D1 \uACC4\uC57D\uC744 \uAC80\uC99D\uD558\uC9C0 \uBABB\uD574 \uBBF8\uC9C0\uC6D0\uC785\uB2C8\uB2E4."
    },
    extension_description: {
      message: "ChatGPT, Claude, Gemini \uC0AC\uC6A9\uB7C9\uACFC \uCD08\uAE30\uD654 \uC2DC\uAC01\uC744 \uBCF4\uC5EC\uC8FC\uB294 \uB85C\uCEEC \uC804\uC6A9 \uD655\uC7A5\uC785\uB2C8\uB2E4."
    },
    format_duration_left: {
      message: "$1 \uB0A8\uC74C"
    },
    format_last_collected: {
      message: "\uB9C8\uC9C0\uB9C9 \uC815\uC0C1 \uC218\uC9D1: $1"
    },
    format_less_than_minute: {
      message: "1\uBD84 \uBBF8\uB9CC"
    },
    format_not_collected: {
      message: "\uC815\uC0C1 \uC218\uC9D1 \uAE30\uB85D \uC5C6\uC74C"
    },
    format_relative_day_one: {
      message: "$1\uC77C \uD6C4"
    },
    format_relative_day_other: {
      message: "$1\uC77C \uD6C4"
    },
    format_relative_hour_one: {
      message: "$1\uC2DC\uAC04 \uD6C4"
    },
    format_relative_hour_other: {
      message: "$1\uC2DC\uAC04 \uD6C4"
    },
    format_relative_minute_one: {
      message: "$1\uBD84 \uD6C4"
    },
    format_relative_minute_other: {
      message: "$1\uBD84 \uD6C4"
    },
    format_remaining: {
      message: "$1 \uB0A8\uC74C"
    },
    format_remaining_unknown: {
      message: "\uB0A8\uC740 \uC2DC\uAC04 \uD655\uC778 \uBD88\uAC00"
    },
    format_reset_countdown: {
      message: "\u{1F552} \uCD08\uAE30\uD654: $1"
    },
    format_reset_pending: {
      message: "\uCD08\uAE30\uD654 \uD6C4 \uD655\uC778 \uC911"
    },
    format_reset_popup: {
      message: "\u{1F552} \uC0AC\uC6A9\uB7C9 \uCD08\uAE30\uD654: $1"
    },
    format_reset_unavailable: {
      message: "\u{1F552} \uCD08\uAE30\uD654: $1"
    },
    format_unknown: {
      message: "\uD655\uC778 \uBD88\uAC00"
    },
    format_usage: {
      message: "\uC0AC\uC6A9\uB7C9: $1"
    },
    format_usage_name: {
      message: "\uC0AC\uC6A9\uB7C9"
    },
    limit_additional: {
      message: "\uCD94\uAC00 \uC81C\uD55C"
    },
    limit_days_one: {
      message: "$1\uC77C"
    },
    limit_days_other: {
      message: "$1\uC77C"
    },
    limit_hours_one: {
      message: "$1\uC2DC\uAC04"
    },
    limit_hours_other: {
      message: "$1\uC2DC\uAC04"
    },
    limit_legacy_shared: {
      message: "Work / Codex \uACF5\uC720"
    },
    limit_primary: {
      message: "\uAE30\uBCF8 \uC81C\uD55C"
    },
    limit_weekly: {
      message: "\uC8FC\uAC04"
    },
    popup_communication_failed: {
      message: "\uD655\uC7A5 \uD504\uB85C\uADF8\uB7A8\uACFC \uD1B5\uC2E0\uD560 \uC218 \uC5C6\uC2B5\uB2C8\uB2E4. \uD655\uC7A5\uC744 \uB2E4\uC2DC \uB85C\uB4DC\uD574 \uC8FC\uC138\uC694."
    },
    popup_danger_threshold: {
      message: "\uACBD\uACE0 \uC2DC\uC791 \uC0AC\uC6A9\uB960"
    },
    popup_disable: {
      message: "\uB044\uAE30"
    },
    popup_disabled: {
      message: "\uAEBC\uC9D0"
    },
    popup_enable: {
      message: "\uCF1C\uAE30"
    },
    popup_grant_enable: {
      message: "\uAD8C\uD55C \uC2B9\uC778 \uBC0F \uCF1C\uAE30"
    },
    popup_language: {
      message: "\uC5B8\uC5B4"
    },
    popup_language_english: {
      message: "\uC601\uC5B4"
    },
    popup_language_korean: {
      message: "\uD55C\uAD6D\uC5B4"
    },
    popup_language_system: {
      message: "\uC2DC\uC2A4\uD15C \uAE30\uBCF8 \uC5B8\uC5B4"
    },
    popup_limit_previous_usage: {
      message: "$1 \uC0AC\uC6A9\uB7C9 (\uC774\uC804 \uAC12)"
    },
    popup_limit_usage: {
      message: "$1 \uC0AC\uC6A9\uB7C9"
    },
    popup_local_only: {
      message: "\uB85C\uCEEC \uC804\uC6A9"
    },
    popup_onboarding_description: {
      message: "\uC120\uD0DD\uD55C \uC11C\uBE44\uC2A4\uC758 \uAD8C\uD55C\uC744 \uD55C \uBC88\uC5D0 \uD5C8\uC6A9\uD558\uACE0 \uC0AC\uC6A9\uB7C9\uC744 \uD655\uC778\uD569\uB2C8\uB2E4."
    },
    popup_onboarding_start: {
      message: "\uAD8C\uD55C \uD5C8\uC6A9 \uBC0F \uC2DC\uC791"
    },
    popup_onboarding_title: {
      message: "\uC0AC\uC6A9\uD560 \uC11C\uBE44\uC2A4\uB97C \uC120\uD0DD\uD558\uC138\uC694"
    },
    popup_open_site: {
      message: "$1 \uC0AC\uC774\uD2B8 \uC5F4\uAE30 (\uC0C8 \uD0ED)"
    },
    popup_permission_canceled: {
      message: "\uAD8C\uD55C \uC2B9\uC778\uC774 \uCDE8\uC18C\uB418\uC5C8\uC2B5\uB2C8\uB2E4."
    },
    popup_previous_usage: {
      message: "\uC774\uC804 \uC218\uC9D1\uAC12"
    },
    popup_provider_plan: {
      message: "$1 \uC694\uAE08\uC81C: $2"
    },
    popup_provider_usage: {
      message: "$1 \uC0AC\uC6A9\uB7C9"
    },
    popup_revoke: {
      message: "\uAD8C\uD55C \uCCA0\uD68C"
    },
    popup_settings: {
      message: "\uC124\uC815"
    },
    popup_settings_saved: {
      message: "\uC124\uC815\uC744 \uC800\uC7A5\uD588\uC2B5\uB2C8\uB2E4."
    },
    popup_show_in_composer: {
      message: "$1 \uC785\uB825\uCC3D\uC5D0 \uD45C\uC2DC"
    },
    popup_threshold_order_error: {
      message: "\uC8FC\uC758 \uC2DC\uC791 \uC0AC\uC6A9\uB960\uC740 \uACBD\uACE0 \uC2DC\uC791 \uC0AC\uC6A9\uB960\uBCF4\uB2E4 \uC791\uC544\uC57C \uD569\uB2C8\uB2E4."
    },
    popup_threshold_range_error: {
      message: "\uC8FC\uC758\xB7\uACBD\uACE0 \uC2DC\uC791 \uC0AC\uC6A9\uB960\uC740 0~100 \uC0AC\uC774\uC758 \uC22B\uC790\uB85C \uC785\uB825\uD574 \uC8FC\uC138\uC694."
    },
    popup_usage_unavailable: {
      message: "\uC0AC\uC6A9\uB7C9 \uD655\uC778 \uBD88\uAC00"
    },
    popup_warning_threshold: {
      message: "\uC8FC\uC758 \uC2DC\uC791 \uC0AC\uC6A9\uB960"
    },
    status_access_denied: {
      message: "\uC0AC\uC774\uD2B8 \uC811\uADFC \uAC70\uBD80"
    },
    status_ambiguous_account: {
      message: "Claude \uC870\uC9C1 \uC120\uD0DD \uD544\uC694"
    },
    status_invalid_response: {
      message: "\uC0AC\uC6A9\uB7C9 \uD655\uC778 \uBD88\uAC00"
    },
    status_network: {
      message: "\uC5F0\uACB0 \uD655\uC778 \uC911"
    },
    status_not_collected: {
      message: "\uC0AC\uC6A9\uB7C9 \uD655\uC778 \uC911"
    },
    status_ok: {
      message: "\uCD5C\uADFC \uC218\uC9D1 \uC131\uACF5"
    },
    status_open_tab: {
      message: "\uC11C\uBE44\uC2A4 \uD0ED \uC5F4\uAE30 \uD544\uC694"
    },
    status_permission_required: {
      message: "\uC0AC\uC774\uD2B8 \uAD8C\uD55C \uD544\uC694"
    },
    status_rate_limited: {
      message: "\uC7A0\uC2DC \uD6C4 \uB2E4\uC2DC \uD655\uC778"
    },
    status_server: {
      message: "\uC11C\uBE44\uC2A4 \uC751\uB2F5 \uB300\uAE30"
    },
    status_signed_out: {
      message: "\uB85C\uADF8\uC778 \uD544\uC694"
    },
    status_tab_access_failed: {
      message: "\uC0AC\uC6A9\uB7C9 \uB2E4\uC2DC \uD655\uC778 \uC911"
    },
    status_unsupported: {
      message: "\uC0AC\uC6A9\uB7C9 \uC218\uC9D1 \uBBF8\uC9C0\uC6D0"
    },
    ticket_availability_unknown: {
      message: "\uC0AC\uC6A9 \uAC00\uB2A5 \uC5EC\uBD80 \uD655\uC778 \uBD88\uAC00"
    },
    ticket_blocked: {
      message: "\uC0AC\uC6A9 \uC81C\uD55C \uC911"
    },
    ticket_count_one: {
      message: "$1\uAC1C"
    },
    ticket_count_other: {
      message: "$1\uAC1C"
    },
    ticket_expiry: {
      message: "$1 \uB9CC\uB8CC"
    },
    ticket_inline: {
      message: "\u{1F3AB} \uD2F0\uCF13 \uB9CC\uB8CC: $1"
    },
    ticket_kind_five_hour: {
      message: "5\uC2DC\uAC04 \uD55C\uB3C4"
    },
    ticket_kind_full: {
      message: "\uC804\uCCB4 \uD55C\uB3C4"
    },
    ticket_kind_unspecified: {
      message: "\uC885\uB958 \uD655\uC778 \uBD88\uAC00"
    },
    ticket_kind_weekly: {
      message: "\uC8FC\uAC04 \uD55C\uB3C4"
    },
    ticket_management_action: {
      message: "\uACF5\uC2DD \uC0AC\uC6A9\uB7C9 \uAD00\uB9AC \uD654\uBA74 \uC5F4\uAE30 (\uC0C8 \uD0ED)"
    },
    ticket_other_first: {
      message: "\uB2E4\uB978 \uD2F0\uCF13 \uC6B0\uC120"
    },
    ticket_requires_limit: {
      message: "\uD55C\uB3C4 \uB3C4\uB2EC \uC870\uAC74"
    },
    ticket_starts: {
      message: "$1\uBD80\uD130"
    },
    ticket_total_one: {
      message: "\u{1F3AB} \uCD08\uAE30\uD654 \uD2F0\uCF13 $1\uAC1C"
    },
    ticket_total_other: {
      message: "\u{1F3AB} \uCD08\uAE30\uD654 \uD2F0\uCF13 $1\uAC1C"
    },
    ticket_unavailable_now: {
      message: "\uD604\uC7AC \uC0AC\uC6A9 \uBD88\uAC00"
    }
  };

  // src/shared/i18n.ts
  var api = globalThis.chrome?.i18n;
  var preference = "system";
  function setLanguagePreference(language) {
    preference = language === "en" || language === "ko" ? language : "system";
  }
  function languageForUI(language) {
    return /^ko(?:-|$)/i.test(language) ? "ko" : "en";
  }
  function uiLanguage() {
    return preference === "system" ? languageForUI(api?.getUILanguage() ?? "en") : preference;
  }
  function t(key, substitutions = []) {
    const values = typeof substitutions === "string" ? [substitutions] : substitutions;
    const translated = preference === "system" ? api?.getMessage(key, values) : "";
    if (translated) return translated;
    const message = (uiLanguage() === "ko" ? messages_default2[key] : messages_default[key])?.message ?? messages_default[key].message;
    return message.replace(/\$(\d+)/g, (_, index) => values[Number(index) - 1] ?? "");
  }

  // src/shared/format.ts
  var DAYS = { ko: ["\uC77C", "\uC6D4", "\uD654", "\uC218", "\uBAA9", "\uAE08", "\uD1A0"], en: ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"] };
  var twoDigits = (value) => String(value).padStart(2, "0");
  function localStamp(at) {
    return `${at.getMonth() + 1}/${at.getDate()}(${DAYS[uiLanguage()][at.getDay()]}) ${twoDigits(at.getHours())}:${twoDigits(at.getMinutes())}`;
  }
  var geminiErrorText = (text) => Object.fromEntries(GEMINI_RESPONSE_ERRORS.map((code) => [code, text]));
  function relativeTime(remaining) {
    if (!Number.isFinite(remaining) || remaining <= 0) return null;
    for (const [unit, size] of [["day", 864e5], ["hour", 36e5], ["minute", 6e4]]) {
      if (remaining >= size) {
        const count2 = Math.floor(remaining / size);
        return t(`format_relative_${unit}_${count2 === 1 ? "one" : "other"}`, String(count2));
      }
    }
    return t("format_less_than_minute");
  }
  function resetValue(value, now, compact = false) {
    const reset = resetTime(value);
    if (reset === null) return t("format_unknown");
    const at = new Date(reset);
    const prefix = compact ? "" : `${localStamp(at)}, `;
    const remaining = at.getTime() - now;
    if (!Number.isFinite(remaining)) return `${prefix}${t("format_remaining_unknown")}`;
    if (remaining <= 0) return `${prefix}${t("format_reset_pending")}`;
    if (compact) return relativeTime(remaining) ?? t("format_remaining_unknown");
    const hours = Math.floor(remaining / 36e5), days = Math.floor(hours / 24);
    return `${prefix}${t("format_duration_left", `${days > 0 ? `${days}d ` : ""}${hours % 24}h`)}`;
  }
  function resetCountdownLabel(reset, now = Date.now()) {
    const at = resetTime(reset), remaining = at === null ? null : relativeTime(Date.parse(at) - now);
    return remaining ? t("format_reset_countdown", remaining) : t("format_reset_unavailable", resetValue(reset, now, true));
  }
  function usagePercentLabel(value) {
    const used = percent(value);
    return t("format_usage", used === null ? t("format_unknown") : `${Math.round(used)}%`);
  }
  var STATUS_KEYS = {
    not_collected: "status_not_collected",
    signed_out: "status_signed_out",
    access_denied: "status_access_denied",
    rate_limited: "status_rate_limited",
    network: "status_network",
    server: "status_server",
    invalid_response: "status_invalid_response",
    ...geminiErrorText("status_invalid_response"),
    open_tab: "status_open_tab",
    tab_access_failed: "status_tab_access_failed",
    ambiguous_account: "status_ambiguous_account",
    unsupported: "status_unsupported",
    permission_required: "status_permission_required",
    reset_pending: "format_reset_pending"
  };
  function statusText(snapshot) {
    if (snapshot.state === "ok") return t("status_ok");
    if (snapshot.state === "stale") return t("status_not_collected");
    return snapshot.errorCode ? t(STATUS_KEYS[snapshot.errorCode]) : t("format_unknown");
  }

  // src/shared/errors.ts
  var ERROR_KEYS = {
    not_collected: "error_not_collected",
    signed_out: "error_signed_out",
    access_denied: "error_access_denied",
    rate_limited: "error_rate_limited",
    network: "error_network",
    invalid_response: "error_invalid_response",
    ...geminiErrorText("error_invalid_response"),
    open_tab: "error_open_tab",
    ambiguous_account: "error_ambiguous_account",
    tab_access_failed: "error_tab_access_failed",
    unsupported: "error_unsupported",
    permission_required: "error_permission_required",
    server: "error_server",
    reset_pending: "format_reset_pending"
  };
  var ERROR_TEXT = Object.defineProperties({}, Object.fromEntries(
    Object.entries(ERROR_KEYS).map(([code, key]) => [code, { enumerable: true, get: () => t(key) }])
  ));

  // src/shared/plan.ts
  var LABELS = {
    chatgpt: ["Free", "Go", "Plus", "Pro", "Pro 100", "Pro 200", "Pro 500", "Team", "Business", "Enterprise", "Education", "Education (K-12)"],
    claude: ["Free", "Pro", "Max", "Max 5x", "Max 20x", "Team", "Enterprise"],
    gemini: ["Free", "AI Plus", "AI Pro", "AI Ultra", "Workspace"]
  };
  var PLAN_MAX_AGE_MS = 10 * 6e4;
  function knownPlanLabel(provider, input) {
    return typeof input === "string" && LABELS[provider].includes(input) ? input : null;
  }
  function parsePlan(provider, input) {
    const raw = record(input), label2 = knownPlanLabel(provider, raw?.label);
    return label2 && finite(raw?.checkedAt) && raw.checkedAt > 0 ? { label: label2, checkedAt: raw.checkedAt } : null;
  }

  // src/shared/tickets.ts
  var count = (value) => Number.isSafeInteger(value) && value >= 0;
  var nullableBoolean = (value) => value === null || typeof value === "boolean";
  var date = (value) => value === null || resetTime(value) !== null;
  var kinds = ["full", "five_hour", "weekly", "unspecified"];
  function parseTicketInventory(input) {
    const raw = record(input);
    if (!raw || typeof raw.mode !== "string" || !["summary", "detail"].includes(raw.mode) || !Array.isArray(raw.grants) || raw.grants.length > 100 || !(raw.usableCount === null || count(raw.usableCount)) || !date(raw.cooldownUntil)) return null;
    const grants = [];
    for (const value of raw.grants) {
      const grant = record(value);
      if (!grant || typeof grant.kind !== "string" || !kinds.includes(grant.kind) || !count(grant.count) || !date(grant.startsAt) || !date(grant.expiresAt) || !nullableBoolean(grant.usableNow) || !nullableBoolean(grant.requiresLimit) || !nullableBoolean(grant.blocked) || !nullableBoolean(grant.selected) || !Array.isArray(grant.clears) || grant.clears.length > 64 || !grant.clears.every((value2) => typeof value2 === "string" && /^(five_hour|seven_day(?:_[a-z0-9_]+)?)$/.test(value2) && value2.length <= 64)) return null;
      const startsAt = resetTime(grant.startsAt), expiresAt = resetTime(grant.expiresAt);
      if (startsAt && expiresAt && Date.parse(startsAt) >= Date.parse(expiresAt)) return null;
      grants.push({
        kind: grant.kind,
        count: grant.count,
        startsAt,
        expiresAt,
        usableNow: grant.usableNow,
        clears: [...new Set(grant.clears)],
        requiresLimit: grant.requiresLimit,
        blocked: grant.blocked,
        selected: grant.selected
      });
    }
    const total = grants.reduce((sum, grant) => sum + grant.count, 0);
    if (!count(total) || raw.usableCount !== null && raw.usableCount > total) return null;
    if (raw.mode === "summary" && grants.some((grant) => grant.kind !== "unspecified" || grant.startsAt !== null || grant.expiresAt !== null)) return null;
    return {
      mode: raw.mode,
      grants,
      usableCount: raw.usableCount,
      cooldownUntil: resetTime(raw.cooldownUntil)
    };
  }
  function parseTicketCache(input) {
    const raw = record(input), inventory = parseTicketInventory(raw?.inventory);
    return inventory && finite(raw?.checkedAt) && raw.checkedAt > 0 && count(raw.failures) ? { inventory, checkedAt: raw.checkedAt, failures: raw.failures } : null;
  }
  function ticketSummary(snapshot, now = Date.now()) {
    if (snapshot.provider === "gemini" || snapshot.ticketRefreshPending || !finite(now) || ["signed_out", "permission_required", "unsupported"].includes(snapshot.state) || ["signed_out", "access_denied", "ambiguous_account", "permission_required"].includes(snapshot.errorCode ?? "")) return null;
    const cache = parseTicketCache(snapshot.tickets);
    if (!cache || cache.checkedAt > now || cache.failures >= 2) return null;
    const { inventory, checkedAt } = cache;
    const grants = inventory.grants.filter((grant) => grant.count > 0 && (grant.expiresAt === null || Date.parse(grant.expiresAt) > now));
    const held = grants.reduce((sum, grant) => sum + grant.count, 0);
    if (!held) return null;
    const expiry = grants.flatMap((grant) => grant.expiresAt ? [Date.parse(grant.expiresAt)] : []);
    const cooldown = inventory.cooldownUntil ? Date.parse(inventory.cooldownUntil) : null;
    const crossed = (time) => time !== null && Date.parse(time) > checkedAt && Date.parse(time) <= now;
    const changedBoundary = inventory.grants.some((grant) => crossed(grant.startsAt) || crossed(grant.expiresAt)) || crossed(inventory.cooldownUntil);
    let usable = null;
    if (cooldown !== null && cooldown > now) usable = 0;
    else if (inventory.usableCount !== null && !changedBoundary) {
      const startedCount = grants.filter((grant) => grant.startsAt === null || Date.parse(grant.startsAt) <= now).reduce((sum, grant) => sum + grant.count, 0);
      usable = inventory.usableCount === 0 || startedCount === held && inventory.usableCount <= startedCount ? inventory.usableCount : null;
    } else if (inventory.mode === "detail") {
      let total = 0, known = true;
      for (const grant of grants) {
        if (grant.startsAt !== null && Date.parse(grant.startsAt) > now) continue;
        if (crossed(grant.startsAt) || crossed(inventory.cooldownUntil)) {
          known = false;
          continue;
        }
        if (grant.blocked === true || grant.selected === false || grant.usableNow === false) continue;
        if (grant.usableNow === true) total += grant.count;
        else known = false;
      }
      if (known) usable = total;
    }
    return { held, usable, expiresAt: expiry.length ? new Date(Math.min(...expiry)).toISOString() : null, grants };
  }

  // src/storage/snapshots.ts
  var FRESH_MS = 10 * 6e4;
  function emptySnapshot(provider) {
    return { provider, state: "error", limits: [], collectedAt: null, checkedAt: null, nextAttemptAt: 0, failures: 0, errorCode: "not_collected" };
  }
  function validLimits(input) {
    return Array.isArray(input) && input.length <= 150 && input.every((x) => {
      const r = record(x);
      return r && typeof r.id === "string" && r.id.length > 0 && r.id.length <= 200 && label(r.label) && ["window", "model", "product"].includes(String(r.category)) && r.source === "api" && (r.percent === null || percent(r.percent) !== null) && (r.resetsAt === null || resetTime(r.resetsAt) !== null) && (r.windowSeconds === null || nonnegative(r.windowSeconds) !== null) && (r.remaining === null || nonnegative(r.remaining) !== null) && (r.unit === null || label(r.unit));
    }) && new Set(input.map((x) => x.id)).size === input.length;
  }
  var STATES = ["ok", "stale", "signed_out", "permission_required", "rate_limited", "unsupported", "error"];
  function parseSnapshot(input, provider) {
    const r = record(input);
    if (!r || r.provider !== provider || !STATES.includes(String(r.state)) || !validLimits(r.limits) || !(r.collectedAt === null || finite(r.collectedAt)) || !(r.checkedAt === null || finite(r.checkedAt)) || !finite(r.nextAttemptAt) || !finite(r.failures) || !(r.errorCode === null || typeof r.errorCode === "string" && Object.hasOwn(ERROR_TEXT, r.errorCode))) return emptySnapshot(provider);
    if (r.state === "ok" && (r.collectedAt === null || r.limits.length === 0)) return emptySnapshot(provider);
    const limits = r.limits.map((limit) => ({
      id: limit.id,
      label: label(limit.label),
      category: limit.category,
      percent: limit.percent,
      resetsAt: limit.resetsAt === null ? null : resetTime(limit.resetsAt),
      windowSeconds: limit.windowSeconds,
      remaining: limit.remaining,
      unit: limit.unit === null ? null : label(limit.unit),
      source: "api"
    }));
    return {
      provider,
      state: r.state,
      limits,
      collectedAt: r.collectedAt,
      checkedAt: r.checkedAt,
      nextAttemptAt: Math.max(0, r.nextAttemptAt),
      failures: Math.max(0, r.failures),
      errorCode: r.errorCode,
      ...r.usageInvalidated === true ? { usageInvalidated: true } : {},
      ...Object.hasOwn(r, "plan") ? { plan: parsePlan(provider, r.plan) } : {},
      ...Object.hasOwn(r, "planRefreshPending") ? { planRefreshPending: r.planRefreshPending === true } : {},
      ...Object.hasOwn(r, "tickets") ? { tickets: provider === "gemini" ? null : parseTicketCache(r.tickets) } : {},
      ...Object.hasOwn(r, "ticketRefreshPending") ? { ticketRefreshPending: r.ticketRefreshPending === true } : {}
    };
  }
  function hasElapsedReset(snapshot, now = Date.now()) {
    return snapshot.limits.some((limit) => {
      const reset = resetTime(limit.resetsAt);
      return reset !== null && Date.parse(reset) <= now;
    });
  }
  function effectiveSnapshot(snapshot, now = Date.now()) {
    const firstTransient = snapshot.failures === 1 && (snapshot.errorCode === "network" || snapshot.errorCode === "server");
    const cachedFallback = !snapshot.usageInvalidated && (firstTransient || snapshot.errorCode === "tab_access_failed");
    const legacyAgeOnly = snapshot.state === "stale" && snapshot.errorCode === null && snapshot.failures === 0;
    const current = snapshot.state === "ok";
    if (!current && !legacyAgeOnly && !(snapshot.state === "error" && cachedFallback)) return snapshot;
    if (snapshot.usageInvalidated || current && snapshot.errorCode !== null && !cachedFallback) return { ...snapshot, state: "error" };
    const usable = finite(now) && finite(snapshot.collectedAt) && snapshot.collectedAt > 0 && snapshot.collectedAt <= now + 6e4 && snapshot.limits.length > 0 && validLimits(snapshot.limits);
    if (!usable) return current || legacyAgeOnly ? { ...snapshot, state: "error", errorCode: "invalid_response" } : snapshot;
    if (hasElapsedReset(snapshot, now)) return { ...snapshot, state: "error", errorCode: "reset_pending" };
    return current ? snapshot : { ...snapshot, state: "ok" };
  }
  var SNAPSHOT_KEYS = { chatgpt: "snapshot:v4:chatgpt", claude: "snapshot:v2:claude", gemini: "snapshot:v1:gemini" };
  var SETTINGS_KEY = "settings:v2";
  function affectsView(changes, areaName) {
    return areaName === "local" && !!changes && Object.keys(changes).some((key) => key === SETTINGS_KEY || Object.values(SNAPSHOT_KEYS).includes(key));
  }

  // src/shared/display-policy.ts
  var displayProvider = (page) => page === "codex" ? "chatgpt" : page;
  function shouldShowStrip(view, page) {
    const source = displayProvider(page);
    return view.permissions[source] && view.settings.enabled[source] && view.settings.strips[page];
  }
  function needsContent(view, pages) {
    return pages.some((page) => shouldShowStrip(view, page));
  }
  var canRefreshFromPage = (page, source) => displayProvider(page) === source;

  // src/shared/contracts.ts
  function sameFields(left, right) {
    if (left === right) return true;
    if (Array.isArray(left)) return Array.isArray(right) && left.length === right.length && left.every((value, index) => sameFields(value, right[index]));
    const a = record(left), b = record(right);
    return !!a && !!b && Object.keys(a).length === Object.keys(b).length && Object.keys(a).every((key) => Object.hasOwn(b, key) && sameFields(a[key], b[key]));
  }
  function isReply(input) {
    const r = record(input), view = record(r?.view);
    if (r?.ok !== true || !view || !isSettings(view.settings)) return false;
    return PROVIDERS.every((p) => {
      const raw = record(record(view.snapshots)?.[p]);
      if (!raw || typeof record(view.permissions)?.[p] !== "boolean") return false;
      const clean = parseSnapshot(raw, p);
      return sameFields(clean, raw);
    });
  }
  async function request(message) {
    const reply = await chrome.runtime.sendMessage(message);
    if (!isReply(reply)) throw new Error("invalid_extension_response");
    return reply.view;
  }

  // src/shared/usage-selection.ts
  function isCommonComposerLimit(provider, limit) {
    return provider === "chatgpt" ? limit.category === "product" && ["shared:primary_window", "shared:secondary_window"].includes(limit.id) : limit.category === "window";
  }
  function composerUsageLimit(provider, limits) {
    const valid = limits.filter((limit) => isCommonComposerLimit(provider, limit) && percent(limit.percent) !== null);
    const exhausted = valid.filter((limit) => limit.percent === 100);
    const candidates = exhausted.length ? exhausted : valid;
    let selected = null;
    let selectedReset = null;
    for (const limit of candidates) {
      const reset = resetTime(limit.resetsAt);
      const time = reset === null ? null : Date.parse(reset);
      const better = exhausted.length ? selectedReset !== null && (time === null || time > selectedReset) : time !== null ? selectedReset === null || time < selectedReset : selectedReset === null && limit.percent > (selected?.percent ?? -1);
      if (selected === null || better) {
        selected = limit;
        selectedReset = time;
      }
    }
    return selected;
  }

  // src/content/usage-label.ts
  function usageParts(snapshot, limit, now = Date.now()) {
    const currentData = snapshot.state === "ok";
    const used = currentData ? percent(limit?.percent) : null;
    const current = usagePercentLabel(used);
    const reset = resetCountdownLabel(currentData ? limit?.resetsAt : null, now);
    const status = currentData ? null : statusText(snapshot);
    return { current, reset, status, percent: used, label: [current, reset, status].filter((value) => value !== null).join("  ") };
  }

  // src/content/gemini.ts
  var GEMINI_COMPOSER = "input-area-v2,.input-area";
  var GEMINI_INPUT = GEMINI_COMPOSER.split(",").flatMap((scope) => [
    `${scope} rich-textarea [contenteditable]`,
    `${scope} textarea`
  ]).join(",");
  var GEMINI_STOP = 'button[data-test-id="stop-button"],button[aria-label="Stop response" i],button[aria-label="Stop generating" i],button[aria-label="\uC751\uB2F5 \uC911\uC9C0"],button[aria-label="\uC0DD\uC131 \uC911\uC9C0"]';
  var MESSAGES = "user-query,model-response,message-content";
  function geminiBoundary(input) {
    const boundary = input.closest(GEMINI_COMPOSER);
    return boundary && !boundary.closest(`[contenteditable],${MESSAGES}`) && !boundary.querySelector(MESSAGES) ? boundary : null;
  }

  // src/content/selectors.ts
  var EDITABLE = "[contenteditable],textarea";
  var COMPOSER = 'form[data-chatgpt-composer],form[data-type="unified-composer"],[data-testid="codex-composer"],[data-testid="composer"]';
  var EXPLICIT_INPUT = `#prompt-textarea,${COMPOSER.split(",").flatMap((container) => [`${container} textarea`, `${container} [contenteditable]`]).join(",")}`;
  var OWN_UI = "#ai-gauge-usage-strip";
  var MODAL_BACKGROUND = '[inert],[aria-hidden="true"]';
  var EXCLUDED_REGION = `[hidden],dialog,[role="dialog"],[role="alertdialog"],[role="search"],nav,[data-message-author-role],[data-testid="user-message"],[data-testid^="conversation-turn-"],${OWN_UI}`;
  var EXCLUDED = `${MODAL_BACKGROUND},${EXCLUDED_REGION}`;
  var SHELL = 'html,body,main,[role="main"],[role="application"],article,aside';
  var UNRELATED_REGION = 'main,[role="main"],[role="application"],article,aside,nav,header,[role="search"],[data-message-author-role],[data-testid="user-message"],[data-testid^="conversation-turn-"]';
  var STOP = 'button[data-testid="stop-button"],button[aria-label="Stop response" i],button[aria-label="\uC751\uB2F5 \uC911\uC9C0"]';
  var CLAUDE_STOP = `${STOP},button[data-testid="stop-response-button"],button[aria-label="Stop generating" i],button[aria-label="Stop generation" i],button[aria-label="\uC0DD\uC131 \uC911\uC9C0"]`;
  var SELECTORS = {
    chatgpt: { input: "#prompt-textarea", stop: STOP },
    codex: { input: EDITABLE, stop: STOP },
    claude: { input: EDITABLE, stop: CLAUDE_STOP },
    gemini: { input: GEMINI_INPUT, stop: GEMINI_STOP }
  };
  function isRendered(element) {
    if (!element.isConnected || element.closest("[hidden],dialog:not([open])")) return false;
    for (let node = element; node; node = node.parentElement) {
      const style = node.ownerDocument.defaultView?.getComputedStyle(node);
      if (style?.display === "none" || style?.visibility === "hidden" || style?.visibility === "collapse" || style?.contentVisibility === "hidden" || style?.opacity === "0") return false;
    }
    return true;
  }
  function visible(element, modalBackground = false) {
    return !element.closest(modalBackground ? EXCLUDED_REGION : EXCLUDED) && isRendered(element);
  }
  function isModalBackground(element) {
    const isolated = element.closest(MODAL_BACKGROUND);
    if (!isolated) return false;
    return [...element.ownerDocument.querySelectorAll('dialog[open],[role="dialog"],[role="alertdialog"]')].some((dialog) => !isolated.contains(dialog) && !dialog.contains(element) && !dialog.closest(`${MODAL_BACKGROUND},${OWN_UI}`) && isRendered(dialog) && onScreen(dialog));
  }
  function hasStreamingControl(doc, provider) {
    return [...doc.querySelectorAll(SELECTORS[provider].stop)].some((control) => visible(control, isModalBackground(control)) && (provider !== "gemini" || !control.closest("[contenteditable]") && geminiBoundary(control) !== null));
  }
  function editingHost(element) {
    if (element.tagName === "TEXTAREA") return true;
    const value = element.getAttribute("contenteditable")?.toLowerCase();
    return value === "" || value === "true" || value === "plaintext-only";
  }
  function onScreen(element) {
    const doc = element.ownerDocument, win = doc.defaultView;
    if (!win || !doc.documentElement.getClientRects().length) return true;
    return [...element.getClientRects()].some((rect) => rect.width > 1 && rect.height > 1 && rect.bottom > 0 && rect.right > 0 && rect.top < win.innerHeight && rect.left < win.innerWidth);
  }
  function eligibleInput(input) {
    if (!editingHost(input) || !visible(input) || !onScreen(input) || input.matches(':disabled,[readonly],[aria-readonly="true"],[role="searchbox"]')) return false;
    const editableParent = input.parentElement?.closest("[contenteditable]");
    return !editableParent || !editingHost(editableParent);
  }
  function inputsInside(element) {
    return [...element.querySelectorAll(EDITABLE)].filter(eligibleInput);
  }
  function shell(element) {
    return element.matches(SHELL) || !!element.closest(EXCLUDED);
  }
  function onlyEditor(element, input) {
    const inputs = inputsInside(element);
    return inputs.length === 1 && inputs[0] === input;
  }
  function bounded(element, input) {
    return !shell(element) && !element.querySelector(UNRELATED_REGION) && onlyEditor(element, input);
  }
  function composerBoundary(input, provider) {
    if (provider === "gemini") {
      const boundary = geminiBoundary(input);
      return boundary && bounded(boundary, input) ? boundary : null;
    }
    for (const declared of [input.closest(COMPOSER), input.closest("form"), input.closest("fieldset")]) {
      if (declared && bounded(declared, input)) return declared;
    }
    if (provider === "chatgpt") return null;
    let branch = input;
    while (branch.parentElement) {
      const parent = branch.parentElement;
      if (!bounded(parent, input)) return null;
      const controls = [...parent.querySelectorAll('button,[role="button"],[role="toolbar"]')].filter((control) => !branch.contains(control) && visible(control));
      if (controls.length > 0) return parent;
      branch = parent;
    }
    return null;
  }
  function painted(style) {
    if (!style) return false;
    const border = [style.borderTopWidth, style.borderBottomWidth, style.borderLeftWidth, style.borderRightWidth].some((width) => Number.parseFloat(width) > 0);
    const shadow = !!style.boxShadow && style.boxShadow !== "none";
    const roundedBackground = Number.parseFloat(style.borderRadius) > 0 && !!style.backgroundColor && !["transparent", "rgba(0, 0, 0, 0)"].includes(style.backgroundColor);
    return border || shadow || roundedBackground;
  }
  function compactWrapper(parent, children, style) {
    if (!parent.ownerDocument.documentElement.getClientRects().length) return true;
    const parentRect = parent.getBoundingClientRect();
    const boxes = children.map((child) => child.getBoundingClientRect()).filter((box) => box.height > 0 && box.width > 0);
    if (!boxes.length || parentRect.height <= 0) return false;
    const contentHeight = Math.max(...boxes.map((box) => box.bottom)) - Math.min(...boxes.map((box) => box.top));
    const insets = [style?.paddingTop, style?.paddingBottom, style?.borderTopWidth, style?.borderBottomWidth].reduce((sum, value) => sum + (Number.parseFloat(value ?? "") || 0), 0);
    return parentRect.height <= contentHeight + insets + 2;
  }
  function outsideLayout(boundary, input) {
    let anchor = boundary;
    while (anchor.parentElement) {
      const parent = anchor.parentElement;
      if (parent.closest("[contenteditable]")) return null;
      const style = parent.ownerDocument.defaultView?.getComputedStyle(parent);
      const isRow = (style?.display === "flex" || style?.display === "inline-flex") && !style.flexDirection.startsWith("column");
      const grid = style?.display === "grid" || style?.display === "inline-grid";
      const constrained = isRow || grid || ["hidden", "clip"].includes(style?.overflowY ?? "") || ["hidden", "clip"].includes(style?.overflow ?? "");
      const contents = style?.display === "contents";
      if (shell(parent) || !onlyEditor(parent, input) || parent.querySelector(UNRELATED_REGION)) {
        return constrained || contents ? null : anchor;
      }
      const children = [...parent.children].filter((child) => !child.matches(OWN_UI) && visible(child));
      const singlePaintedWrapper = children.length === 1 && children[0] === anchor && painted(style);
      if (contents || (constrained || singlePaintedWrapper) && children.length <= 4 && compactWrapper(parent, children, style)) {
        anchor = parent;
        continue;
      }
      return constrained ? null : anchor;
    }
    return null;
  }
  function hasClassPrefix(element, prefix) {
    return [...element.classList].some((token) => token.startsWith(prefix) && token.length > prefix.length);
  }
  function classPrefixElements(doc, prefix) {
    return [...doc.querySelectorAll(`div[class*="${prefix}"]`)].filter((element) => hasClassPrefix(element, prefix));
  }
  function eligibleAnchor(anchor, modalBackground = false) {
    return visible(anchor, modalBackground) && onScreen(anchor) && !anchor.closest("[contenteditable]") && !anchor.querySelector(UNRELATED_REGION);
  }
  function retainsComposerMarker(target, modalBackground) {
    if (!target.marker) return true;
    const { anchor, marker } = target;
    return eligibleAnchor(anchor, modalBackground) && (marker === "claude" ? anchor.matches('div[data-cds="ChatComposerChin"]') : hasClassPrefix(anchor, marker === "chatgpt" ? "ComposerLayoutBody-" : marker === "codex" ? "ComposerLayoutRoot-" : "ComposerLayoutFooter-"));
  }
  function retainsComposerTarget(target) {
    const { anchor, input, scope } = target, modalBackground = isModalBackground(anchor);
    return visible(anchor, modalBackground) && retainsComposerMarker(target, modalBackground) && (!scope || scope.isConnected && scope.contains(anchor)) && (!input || visible(input, modalBackground) && (scope ?? anchor).contains(input));
  }
  function associateMarker(anchor, markers) {
    for (let scope = anchor; scope && !shell(scope); scope = scope.parentElement) {
      if (scope.querySelector(UNRELATED_REGION) || markers.filter((marker) => scope.contains(marker)).length !== 1) break;
      const inputs = inputsInside(scope);
      if (inputs.length === 1) return { input: inputs[0], anchor, scope, placement: "after" };
      if (inputs.length > 1) break;
    }
    return { input: null, anchor, placement: "after" };
  }
  function requestedTargets(doc, provider) {
    if (provider === "gemini") return [];
    const markers = (provider === "chatgpt" ? classPrefixElements(doc, "ComposerLayoutBody-") : provider === "codex" ? classPrefixElements(doc, "ComposerLayoutRoot-") : [...doc.querySelectorAll('div[data-cds="ChatComposerChin"]')]).filter((anchor) => eligibleAnchor(anchor));
    return markers.map((anchor) => ({ ...associateMarker(anchor, markers), marker: provider }));
  }
  function codexFooters(doc) {
    return classPrefixElements(doc, "ComposerLayoutFooter-").filter((anchor) => eligibleAnchor(anchor));
  }
  function hasCodexFooter(doc) {
    return classPrefixElements(doc, "ComposerLayoutFooter-").some((anchor) => eligibleAnchor(anchor, isModalBackground(anchor)));
  }
  function codexFooterTargets(doc) {
    const footers = codexFooters(doc);
    return footers.map((footer) => {
      const target = { ...associateMarker(footer, footers), marker: "codex-footer" };
      if (!target.input) return target;
      const boundary = composerBoundary(target.input, "codex");
      const anchor = boundary && outsideLayout(boundary, target.input);
      return anchor ? { input: target.input, anchor, placement: "after" } : target;
    });
  }
  function preferredMarker(targets, doc) {
    if (targets.length === 1) return targets[0];
    const focused = targets.filter(({ input, anchor }) => anchor.contains(doc.activeElement) || input === doc.activeElement || !!input?.contains(doc.activeElement));
    if (focused.length === 1) return focused[0];
    const associated = targets.filter(({ input }) => input !== null);
    return associated.length === 1 ? associated[0] : null;
  }
  function findComposerTarget(doc, provider) {
    const requested = requestedTargets(doc, provider);
    if (requested.length) return preferredMarker(requested, doc);
    if (provider === "codex") {
      const footers = codexFooterTargets(doc);
      if (footers.length) return preferredMarker(footers, doc);
    }
    const selector = provider === "chatgpt" ? EXPLICIT_INPUT : SELECTORS[provider].input;
    const targets = [];
    for (const input of doc.querySelectorAll(selector)) {
      if (!eligibleInput(input)) continue;
      const boundary = composerBoundary(input, provider);
      const anchor = boundary && outsideLayout(boundary, input);
      if (anchor) targets.push({ input, anchor });
    }
    if (targets.length === 1) return targets[0];
    const focused = targets.filter(({ input }) => input === doc.activeElement || !!input?.contains(doc.activeElement));
    if (focused.length === 1) return focused[0];
    const explicit = targets.filter(({ input }) => input?.matches(EXPLICIT_INPUT));
    return explicit.length === 1 ? explicit[0] : null;
  }

  // src/shared/ticket-presentation.ts
  var MANAGEMENT_URLS = {
    chatgpt: "https://chatgpt.com/settings/usage?tab=overview",
    claude: "https://claude.ai/new#settings/usage"
  };
  function inlineTicketDisplay(snapshot, now = Date.now()) {
    const usageReady = snapshot.state === "ok" && snapshot.errorCode === null;
    const resetElapsed = snapshot.state === "error" && snapshot.errorCode === "reset_pending";
    if (!usageReady && !resetElapsed || snapshot.failures !== 0 || snapshot.usageInvalidated || snapshot.tickets?.failures !== 0) return null;
    const href = MANAGEMENT_URLS[snapshot.provider], summary = ticketSummary(snapshot, now);
    if (!href || !summary?.expiresAt) return null;
    const remaining = relativeTime(Date.parse(summary.expiresAt) - now);
    if (!remaining) return null;
    const text = t("ticket_inline", remaining);
    return { href, text, accessible: `${text}. ${t("ticket_management_action")}` };
  }

  // assets/gauge-background.svg
  var gauge_background_default = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64" width="64" height="64" fill="none">\n  <defs>\n    <linearGradient id="track" x1="9" y1="48" x2="55" y2="18" gradientUnits="userSpaceOnUse">\n      <stop stop-color="#5EF8E8"/><stop offset="0.55" stop-color="#20CEFC"/><stop offset="1" stop-color="#159EFF"/>\n    </linearGradient>\n    <linearGradient id="hub" x1="26" y1="42" x2="39" y2="57" gradientUnits="userSpaceOnUse">\n      <stop stop-color="#80F7FF"/><stop offset="0.45" stop-color="#1970D0"/><stop offset="1" stop-color="#07275B"/>\n    </linearGradient>\n  </defs>\n  <!-- Transparent canvas; the arc uses a CSS custom property for inline SVG usage. -->\n  <path d="M8 46 A24 24 0 0 1 56 46" stroke="#073D85" stroke-width="10" stroke-linecap="round" opacity=".45"/>\n  <path d="M8 46 A24 24 0 0 1 56 46" stroke="var(--gauge-color, url(#track))" stroke-width="8" stroke-linecap="round"/>\n  <path d="M8 46 A24 24 0 0 1 56 46" stroke="white" stroke-width="1.2" stroke-linecap="round" opacity=".34"/>\n  <circle cx="32" cy="46" r="7" fill="#06377E" stroke="#3CAFFD" stroke-width="1.5"/>\n  <circle cx="32" cy="46" r="5" fill="url(#hub)"/>\n</svg>\n';

  // assets/gauge-needle.svg
  var gauge_needle_default = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64" width="64" height="64" fill="none">\n  <defs>\n    <linearGradient id="needle" x1="27" y1="46" x2="37" y2="13" gradientUnits="userSpaceOnUse">\n      <stop stop-color="#FF8A14"/><stop offset=".55" stop-color="#FFAD20"/><stop offset="1" stop-color="#FFE483"/>\n    </linearGradient>\n  </defs>\n  <!-- Neutral orientation points upward (50 percent). Rotate the needle group around (32,46). -->\n  <g id="needle-rotor">\n    <path d="M27.5 46 L32 13 L36.5 46 Z" fill="url(#needle)" stroke="#FFB528" stroke-width=".6" stroke-linejoin="round"/>\n  </g>\n  <circle cx="32" cy="46" r="5.5" fill="#0D4D9F" stroke="#72E9FF" stroke-width="1.5"/>\n  <circle cx="30.5" cy="44.5" r="2.1" fill="#A8F9FF" opacity=".75"/>\n</svg>\n';

  // src/content/usage-gauge.ts
  var SVG_NS = "http://www.w3.org/2000/svg";
  var nextId = 0;
  var USAGE_GAUGE_CSS = `
.usage-gauge{display:block;width:20px;height:20px;flex:0 0 20px;overflow:visible}
.gauge-needle{transform-box:view-box;transform-origin:32px 46px;transition:transform 500ms ease}
.gauge-arc{transition:stroke 300ms ease}
@media (prefers-reduced-motion:reduce){.gauge-needle,.gauge-arc{transition:none}}`;
  function assetElements(doc, source) {
    const Parser = doc.defaultView?.DOMParser ?? globalThis.DOMParser;
    const root = new Parser().parseFromString(source, "image/svg+xml").documentElement;
    if (root.namespaceURI !== SVG_NS || root.localName !== "svg") throw new Error("invalid_gauge_asset");
    return [...root.children].map((child) => doc.importNode(child, true));
  }
  var UsageGauge = class {
    element;
    needle;
    arc;
    value;
    constructor(doc, value, thresholds) {
      this.element = doc.createElementNS(SVG_NS, "svg");
      for (const [name, attribute] of Object.entries({
        viewBox: "0 0 64 64",
        width: "20",
        height: "20",
        fill: "none",
        class: "usage-gauge brand-icon",
        "aria-hidden": "true",
        focusable: "false"
      })) this.element.setAttribute(name, attribute);
      this.element.append(...assetElements(doc, gauge_background_default), ...assetElements(doc, gauge_needle_default));
      const prefix = `ai-gauge-${++nextId}-`;
      for (const node of this.element.querySelectorAll("[id]")) {
        const id = node.id;
        node.id = prefix + id;
        for (const shape of this.element.querySelectorAll("[fill],[stroke]")) {
          for (const attribute of ["fill", "stroke"]) {
            const current = shape.getAttribute(attribute);
            if (current?.includes(`url(#${id})`)) shape.setAttribute(attribute, current.replace(`url(#${id})`, `url(#${prefix}${id})`));
          }
        }
      }
      const arc = [...this.element.querySelectorAll("path[stroke]")].find((path) => path.getAttribute("stroke").includes("--gauge-color"));
      const needle = this.element.querySelector(`g[id="${prefix}needle-rotor"]`);
      if (!arc || !needle) throw new Error("invalid_gauge_asset");
      arc.classList.add("gauge-arc");
      needle.classList.add("gauge-needle");
      this.arc = arc;
      this.needle = needle;
      this.update(value, thresholds);
    }
    update(value, thresholds) {
      const used = percent(value);
      const color = used === null ? "#8893A0" : used >= thresholds.danger ? "#FF454E" : used >= thresholds.warning ? "#FFAE32" : "#2DE5F4";
      if (this.arc.getAttribute("stroke") !== color) this.arc.setAttribute("stroke", color);
      if (this.value === used) return;
      if (this.value == null || used === null) {
        if (this.needle.style.transition !== "none") this.needle.style.transition = "none";
      } else if (this.needle.style.transition) this.needle.style.removeProperty("transition");
      const state = used === null ? "unknown" : "known";
      if (this.element.getAttribute("data-usage-state") !== state) this.element.setAttribute("data-usage-state", state);
      const visibility = used === null ? "hidden" : "visible";
      if (this.needle.getAttribute("visibility") !== visibility) this.needle.setAttribute("visibility", visibility);
      if (used !== null) {
        const transform = `rotate(${-90 + used * 1.8}deg)`;
        if (this.needle.style.transform !== transform) this.needle.style.transform = transform;
      }
      this.value = used;
    }
  };

  // src/content/usage-strip.ts
  var UsageStrip = class {
    constructor(provider, doc) {
      this.provider = provider;
      this.doc = doc;
    }
    provider;
    doc;
    host = null;
    view = null;
    target = null;
    update(view) {
      this.view = view;
      this.mount();
    }
    mount() {
      const view = this.view, p = this.provider;
      if (!view || !shouldShowStrip(view, p)) {
        this.remove();
        return;
      }
      setLanguagePreference(view.settings.language);
      if ([...this.doc.querySelectorAll("#ai-gauge-usage-strip")].some((node) => node !== this.host)) {
        this.remove();
        return;
      }
      const next = findComposerTarget(this.doc, p);
      if (next) this.target = next;
      else if (!this.target || !retainsComposerTarget(this.target)) {
        this.remove();
        return;
      }
      const anchor = this.target.anchor;
      const snapshot = effectiveSnapshot(view.snapshots[displayProvider(p)]), limit = composerUsageLimit(displayProvider(p), snapshot.limits) ?? void 0;
      const parts = usageParts(snapshot, limit);
      if (!this.host) {
        this.host = this.doc.createElement("div");
        this.host.id = "ai-gauge-usage-strip";
        this.host.dataset.aiGaugeOwned = "usage-strip";
        this.host.lang = uiLanguage();
        const root = this.host.attachShadow({ mode: "closed" });
        const style = this.doc.createElement("style");
        style.textContent = `
${USAGE_GAUGE_CSS}
:host{display:block;position:static;box-sizing:border-box;width:100%;min-width:0;max-width:100%;height:30px;flex:0 0 auto;align-self:stretch;grid-column:1/-1;margin:0;border:0;background:transparent;font:12px/1.5 system-ui;color:inherit;container:ai-gauge/inline-size}
.usage{display:flex;align-items:center;gap:14px;box-sizing:border-box;height:30px;padding:0 10px;border:0;background:transparent;overflow:hidden}
.current{display:inline-flex;align-items:center;gap:6px;flex:0 0 auto;min-width:0;max-width:100%;overflow:hidden}
.current>span,.reset,.status{color:inherit;opacity:.8;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.reset,.status{min-width:0;max-width:100%}
.tickets{flex:0 0 auto;max-width:360px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;color:inherit;opacity:.8;text-decoration:underline;text-underline-offset:3px}
.tickets:focus-visible{outline:2px solid currentColor;outline-offset:2px;border-radius:2px}
.usage:has(.status:not([hidden])) .reset{display:none}
progress{appearance:none;-webkit-appearance:none;width:80px;max-width:100%;height:6px;flex:0 0 80px;box-sizing:border-box;border:0;border-radius:999px;overflow:hidden;background:#8893a033;color:inherit;accent-color:currentColor}
progress::-webkit-progress-bar{background:#8893a033;border-radius:999px}
progress::-webkit-progress-value{background:currentColor;border-radius:999px}
progress::-moz-progress-bar{background:currentColor;border-radius:999px}
@container ai-gauge (max-width:900px){.tickets{display:none}}
@container ai-gauge (max-width:520px){.reset{display:none}}
@container ai-gauge (max-width:280px){progress{display:none}}
@container ai-gauge (max-width:180px){.brand-icon{display:none}}
[hidden]{display:none!important}`;
        const row = this.doc.createElement("div");
        row.className = "usage";
        row.setAttribute("role", "status");
        row.setAttribute("aria-live", "polite");
        row.setAttribute("aria-atomic", "true");
        const current = this.doc.createElement("span");
        current.className = "current";
        this.currentText = this.doc.createElement("span");
        this.progress = this.doc.createElement("progress");
        this.progress.max = 100;
        this.progress.hidden = true;
        this.progress.setAttribute("aria-label", t("format_usage_name"));
        current.append(this.currentText, this.progress);
        this.gauge = new UsageGauge(this.doc, parts.percent, view.settings);
        current.prepend(this.gauge.element);
        this.resetText = this.doc.createElement("span");
        this.resetText.className = "reset";
        this.statusText = this.doc.createElement("span");
        this.statusText.className = "status";
        this.statusText.hidden = true;
        row.append(current, this.resetText, this.statusText);
        if (p !== "gemini") {
          this.ticketLink = this.doc.createElement("a");
          this.ticketLink.className = "tickets";
          this.ticketLink.hidden = true;
          this.ticketLink.target = "_blank";
          this.ticketLink.rel = "noopener noreferrer";
          row.append(this.ticketLink);
        }
        root.append(style, row);
      }
      if (anchor.nextElementSibling !== this.host) anchor.after(this.host);
      if (this.host.lang !== uiLanguage()) this.host.lang = uiLanguage();
      const progressLabel = t("format_usage_name");
      if (this.progress.getAttribute("aria-label") !== progressLabel) this.progress.setAttribute("aria-label", progressLabel);
      this.gauge.update(parts.percent, view.settings);
      if (this.currentText.textContent !== parts.current) this.currentText.textContent = parts.current;
      if (this.resetText.textContent !== parts.reset) this.resetText.textContent = parts.reset;
      const status = parts.status ?? "";
      if (this.statusText.textContent !== status) this.statusText.textContent = status;
      if (this.statusText.hidden !== (parts.status === null)) this.statusText.hidden = parts.status === null;
      if (this.progress.hidden !== (parts.percent === null)) this.progress.hidden = parts.percent === null;
      if (parts.percent === null) {
        if (this.progress.hasAttribute("value")) this.progress.removeAttribute("value");
      } else if (this.progress.getAttribute("value") !== String(parts.percent)) this.progress.setAttribute("value", String(parts.percent));
      if (this.ticketLink) {
        const tickets = inlineTicketDisplay(view.snapshots[displayProvider(p)]);
        if (this.ticketLink.hidden !== (tickets === null)) this.ticketLink.hidden = tickets === null;
        if (tickets) {
          if (this.ticketLink.textContent !== tickets.text) this.ticketLink.textContent = tickets.text;
          if (this.ticketLink.getAttribute("href") !== tickets.href) this.ticketLink.href = tickets.href;
          if (this.ticketLink.getAttribute("aria-label") !== tickets.accessible) this.ticketLink.setAttribute("aria-label", tickets.accessible);
        } else {
          if (this.ticketLink.textContent) this.ticketLink.textContent = "";
          for (const attribute of ["href", "aria-label", "aria-description", "title"]) if (this.ticketLink.hasAttribute(attribute)) this.ticketLink.removeAttribute(attribute);
        }
      }
      if (this.host.getAttribute("aria-label") !== parts.label) this.host.setAttribute("aria-label", parts.label);
    }
    currentText = null;
    resetText = null;
    statusText = null;
    progress = null;
    gauge = null;
    ticketLink = null;
    remove() {
      this.host?.remove();
      this.host = null;
      this.target = null;
      this.currentText = null;
      this.resetText = null;
      this.statusText = null;
      this.progress = null;
      this.ticketLink = null;
      this.gauge = null;
    }
  };

  // src/content/display-diagnostics.ts
  function authorizedDisplayRequest(message, sender, extensionId) {
    return sender.id === extensionId && !sender.tab && sender.url === `chrome-extension://${extensionId}/popup.html` && typeof message === "object" && message !== null && Object.keys(message).length === 1 && "type" in message && message.type === "display-diagnostics";
  }
  function visible2(element) {
    if (!isRendered(element)) return false;
    const win = element.ownerDocument.defaultView;
    if (!win) return false;
    return [...element.getClientRects()].some((box) => box.width > 1 && box.height > 1 && box.right > 0 && box.bottom > 0 && box.left < win.innerWidth && box.top < win.innerHeight);
  }
  function createDisplayDiagnostic(doc, provider) {
    const strips = [...doc.querySelectorAll("#ai-gauge-usage-strip")];
    return {
      status: "ready",
      provider,
      contentReady: true,
      editableCount: Math.min(1e4, doc.querySelectorAll("[contenteditable],textarea").length),
      iframeCount: Math.min(1e4, doc.querySelectorAll("iframe").length),
      targetFound: findComposerTarget(doc, provider) !== null,
      stripCount: Math.min(1e4, strips.length),
      stripVisible: strips.some(visible2)
    };
  }

  // src/content/page-provider.ts
  function resolvePageProvider(doc, url) {
    const provider = providerFromUrl(url);
    return provider === "chatgpt" && hasCodexFooter(doc) ? "codex" : provider;
  }

  // src/shared/build-mode.ts
  var DEVELOPMENT = true;

  // src/content/view-requests.ts
  var LoadQueue = class {
    running = false;
    again = false;
    queued = /* @__PURE__ */ new Set();
    get busy() {
      return this.running;
    }
    defer(refresh) {
      this.again = true;
      if (refresh) this.queued.add(refresh);
    }
    start() {
      this.running = true;
    }
    requestAgain() {
      this.again = true;
    }
    /** Ends the running request; returns the follow-up to run, or null when none is due. */
    finish() {
      this.running = false;
      if (!this.again && !this.queued.size) return null;
      this.again = false;
      const refresh = this.queued.values().next().value;
      if (refresh) this.queued.delete(refresh);
      return { refresh };
    }
  };
  var RetryTimer = class {
    constructor(run) {
      this.run = run;
    }
    run;
    timer = null;
    failures = 0;
    succeeded() {
      this.failures = 0;
      if (this.timer) {
        clearTimeout(this.timer);
        this.timer = null;
      }
    }
    failed() {
      this.failures++;
      if (!this.timer) this.timer = setTimeout(() => {
        this.timer = null;
        this.run();
      }, Math.min(3e4, 1e3 * 2 ** Math.min(this.failures - 1, 5)));
    }
    cancel() {
      if (this.timer) clearTimeout(this.timer);
    }
  };
  var CompletionWatcher = class {
    constructor(view, onDue) {
      this.view = view;
      this.onDue = onDue;
    }
    view;
    onDue;
    timer = null;
    source = null;
    lastSignal = 0;
    arm(source) {
      this.source = source;
      this.schedule();
    }
    clear() {
      if (this.timer) clearTimeout(this.timer);
      this.timer = null;
      this.source = null;
    }
    schedule() {
      const view = this.view();
      if (!this.source || !view) return;
      const source = this.source, snapshot = view.snapshots[source];
      if (!view.settings.enabled[source] || !view.permissions[source] || ["signed_out", "permission_required", "unsupported"].includes(snapshot.state)) {
        this.clear();
        return;
      }
      const earliest = Math.max(snapshot.nextAttemptAt, snapshot.checkedAt === null ? 0 : snapshot.checkedAt + 6e4, this.lastSignal + 6e4);
      const delay = earliest - Date.now();
      if (this.timer) {
        clearTimeout(this.timer);
        this.timer = null;
      }
      if (delay > 0) this.timer = setTimeout(() => {
        this.timer = null;
        this.schedule();
      }, Math.min(delay + 100, 2147483647));
      else {
        this.source = null;
        this.lastSignal = Date.now();
        this.onDue(source);
      }
    }
  };

  // src/content/mutations.ts
  var ownNode = (node) => {
    const element = node.nodeType === Node.ELEMENT_NODE ? node : node.parentElement;
    return !!element?.closest("#ai-gauge-usage-strip");
  };
  function hasExternalChange(records) {
    return records.some((record2) => {
      if (ownNode(record2.target)) return false;
      const changed = [...record2.addedNodes, ...record2.removedNodes];
      return record2.type !== "childList" || changed.length === 0 || changed.some((node) => !ownNode(node)) || [...record2.removedNodes].some((node) => !node.isConnected);
    });
  }
  var OBSERVED_ATTRIBUTES = ["hidden", "aria-hidden", "inert", "open", "role", "style", "class", "contenteditable", "aria-label", "data-testid", "data-test-id", "data-cds"];

  // src/content/index.ts
  if (resolvePageProvider(document, location.href) && !window.__aiGaugeMounted) {
    window.__aiGaugeMounted = true;
    let provider = null, strip = null, view = null;
    let stopped = false, timer = null, wasStreaming = false;
    let clockTimer = null;
    let routeUrl = null;
    let contextPending = false;
    const queue = new LoadQueue();
    const retry = new RetryTimer(() => {
      void load();
    });
    const completion = new CompletionWatcher(() => stopped ? null : view, (source) => {
      void load(source);
    });
    const route = () => {
      const next = resolvePageProvider(document, location.href);
      const navigated = routeUrl !== null && routeUrl !== location.href;
      if (navigated || next !== provider) {
        contextPending = true;
        completion.clear();
      }
      routeUrl = location.href;
      if (next === provider) {
        if (navigated) wasStreaming = next ? hasStreamingControl(document, next) : false;
        return navigated;
      }
      strip?.remove();
      provider = next;
      strip = next ? new UsageStrip(next, document) : null;
      wasStreaming = next ? hasStreamingControl(document, next) : false;
      if (view) strip?.update(view);
      return true;
    };
    const stop = () => {
      stopped = true;
      window.__aiGaugeMounted = false;
      strip?.remove();
      observer.disconnect();
      if (timer) clearTimeout(timer);
      retry.cancel();
      if (clockTimer) clearInterval(clockTimer);
      completion.clear();
      document.removeEventListener("focusin", scheduleCheck);
      document.removeEventListener("visibilitychange", onVisible);
      window.removeEventListener("popstate", onRoute);
      chrome.runtime.onMessage.removeListener(onMessage);
      chrome.storage.onChanged.removeListener(onStorage);
    };
    const load = async (refresh) => {
      if (stopped) return;
      if (queue.busy) {
        queue.defer(refresh);
        return;
      }
      route();
      if (!provider) return;
      const current = provider;
      queue.start();
      const context = contextPending;
      contextPending = false;
      try {
        const nextView = await request(context ? { type: "context", provider: displayProvider(current) } : refresh && canRefreshFromPage(current, refresh) ? { type: "refresh", provider: refresh, trigger: "event" } : { type: "view" });
        if (stopped) return;
        view = nextView;
        retry.succeeded();
        route();
        if (contextPending) queue.requestAgain();
        strip?.update(view);
        const group = SITE_GROUPS.find((g) => g.providers.includes(current));
        if (!view.permissions[displayProvider(current)] || !group || !needsContent(view, group.providers)) stop();
        else completion.schedule();
      } catch {
        if (stopped) return;
        if (context) contextPending = true;
        let live = false;
        try {
          live = Boolean(chrome.runtime.id);
        } catch {
        }
        if (!live) stop();
        else {
          strip?.mount();
          retry.failed();
        }
      } finally {
        const next = queue.finish();
        if (!stopped && next) void load(next.refresh);
      }
    };
    const check = () => {
      if (timer) clearTimeout(timer);
      timer = null;
      if (stopped) return;
      const changed = route();
      strip?.mount();
      if (!provider) return;
      if (changed || contextPending) void load(displayProvider(provider));
      const streaming = hasStreamingControl(document, provider);
      if (wasStreaming && !streaming) completion.arm(displayProvider(provider));
      wasStreaming = streaming;
    };
    const scheduleCheck = () => {
      if (!timer && !stopped) timer = setTimeout(check, 300);
    };
    const observer = new MutationObserver((records) => {
      if (stopped || !hasExternalChange(records)) return;
      if (provider && hasStreamingControl(document, provider)) wasStreaming = true;
      scheduleCheck();
    });
    observer.observe(document, { childList: true, subtree: true, attributes: true, attributeFilter: OBSERVED_ATTRIBUTES });
    const onMessage = (message, sender, sendResponse) => {
      if (DEVELOPMENT && authorizedDisplayRequest(message, sender, chrome.runtime.id)) {
        const current = resolvePageProvider(document, location.href);
        if (!stopped && current) sendResponse?.(createDisplayDiagnostic(document, current));
        return;
      }
      if (sender.id !== chrome.runtime.id || typeof message !== "object" || message === null || !("type" in message)) return;
      if (message.type === "permissions-revoked" && "origins" in message && Array.isArray(message.origins)) {
        const origin = SITE_GROUPS.find((site) => provider && site.providers.includes(provider))?.origin;
        if (origin && message.origins.includes(origin)) stop();
      } else if (message.type === "invalidate") void load();
    };
    const onStorage = (changes, areaName) => {
      if (affectsView(changes, areaName)) void load();
    };
    const onVisible = () => {
      if (document.visibilityState === "visible") {
        check();
        void load(provider ? displayProvider(provider) : void 0);
      }
    };
    const onRoute = () => {
      check();
    };
    chrome.runtime.onMessage.addListener(onMessage);
    chrome.storage.onChanged.addListener(onStorage);
    document.addEventListener("focusin", scheduleCheck);
    document.addEventListener("visibilitychange", onVisible);
    window.addEventListener("popstate", onRoute);
    clockTimer = setInterval(check, 15e3);
    void load();
  }
})();
