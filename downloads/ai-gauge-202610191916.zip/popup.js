// src/shared/types.ts
var PROVIDERS = ["chatgpt", "claude", "gemini"];
var PAGE_PROVIDERS = ["chatgpt", "codex", "claude", "gemini"];
var ORIGINS = { chatgpt: "https://chatgpt.com/*", claude: "https://claude.ai/*", gemini: "https://gemini.google.com/*" };
var NAMES = { chatgpt: "ChatGPT", claude: "Claude", gemini: "Gemini" };
var HOME_URLS = { chatgpt: "https://chatgpt.com/", claude: "https://claude.ai/", gemini: "https://gemini.google.com/" };
var GEMINI_RESPONSE_ERRORS = ["gemini_response_type", "gemini_response_read", "gemini_frame_invalid", "gemini_rpc_missing", "gemini_rpc_invalid", "gemini_quota_invalid"];
var SITE_GROUPS = [
  { id: "openai", origin: ORIGINS.chatgpt, providers: ["chatgpt", "codex"] },
  { id: "claude", origin: ORIGINS.claude, providers: ["claude"] },
  { id: "gemini", origin: ORIGINS.gemini, providers: ["gemini"] }
];
function providerFromUrl(url) {
  try {
    const u = new URL(url ?? "");
    if (u.protocol !== "https:") return null;
    if (u.hostname === "claude.ai") return "claude";
    if (u.hostname === "gemini.google.com") return "gemini";
    if (u.hostname === "chatgpt.com") return /^\/(codex|work)(?:\/|$)/.test(u.pathname) ? "codex" : "chatgpt";
    return null;
  } catch {
    return null;
  }
}

// src/shared/validation.ts
function record(v) {
  return v !== null && typeof v === "object" && !Array.isArray(v) ? v : null;
}
var finite = (v) => typeof v === "number" && Number.isFinite(v);
var percent = (v) => finite(v) && v >= 0 && v <= 100 ? v : null;
var nonnegative = (v) => finite(v) && v >= 0 ? v : null;
function label(v) {
  return typeof v === "string" && v.trim().length > 0 && v.length <= 120 && !/[\u0000-\u001f\u007f]/.test(v) ? v.trim() : null;
}
function resetTime(v) {
  if (typeof v !== "string") return null;
  const parts = /^(\d{4})-(\d{2})-(\d{2})T(\d{2}):(\d{2}):(\d{2})(?:\.\d+)?(?:Z|[+-]\d{2}:\d{2})$/.exec(v);
  if (!parts) return null;
  const [year, month, day, hour, minute, second] = parts.slice(1, 7).map(Number);
  if (month < 1 || month > 12 || day < 1 || day > new Date(Date.UTC(year, month, 0)).getUTCDate() || hour > 23 || minute > 59 || second > 59) return null;
  const ms = Date.parse(v);
  return Number.isFinite(ms) && ms > 0 && ms < 41024448e5 ? new Date(ms).toISOString() : null;
}

// src/storage/settings.ts
var inRange = (value) => finite(value) && value >= 0 && value <= 100;
function checkUsageThresholds(warning, danger) {
  const fields = ["warning", "danger"].filter((_, index) => !inRange(index === 0 ? warning : danger));
  if (fields.length) return { ok: false, reason: "range", fields };
  if (warning >= danger) return { ok: false, reason: "order", fields: ["warning", "danger"] };
  return { ok: true, value: { warning, danger } };
}
function parseUsageThresholds(warning, danger) {
  const result = checkUsageThresholds(warning, danger);
  return result.ok ? result.value : null;
}
function parseStrips(value) {
  const strips = record(value);
  return strips && Object.keys(strips).length === PAGE_PROVIDERS.length && PAGE_PROVIDERS.every((p) => typeof strips[p] === "boolean") ? Object.fromEntries(PAGE_PROVIDERS.map((p) => [p, strips[p]])) : null;
}
var isLanguagePreference = (value) => value === "system" || value === "en" || value === "ko";
function isSettings(value) {
  const r = record(value), enabled = record(r?.enabled);
  return !!r && !!enabled && PROVIDERS.every((p) => typeof enabled[p] === "boolean") && isLanguagePreference(r.language) && parseStrips(r.strips) !== null && parseUsageThresholds(r.warning, r.danger) !== null;
}

// _locales/en/messages.json
var messages_default = {
  badge_disabled: {
    message: "Disabled"
  },
  badge_permission_required: {
    message: "Permission required"
  },
  badge_usage_unknown: {
    message: "Usage unavailable"
  },
  diagnostics_checking_tab: {
    message: "Checking the display in the current tab."
  },
  diagnostics_copied: {
    message: "Diagnostics copied."
  },
  diagnostics_copy: {
    message: "Copy diagnostics"
  },
  diagnostics_copy_failed: {
    message: "Clipboard access was denied. The text is selected so you can copy it manually."
  },
  diagnostics_description: {
    message: "Shows the version, settings, errors, timestamps, and display target and element counts in the current tab. No input, account details, or URLs are included. Nothing is sent automatically."
  },
  diagnostics_not_ready: {
    message: "Status is not available yet. Please try again shortly."
  },
  diagnostics_output_label: {
    message: "Local diagnostics"
  },
  diagnostics_show: {
    message: "Show current status"
  },
  diagnostics_shown: {
    message: "Current status shown. Nothing is sent automatically."
  },
  diagnostics_title: {
    message: "Diagnostics"
  },
  error_access_denied: {
    message: "The site denied access. Security protections are not bypassed."
  },
  error_ambiguous_account: {
    message: "Multiple Claude organizations were found. Check usage settings in your account."
  },
  error_invalid_response: {
    message: "The usage response format could not be recognized."
  },
  error_network: {
    message: "The connection failed or the request timed out."
  },
  error_not_collected: {
    message: "Usage has not been collected yet."
  },
  error_open_tab: {
    message: "Open a signed-in service tab, then reopen the popup."
  },
  error_permission_required: {
    message: "Site access permission is required for this service."
  },
  error_rate_limited: {
    message: "Request limit reached. Please wait until the next retry."
  },
  error_server: {
    message: "The service returned an error. Another attempt will be made shortly."
  },
  error_signed_out: {
    message: "Sign in to the site, then reopen the popup."
  },
  error_tab_access_failed: {
    message: "Usage collection could not run in the open service tab. The last valid usage is kept while automatic retries continue."
  },
  error_unsupported: {
    message: "A safe collection method could not be verified. This service is unsupported."
  },
  extension_description: {
    message: "A local-only extension showing ChatGPT, Claude and Gemini usage and reset times."
  },
  format_duration_left: {
    message: "$1 left"
  },
  format_last_collected: {
    message: "Last successful collection: $1"
  },
  format_less_than_minute: {
    message: "in less than a minute"
  },
  format_not_collected: {
    message: "No successful collection yet"
  },
  format_relative_day_one: {
    message: "in $1 day"
  },
  format_relative_day_other: {
    message: "in $1 days"
  },
  format_relative_hour_one: {
    message: "in $1 hour"
  },
  format_relative_hour_other: {
    message: "in $1 hours"
  },
  format_relative_minute_one: {
    message: "in $1 minute"
  },
  format_relative_minute_other: {
    message: "in $1 minutes"
  },
  format_remaining: {
    message: "$1 remaining"
  },
  format_remaining_unknown: {
    message: "Time remaining unavailable"
  },
  format_reset_countdown: {
    message: "\u{1F552} Resets $1"
  },
  format_reset_pending: {
    message: "Checking after reset"
  },
  format_reset_popup: {
    message: "\u{1F552} Reset: $1"
  },
  format_reset_unavailable: {
    message: "\u{1F552} Reset: $1"
  },
  format_unknown: {
    message: "Unavailable"
  },
  format_usage: {
    message: "Usage: $1"
  },
  format_usage_name: {
    message: "Usage"
  },
  limit_additional: {
    message: "Additional limit"
  },
  limit_days_one: {
    message: "$1 day"
  },
  limit_days_other: {
    message: "$1 days"
  },
  limit_hours_one: {
    message: "$1 hour"
  },
  limit_hours_other: {
    message: "$1 hours"
  },
  limit_legacy_shared: {
    message: "Work / Codex shared"
  },
  limit_primary: {
    message: "Primary limit"
  },
  limit_weekly: {
    message: "Weekly"
  },
  popup_communication_failed: {
    message: "Cannot communicate with the extension. Please reload it."
  },
  popup_danger_threshold: {
    message: "Warning starts at"
  },
  popup_disable: {
    message: "Disable"
  },
  popup_disabled: {
    message: "Off"
  },
  popup_enable: {
    message: "Enable"
  },
  popup_grant_enable: {
    message: "Grant access and enable"
  },
  popup_language: {
    message: "Language"
  },
  popup_language_english: {
    message: "English"
  },
  popup_language_korean: {
    message: "Korean"
  },
  popup_language_system: {
    message: "System default"
  },
  popup_limit_previous_usage: {
    message: "$1 usage (previous value)"
  },
  popup_limit_usage: {
    message: "$1 usage"
  },
  popup_local_only: {
    message: "Local only"
  },
  popup_onboarding_description: {
    message: "Grant access to your selected services together to view usage."
  },
  popup_onboarding_start: {
    message: "Grant access and start"
  },
  popup_onboarding_title: {
    message: "Choose your services"
  },
  popup_open_site: {
    message: "Open $1 (new tab)"
  },
  popup_permission_canceled: {
    message: "Access request canceled."
  },
  popup_previous_usage: {
    message: "Previous usage"
  },
  popup_provider_plan: {
    message: "$1 plan: $2"
  },
  popup_provider_usage: {
    message: "$1 usage"
  },
  popup_revoke: {
    message: "Revoke access"
  },
  popup_settings: {
    message: "Settings"
  },
  popup_settings_saved: {
    message: "Settings saved."
  },
  popup_show_in_composer: {
    message: "Show below $1 input"
  },
  popup_threshold_order_error: {
    message: "The caution threshold must be lower than the warning threshold."
  },
  popup_threshold_range_error: {
    message: "Enter caution and warning thresholds between 0 and 100."
  },
  popup_usage_unavailable: {
    message: "Usage unavailable"
  },
  popup_warning_threshold: {
    message: "Caution starts at"
  },
  status_access_denied: {
    message: "Site access denied"
  },
  status_ambiguous_account: {
    message: "Select a Claude organization"
  },
  status_invalid_response: {
    message: "Usage unavailable"
  },
  status_network: {
    message: "Checking connection"
  },
  status_not_collected: {
    message: "Checking usage"
  },
  status_ok: {
    message: "Successfully collected"
  },
  status_open_tab: {
    message: "Open a service tab"
  },
  status_permission_required: {
    message: "Site permission required"
  },
  status_rate_limited: {
    message: "Check again shortly"
  },
  status_server: {
    message: "Waiting for service"
  },
  status_signed_out: {
    message: "Sign in required"
  },
  status_tab_access_failed: {
    message: "Rechecking usage"
  },
  status_unsupported: {
    message: "Usage collection unsupported"
  },
  ticket_availability_unknown: {
    message: "Availability unknown"
  },
  ticket_blocked: {
    message: "Currently restricted"
  },
  ticket_count_one: {
    message: "$1 ticket"
  },
  ticket_count_other: {
    message: "$1 tickets"
  },
  ticket_expiry: {
    message: "Expires $1"
  },
  ticket_inline: {
    message: "\u{1F3AB} Ticket expires $1"
  },
  ticket_kind_five_hour: {
    message: "5-hour limit"
  },
  ticket_kind_full: {
    message: "All limits"
  },
  ticket_kind_unspecified: {
    message: "Unknown type"
  },
  ticket_kind_weekly: {
    message: "Weekly limit"
  },
  ticket_management_action: {
    message: "Open official usage settings (new tab)"
  },
  ticket_other_first: {
    message: "Another ticket takes priority"
  },
  ticket_requires_limit: {
    message: "Limit must be reached"
  },
  ticket_starts: {
    message: "From $1"
  },
  ticket_total_one: {
    message: "\u{1F3AB} $1 reset ticket"
  },
  ticket_total_other: {
    message: "\u{1F3AB} $1 reset tickets"
  },
  ticket_unavailable_now: {
    message: "Not currently usable"
  }
};

// _locales/ko/messages.json
var messages_default2 = {
  badge_disabled: {
    message: "\uBE44\uD65C\uC131"
  },
  badge_permission_required: {
    message: "\uAD8C\uD55C \uD544\uC694"
  },
  badge_usage_unknown: {
    message: "\uC0AC\uC6A9\uB960 \uD655\uC778 \uBD88\uAC00"
  },
  diagnostics_checking_tab: {
    message: "\uD604\uC7AC \uD0ED\uC758 \uD45C\uC2DC \uC0C1\uD0DC\uB97C \uD655\uC778\uD558\uACE0 \uC788\uC2B5\uB2C8\uB2E4."
  },
  diagnostics_copied: {
    message: "\uC9C4\uB2E8 \uC815\uBCF4\uB97C \uBCF5\uC0AC\uD588\uC2B5\uB2C8\uB2E4."
  },
  diagnostics_copy: {
    message: "\uC9C4\uB2E8 \uC815\uBCF4 \uBCF5\uC0AC"
  },
  diagnostics_copy_failed: {
    message: "\uC790\uB3D9 \uBCF5\uC0AC\uAC00 \uD5C8\uC6A9\uB418\uC9C0 \uC54A\uC544 \uB0B4\uC6A9\uC744 \uC120\uD0DD\uD588\uC2B5\uB2C8\uB2E4. \uC9C1\uC811 \uBCF5\uC0AC\uD574 \uC8FC\uC138\uC694."
  },
  diagnostics_description: {
    message: "\uBC84\uC804\xB7\uC124\uC815\xB7\uC624\uB958\xB7\uC2DC\uAC01\uACFC \uD604\uC7AC \uD0ED\uC758 \uD45C\uC2DC \uB300\uC0C1 \uBC1C\uACAC \uC5EC\uBD80\xB7\uC694\uC18C \uAC1C\uC218\uB9CC \uD655\uC778\uD569\uB2C8\uB2E4. \uC785\uB825 \uB0B4\uC6A9\xB7\uACC4\uC815\xB7URL\uC740 \uD3EC\uD568\uD558\uC9C0 \uC54A\uC73C\uBA70 \uC790\uB3D9\uC73C\uB85C \uC804\uC1A1\uB418\uC9C0 \uC54A\uC2B5\uB2C8\uB2E4."
  },
  diagnostics_not_ready: {
    message: "\uC0C1\uD0DC\uB97C \uC544\uC9C1 \uC77D\uC9C0 \uBABB\uD588\uC2B5\uB2C8\uB2E4. \uC7A0\uC2DC \uD6C4 \uB2E4\uC2DC \uB20C\uB7EC \uC8FC\uC138\uC694."
  },
  diagnostics_output_label: {
    message: "\uB85C\uCEEC \uC9C4\uB2E8 \uC815\uBCF4"
  },
  diagnostics_show: {
    message: "\uD604\uC7AC \uC0C1\uD0DC \uBCF4\uAE30"
  },
  diagnostics_shown: {
    message: "\uD604\uC7AC \uC0C1\uD0DC\uB97C \uD45C\uC2DC\uD588\uC2B5\uB2C8\uB2E4. \uC790\uB3D9\uC73C\uB85C \uC804\uC1A1\uB418\uC9C0 \uC54A\uC2B5\uB2C8\uB2E4."
  },
  diagnostics_title: {
    message: "\uC9C4\uB2E8 \uC815\uBCF4"
  },
  error_access_denied: {
    message: "\uC0AC\uC774\uD2B8\uAC00 \uC811\uADFC\uC744 \uAC70\uBD80\uD588\uC2B5\uB2C8\uB2E4. \uBCF4\uD638\uC7A5\uCE58\uB97C \uC6B0\uD68C\uD558\uC9C0 \uC54A\uC2B5\uB2C8\uB2E4."
  },
  error_ambiguous_account: {
    message: "\uC5EC\uB7EC Claude \uC870\uC9C1\uC774 \uD655\uC778\uB418\uC5B4 \uC120\uD0DD\uD560 \uC218 \uC5C6\uC2B5\uB2C8\uB2E4. \uACC4\uC815\uC758 \uC0AC\uC6A9\uB7C9 \uD654\uBA74\uC744 \uD655\uC778\uD574 \uC8FC\uC138\uC694."
  },
  error_invalid_response: {
    message: "\uC0AC\uC6A9\uB7C9 \uC751\uB2F5 \uD615\uC2DD\uC744 \uD655\uC778\uD560 \uC218 \uC5C6\uC2B5\uB2C8\uB2E4."
  },
  error_network: {
    message: "\uC5F0\uACB0 \uB610\uB294 \uC694\uCCAD \uC2DC\uAC04\uC774 \uCD08\uACFC\uB418\uC5C8\uC2B5\uB2C8\uB2E4."
  },
  error_not_collected: {
    message: "\uC544\uC9C1 \uC218\uC9D1\uD558\uC9C0 \uC54A\uC558\uC2B5\uB2C8\uB2E4."
  },
  error_open_tab: {
    message: "\uB85C\uADF8\uC778\uD55C \uC11C\uBE44\uC2A4 \uD0ED\uC744 \uC5F0 \uB4A4 \uD31D\uC5C5\uC744 \uB2E4\uC2DC \uC5F4\uC5B4 \uC8FC\uC138\uC694."
  },
  error_permission_required: {
    message: "\uC774 \uC11C\uBE44\uC2A4\uC758 \uC0AC\uC774\uD2B8 \uC811\uADFC \uAD8C\uD55C\uC774 \uD544\uC694\uD569\uB2C8\uB2E4."
  },
  error_rate_limited: {
    message: "\uC694\uCCAD \uD55C\uB3C4\uC5D0 \uB3C4\uB2EC\uD588\uC2B5\uB2C8\uB2E4. \uC7AC\uC2DC\uB3C4 \uC2DC\uAC01\uAE4C\uC9C0 \uAE30\uB2E4\uB824 \uC8FC\uC138\uC694."
  },
  error_server: {
    message: "\uC11C\uBE44\uC2A4 \uC624\uB958\uC785\uB2C8\uB2E4. \uC7A0\uC2DC \uD6C4 \uB2E4\uC2DC \uC2DC\uB3C4\uD569\uB2C8\uB2E4."
  },
  error_signed_out: {
    message: "\uC0AC\uC774\uD2B8\uC5D0 \uB85C\uADF8\uC778\uD55C \uB4A4 \uD31D\uC5C5\uC744 \uB2E4\uC2DC \uC5F4\uC5B4 \uC8FC\uC138\uC694."
  },
  error_tab_access_failed: {
    message: "\uC5F4\uB9B0 \uC11C\uBE44\uC2A4 \uD0ED\uC5D0\uC11C \uC218\uC9D1 \uCF54\uB4DC\uB97C \uC2E4\uD589\uD558\uC9C0 \uBABB\uD588\uC2B5\uB2C8\uB2E4. \uB9C8\uC9C0\uB9C9 \uC720\uD6A8 \uC0AC\uC6A9\uB7C9\uC744 \uC720\uC9C0\uD558\uBA70 \uC790\uB3D9\uC73C\uB85C \uB2E4\uC2DC \uC2DC\uB3C4\uD569\uB2C8\uB2E4."
  },
  error_unsupported: {
    message: "\uC548\uC804\uD55C \uC218\uC9D1 \uACC4\uC57D\uC744 \uAC80\uC99D\uD558\uC9C0 \uBABB\uD574 \uBBF8\uC9C0\uC6D0\uC785\uB2C8\uB2E4."
  },
  extension_description: {
    message: "ChatGPT, Claude, Gemini \uC0AC\uC6A9\uB7C9\uACFC \uCD08\uAE30\uD654 \uC2DC\uAC01\uC744 \uBCF4\uC5EC\uC8FC\uB294 \uB85C\uCEEC \uC804\uC6A9 \uD655\uC7A5\uC785\uB2C8\uB2E4."
  },
  format_duration_left: {
    message: "$1 \uB0A8\uC74C"
  },
  format_last_collected: {
    message: "\uB9C8\uC9C0\uB9C9 \uC815\uC0C1 \uC218\uC9D1: $1"
  },
  format_less_than_minute: {
    message: "1\uBD84 \uBBF8\uB9CC"
  },
  format_not_collected: {
    message: "\uC815\uC0C1 \uC218\uC9D1 \uAE30\uB85D \uC5C6\uC74C"
  },
  format_relative_day_one: {
    message: "$1\uC77C \uD6C4"
  },
  format_relative_day_other: {
    message: "$1\uC77C \uD6C4"
  },
  format_relative_hour_one: {
    message: "$1\uC2DC\uAC04 \uD6C4"
  },
  format_relative_hour_other: {
    message: "$1\uC2DC\uAC04 \uD6C4"
  },
  format_relative_minute_one: {
    message: "$1\uBD84 \uD6C4"
  },
  format_relative_minute_other: {
    message: "$1\uBD84 \uD6C4"
  },
  format_remaining: {
    message: "$1 \uB0A8\uC74C"
  },
  format_remaining_unknown: {
    message: "\uB0A8\uC740 \uC2DC\uAC04 \uD655\uC778 \uBD88\uAC00"
  },
  format_reset_countdown: {
    message: "\u{1F552} \uCD08\uAE30\uD654: $1"
  },
  format_reset_pending: {
    message: "\uCD08\uAE30\uD654 \uD6C4 \uD655\uC778 \uC911"
  },
  format_reset_popup: {
    message: "\u{1F552} \uC0AC\uC6A9\uB7C9 \uCD08\uAE30\uD654: $1"
  },
  format_reset_unavailable: {
    message: "\u{1F552} \uCD08\uAE30\uD654: $1"
  },
  format_unknown: {
    message: "\uD655\uC778 \uBD88\uAC00"
  },
  format_usage: {
    message: "\uC0AC\uC6A9\uB7C9: $1"
  },
  format_usage_name: {
    message: "\uC0AC\uC6A9\uB7C9"
  },
  limit_additional: {
    message: "\uCD94\uAC00 \uC81C\uD55C"
  },
  limit_days_one: {
    message: "$1\uC77C"
  },
  limit_days_other: {
    message: "$1\uC77C"
  },
  limit_hours_one: {
    message: "$1\uC2DC\uAC04"
  },
  limit_hours_other: {
    message: "$1\uC2DC\uAC04"
  },
  limit_legacy_shared: {
    message: "Work / Codex \uACF5\uC720"
  },
  limit_primary: {
    message: "\uAE30\uBCF8 \uC81C\uD55C"
  },
  limit_weekly: {
    message: "\uC8FC\uAC04"
  },
  popup_communication_failed: {
    message: "\uD655\uC7A5 \uD504\uB85C\uADF8\uB7A8\uACFC \uD1B5\uC2E0\uD560 \uC218 \uC5C6\uC2B5\uB2C8\uB2E4. \uD655\uC7A5\uC744 \uB2E4\uC2DC \uB85C\uB4DC\uD574 \uC8FC\uC138\uC694."
  },
  popup_danger_threshold: {
    message: "\uACBD\uACE0 \uC2DC\uC791 \uC0AC\uC6A9\uB960"
  },
  popup_disable: {
    message: "\uB044\uAE30"
  },
  popup_disabled: {
    message: "\uAEBC\uC9D0"
  },
  popup_enable: {
    message: "\uCF1C\uAE30"
  },
  popup_grant_enable: {
    message: "\uAD8C\uD55C \uC2B9\uC778 \uBC0F \uCF1C\uAE30"
  },
  popup_language: {
    message: "\uC5B8\uC5B4"
  },
  popup_language_english: {
    message: "\uC601\uC5B4"
  },
  popup_language_korean: {
    message: "\uD55C\uAD6D\uC5B4"
  },
  popup_language_system: {
    message: "\uC2DC\uC2A4\uD15C \uAE30\uBCF8 \uC5B8\uC5B4"
  },
  popup_limit_previous_usage: {
    message: "$1 \uC0AC\uC6A9\uB7C9 (\uC774\uC804 \uAC12)"
  },
  popup_limit_usage: {
    message: "$1 \uC0AC\uC6A9\uB7C9"
  },
  popup_local_only: {
    message: "\uB85C\uCEEC \uC804\uC6A9"
  },
  popup_onboarding_description: {
    message: "\uC120\uD0DD\uD55C \uC11C\uBE44\uC2A4\uC758 \uAD8C\uD55C\uC744 \uD55C \uBC88\uC5D0 \uD5C8\uC6A9\uD558\uACE0 \uC0AC\uC6A9\uB7C9\uC744 \uD655\uC778\uD569\uB2C8\uB2E4."
  },
  popup_onboarding_start: {
    message: "\uAD8C\uD55C \uD5C8\uC6A9 \uBC0F \uC2DC\uC791"
  },
  popup_onboarding_title: {
    message: "\uC0AC\uC6A9\uD560 \uC11C\uBE44\uC2A4\uB97C \uC120\uD0DD\uD558\uC138\uC694"
  },
  popup_open_site: {
    message: "$1 \uC0AC\uC774\uD2B8 \uC5F4\uAE30 (\uC0C8 \uD0ED)"
  },
  popup_permission_canceled: {
    message: "\uAD8C\uD55C \uC2B9\uC778\uC774 \uCDE8\uC18C\uB418\uC5C8\uC2B5\uB2C8\uB2E4."
  },
  popup_previous_usage: {
    message: "\uC774\uC804 \uC218\uC9D1\uAC12"
  },
  popup_provider_plan: {
    message: "$1 \uC694\uAE08\uC81C: $2"
  },
  popup_provider_usage: {
    message: "$1 \uC0AC\uC6A9\uB7C9"
  },
  popup_revoke: {
    message: "\uAD8C\uD55C \uCCA0\uD68C"
  },
  popup_settings: {
    message: "\uC124\uC815"
  },
  popup_settings_saved: {
    message: "\uC124\uC815\uC744 \uC800\uC7A5\uD588\uC2B5\uB2C8\uB2E4."
  },
  popup_show_in_composer: {
    message: "$1 \uC785\uB825\uCC3D\uC5D0 \uD45C\uC2DC"
  },
  popup_threshold_order_error: {
    message: "\uC8FC\uC758 \uC2DC\uC791 \uC0AC\uC6A9\uB960\uC740 \uACBD\uACE0 \uC2DC\uC791 \uC0AC\uC6A9\uB960\uBCF4\uB2E4 \uC791\uC544\uC57C \uD569\uB2C8\uB2E4."
  },
  popup_threshold_range_error: {
    message: "\uC8FC\uC758\xB7\uACBD\uACE0 \uC2DC\uC791 \uC0AC\uC6A9\uB960\uC740 0~100 \uC0AC\uC774\uC758 \uC22B\uC790\uB85C \uC785\uB825\uD574 \uC8FC\uC138\uC694."
  },
  popup_usage_unavailable: {
    message: "\uC0AC\uC6A9\uB7C9 \uD655\uC778 \uBD88\uAC00"
  },
  popup_warning_threshold: {
    message: "\uC8FC\uC758 \uC2DC\uC791 \uC0AC\uC6A9\uB960"
  },
  status_access_denied: {
    message: "\uC0AC\uC774\uD2B8 \uC811\uADFC \uAC70\uBD80"
  },
  status_ambiguous_account: {
    message: "Claude \uC870\uC9C1 \uC120\uD0DD \uD544\uC694"
  },
  status_invalid_response: {
    message: "\uC0AC\uC6A9\uB7C9 \uD655\uC778 \uBD88\uAC00"
  },
  status_network: {
    message: "\uC5F0\uACB0 \uD655\uC778 \uC911"
  },
  status_not_collected: {
    message: "\uC0AC\uC6A9\uB7C9 \uD655\uC778 \uC911"
  },
  status_ok: {
    message: "\uCD5C\uADFC \uC218\uC9D1 \uC131\uACF5"
  },
  status_open_tab: {
    message: "\uC11C\uBE44\uC2A4 \uD0ED \uC5F4\uAE30 \uD544\uC694"
  },
  status_permission_required: {
    message: "\uC0AC\uC774\uD2B8 \uAD8C\uD55C \uD544\uC694"
  },
  status_rate_limited: {
    message: "\uC7A0\uC2DC \uD6C4 \uB2E4\uC2DC \uD655\uC778"
  },
  status_server: {
    message: "\uC11C\uBE44\uC2A4 \uC751\uB2F5 \uB300\uAE30"
  },
  status_signed_out: {
    message: "\uB85C\uADF8\uC778 \uD544\uC694"
  },
  status_tab_access_failed: {
    message: "\uC0AC\uC6A9\uB7C9 \uB2E4\uC2DC \uD655\uC778 \uC911"
  },
  status_unsupported: {
    message: "\uC0AC\uC6A9\uB7C9 \uC218\uC9D1 \uBBF8\uC9C0\uC6D0"
  },
  ticket_availability_unknown: {
    message: "\uC0AC\uC6A9 \uAC00\uB2A5 \uC5EC\uBD80 \uD655\uC778 \uBD88\uAC00"
  },
  ticket_blocked: {
    message: "\uC0AC\uC6A9 \uC81C\uD55C \uC911"
  },
  ticket_count_one: {
    message: "$1\uAC1C"
  },
  ticket_count_other: {
    message: "$1\uAC1C"
  },
  ticket_expiry: {
    message: "$1 \uB9CC\uB8CC"
  },
  ticket_inline: {
    message: "\u{1F3AB} \uD2F0\uCF13 \uB9CC\uB8CC: $1"
  },
  ticket_kind_five_hour: {
    message: "5\uC2DC\uAC04 \uD55C\uB3C4"
  },
  ticket_kind_full: {
    message: "\uC804\uCCB4 \uD55C\uB3C4"
  },
  ticket_kind_unspecified: {
    message: "\uC885\uB958 \uD655\uC778 \uBD88\uAC00"
  },
  ticket_kind_weekly: {
    message: "\uC8FC\uAC04 \uD55C\uB3C4"
  },
  ticket_management_action: {
    message: "\uACF5\uC2DD \uC0AC\uC6A9\uB7C9 \uAD00\uB9AC \uD654\uBA74 \uC5F4\uAE30 (\uC0C8 \uD0ED)"
  },
  ticket_other_first: {
    message: "\uB2E4\uB978 \uD2F0\uCF13 \uC6B0\uC120"
  },
  ticket_requires_limit: {
    message: "\uD55C\uB3C4 \uB3C4\uB2EC \uC870\uAC74"
  },
  ticket_starts: {
    message: "$1\uBD80\uD130"
  },
  ticket_total_one: {
    message: "\u{1F3AB} \uCD08\uAE30\uD654 \uD2F0\uCF13 $1\uAC1C"
  },
  ticket_total_other: {
    message: "\u{1F3AB} \uCD08\uAE30\uD654 \uD2F0\uCF13 $1\uAC1C"
  },
  ticket_unavailable_now: {
    message: "\uD604\uC7AC \uC0AC\uC6A9 \uBD88\uAC00"
  }
};

// src/shared/i18n.ts
var api = globalThis.chrome?.i18n;
var preference = "system";
function setLanguagePreference(language) {
  preference = language === "en" || language === "ko" ? language : "system";
}
function languageForUI(language) {
  return /^ko(?:-|$)/i.test(language) ? "ko" : "en";
}
function uiLanguage() {
  return preference === "system" ? languageForUI(api?.getUILanguage() ?? "en") : preference;
}
function t(key, substitutions = []) {
  const values = typeof substitutions === "string" ? [substitutions] : substitutions;
  const translated = preference === "system" ? api?.getMessage(key, values) : "";
  if (translated) return translated;
  const message = (uiLanguage() === "ko" ? messages_default2[key] : messages_default[key])?.message ?? messages_default[key].message;
  return message.replace(/\$(\d+)/g, (_, index) => values[Number(index) - 1] ?? "");
}
function localizeDocument(doc) {
  doc.documentElement.lang = uiLanguage();
  for (const node of doc.querySelectorAll("[data-i18n]")) {
    const key = node.dataset.i18n;
    if (key && Object.hasOwn(messages_default, key)) node.textContent = t(key);
  }
  for (const attribute of ["aria-label", "title", "placeholder"]) {
    for (const node of doc.querySelectorAll(`[data-i18n-${attribute}]`)) {
      const key = node.getAttribute(`data-i18n-${attribute}`);
      if (key && Object.hasOwn(messages_default, key)) node.setAttribute(attribute, t(key));
    }
  }
}

// src/shared/limit-label.ts
function localizedLimitLabel(limit, provider) {
  const label2 = provider === "chatgpt" ? limit.label.replace(/^(?:ChatGPT\s*·\s*|Work\s*\/\s*Codex\s*공유\s*(?:[·:–—-]\s*)?)/, "").trim() : limit.label;
  return label2.split(" \xB7 ").map((part) => {
    const period = /^(\d+(?:\.\d+)?)(시간|일)$/.exec(part);
    if (period) {
      const value = period[1], unit = period[2] === "\uC77C" ? "days" : "hours";
      return t(`limit_${unit}_${Number(value) === 1 ? "one" : "other"}`, value);
    }
    if (part === "\uAE30\uBCF8 \uC81C\uD55C") return t("limit_primary");
    if (part === "\uCD94\uAC00 \uC81C\uD55C") return t("limit_additional");
    if (part === "\uC8FC\uAC04") return t("limit_weekly");
    if (part === "Work / Codex \uACF5\uC720") return t("limit_legacy_shared");
    return part;
  }).join(" \xB7 ") || t("format_usage_name");
}

// src/shared/format.ts
var DAYS = { ko: ["\uC77C", "\uC6D4", "\uD654", "\uC218", "\uBAA9", "\uAE08", "\uD1A0"], en: ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"] };
var twoDigits = (value) => String(value).padStart(2, "0");
function localStamp(at) {
  return `${at.getMonth() + 1}/${at.getDate()}(${DAYS[uiLanguage()][at.getDay()]}) ${twoDigits(at.getHours())}:${twoDigits(at.getMinutes())}`;
}
var geminiErrorText = (text) => Object.fromEntries(GEMINI_RESPONSE_ERRORS.map((code) => [code, text]));
function relativeTime(remaining) {
  if (!Number.isFinite(remaining) || remaining <= 0) return null;
  for (const [unit, size] of [["day", 864e5], ["hour", 36e5], ["minute", 6e4]]) {
    if (remaining >= size) {
      const count2 = Math.floor(remaining / size);
      return t(`format_relative_${unit}_${count2 === 1 ? "one" : "other"}`, String(count2));
    }
  }
  return t("format_less_than_minute");
}
function resetValue(value, now, compact = false) {
  const reset = resetTime(value);
  if (reset === null) return t("format_unknown");
  const at = new Date(reset);
  const prefix = compact ? "" : `${localStamp(at)}, `;
  const remaining = at.getTime() - now;
  if (!Number.isFinite(remaining)) return `${prefix}${t("format_remaining_unknown")}`;
  if (remaining <= 0) return `${prefix}${t("format_reset_pending")}`;
  if (compact) return relativeTime(remaining) ?? t("format_remaining_unknown");
  const hours = Math.floor(remaining / 36e5), days = Math.floor(hours / 24);
  return `${prefix}${t("format_duration_left", `${days > 0 ? `${days}d ` : ""}${hours % 24}h`)}`;
}
var resetLabel = (reset, now = Date.now()) => t("format_reset_popup", resetValue(reset, now));
function usagePercentLabel(value) {
  const used = percent(value);
  return t("format_usage", used === null ? t("format_unknown") : `${Math.round(used)}%`);
}
var STATUS_KEYS = {
  not_collected: "status_not_collected",
  signed_out: "status_signed_out",
  access_denied: "status_access_denied",
  rate_limited: "status_rate_limited",
  network: "status_network",
  server: "status_server",
  invalid_response: "status_invalid_response",
  ...geminiErrorText("status_invalid_response"),
  open_tab: "status_open_tab",
  tab_access_failed: "status_tab_access_failed",
  ambiguous_account: "status_ambiguous_account",
  unsupported: "status_unsupported",
  permission_required: "status_permission_required",
  reset_pending: "format_reset_pending"
};
function statusText(snapshot) {
  if (snapshot.state === "ok") return t("status_ok");
  if (snapshot.state === "stale") return t("status_not_collected");
  return snapshot.errorCode ? t(STATUS_KEYS[snapshot.errorCode]) : t("format_unknown");
}

// src/shared/errors.ts
var ERROR_KEYS = {
  not_collected: "error_not_collected",
  signed_out: "error_signed_out",
  access_denied: "error_access_denied",
  rate_limited: "error_rate_limited",
  network: "error_network",
  invalid_response: "error_invalid_response",
  ...geminiErrorText("error_invalid_response"),
  open_tab: "error_open_tab",
  ambiguous_account: "error_ambiguous_account",
  tab_access_failed: "error_tab_access_failed",
  unsupported: "error_unsupported",
  permission_required: "error_permission_required",
  server: "error_server",
  reset_pending: "format_reset_pending"
};
var ERROR_TEXT = Object.defineProperties({}, Object.fromEntries(
  Object.entries(ERROR_KEYS).map(([code, key]) => [code, { enumerable: true, get: () => t(key) }])
));

// src/shared/plan.ts
var LABELS = {
  chatgpt: ["Free", "Go", "Plus", "Pro", "Pro 100", "Pro 200", "Pro 500", "Team", "Business", "Enterprise", "Education", "Education (K-12)"],
  claude: ["Free", "Pro", "Max", "Max 5x", "Max 20x", "Team", "Enterprise"],
  gemini: ["Free", "AI Plus", "AI Pro", "AI Ultra", "Workspace"]
};
var PLAN_MAX_AGE_MS = 10 * 6e4;
function knownPlanLabel(provider, input) {
  return typeof input === "string" && LABELS[provider].includes(input) ? input : null;
}
function parsePlan(provider, input) {
  const raw = record(input), label2 = knownPlanLabel(provider, raw?.label);
  return label2 && finite(raw?.checkedAt) && raw.checkedAt > 0 ? { label: label2, checkedAt: raw.checkedAt } : null;
}
function currentPlanLabel(snapshot, now = Date.now()) {
  const plan = parsePlan(snapshot.provider, snapshot.plan);
  return plan && !snapshot.planRefreshPending && snapshot.state === "ok" && snapshot.errorCode === null && plan.checkedAt === snapshot.collectedAt && finite(snapshot.checkedAt) && plan.checkedAt <= snapshot.checkedAt && snapshot.checkedAt <= now && finite(now) && plan.checkedAt <= now && now - plan.checkedAt < PLAN_MAX_AGE_MS ? plan.label : null;
}

// src/shared/tickets.ts
var count = (value) => Number.isSafeInteger(value) && value >= 0;
var nullableBoolean = (value) => value === null || typeof value === "boolean";
var date = (value) => value === null || resetTime(value) !== null;
var kinds = ["full", "five_hour", "weekly", "unspecified"];
function parseTicketInventory(input) {
  const raw = record(input);
  if (!raw || typeof raw.mode !== "string" || !["summary", "detail"].includes(raw.mode) || !Array.isArray(raw.grants) || raw.grants.length > 100 || !(raw.usableCount === null || count(raw.usableCount)) || !date(raw.cooldownUntil)) return null;
  const grants = [];
  for (const value of raw.grants) {
    const grant = record(value);
    if (!grant || typeof grant.kind !== "string" || !kinds.includes(grant.kind) || !count(grant.count) || !date(grant.startsAt) || !date(grant.expiresAt) || !nullableBoolean(grant.usableNow) || !nullableBoolean(grant.requiresLimit) || !nullableBoolean(grant.blocked) || !nullableBoolean(grant.selected) || !Array.isArray(grant.clears) || grant.clears.length > 64 || !grant.clears.every((value2) => typeof value2 === "string" && /^(five_hour|seven_day(?:_[a-z0-9_]+)?)$/.test(value2) && value2.length <= 64)) return null;
    const startsAt = resetTime(grant.startsAt), expiresAt = resetTime(grant.expiresAt);
    if (startsAt && expiresAt && Date.parse(startsAt) >= Date.parse(expiresAt)) return null;
    grants.push({
      kind: grant.kind,
      count: grant.count,
      startsAt,
      expiresAt,
      usableNow: grant.usableNow,
      clears: [...new Set(grant.clears)],
      requiresLimit: grant.requiresLimit,
      blocked: grant.blocked,
      selected: grant.selected
    });
  }
  const total = grants.reduce((sum, grant) => sum + grant.count, 0);
  if (!count(total) || raw.usableCount !== null && raw.usableCount > total) return null;
  if (raw.mode === "summary" && grants.some((grant) => grant.kind !== "unspecified" || grant.startsAt !== null || grant.expiresAt !== null)) return null;
  return {
    mode: raw.mode,
    grants,
    usableCount: raw.usableCount,
    cooldownUntil: resetTime(raw.cooldownUntil)
  };
}
function parseTicketCache(input) {
  const raw = record(input), inventory = parseTicketInventory(raw?.inventory);
  return inventory && finite(raw?.checkedAt) && raw.checkedAt > 0 && count(raw.failures) ? { inventory, checkedAt: raw.checkedAt, failures: raw.failures } : null;
}
function ticketSummary(snapshot, now = Date.now()) {
  if (snapshot.provider === "gemini" || snapshot.ticketRefreshPending || !finite(now) || ["signed_out", "permission_required", "unsupported"].includes(snapshot.state) || ["signed_out", "access_denied", "ambiguous_account", "permission_required"].includes(snapshot.errorCode ?? "")) return null;
  const cache = parseTicketCache(snapshot.tickets);
  if (!cache || cache.checkedAt > now || cache.failures >= 2) return null;
  const { inventory, checkedAt } = cache;
  const grants = inventory.grants.filter((grant) => grant.count > 0 && (grant.expiresAt === null || Date.parse(grant.expiresAt) > now));
  const held = grants.reduce((sum, grant) => sum + grant.count, 0);
  if (!held) return null;
  const expiry = grants.flatMap((grant) => grant.expiresAt ? [Date.parse(grant.expiresAt)] : []);
  const cooldown = inventory.cooldownUntil ? Date.parse(inventory.cooldownUntil) : null;
  const crossed = (time) => time !== null && Date.parse(time) > checkedAt && Date.parse(time) <= now;
  const changedBoundary = inventory.grants.some((grant) => crossed(grant.startsAt) || crossed(grant.expiresAt)) || crossed(inventory.cooldownUntil);
  let usable = null;
  if (cooldown !== null && cooldown > now) usable = 0;
  else if (inventory.usableCount !== null && !changedBoundary) {
    const startedCount = grants.filter((grant) => grant.startsAt === null || Date.parse(grant.startsAt) <= now).reduce((sum, grant) => sum + grant.count, 0);
    usable = inventory.usableCount === 0 || startedCount === held && inventory.usableCount <= startedCount ? inventory.usableCount : null;
  } else if (inventory.mode === "detail") {
    let total = 0, known = true;
    for (const grant of grants) {
      if (grant.startsAt !== null && Date.parse(grant.startsAt) > now) continue;
      if (crossed(grant.startsAt) || crossed(inventory.cooldownUntil)) {
        known = false;
        continue;
      }
      if (grant.blocked === true || grant.selected === false || grant.usableNow === false) continue;
      if (grant.usableNow === true) total += grant.count;
      else known = false;
    }
    if (known) usable = total;
  }
  return { held, usable, expiresAt: expiry.length ? new Date(Math.min(...expiry)).toISOString() : null, grants };
}

// src/storage/snapshots.ts
var FRESH_MS = 10 * 6e4;
function emptySnapshot(provider) {
  return { provider, state: "error", limits: [], collectedAt: null, checkedAt: null, nextAttemptAt: 0, failures: 0, errorCode: "not_collected" };
}
function validLimits(input) {
  return Array.isArray(input) && input.length <= 150 && input.every((x) => {
    const r = record(x);
    return r && typeof r.id === "string" && r.id.length > 0 && r.id.length <= 200 && label(r.label) && ["window", "model", "product"].includes(String(r.category)) && r.source === "api" && (r.percent === null || percent(r.percent) !== null) && (r.resetsAt === null || resetTime(r.resetsAt) !== null) && (r.windowSeconds === null || nonnegative(r.windowSeconds) !== null) && (r.remaining === null || nonnegative(r.remaining) !== null) && (r.unit === null || label(r.unit));
  }) && new Set(input.map((x) => x.id)).size === input.length;
}
var STATES = ["ok", "stale", "signed_out", "permission_required", "rate_limited", "unsupported", "error"];
function parseSnapshot(input, provider) {
  const r = record(input);
  if (!r || r.provider !== provider || !STATES.includes(String(r.state)) || !validLimits(r.limits) || !(r.collectedAt === null || finite(r.collectedAt)) || !(r.checkedAt === null || finite(r.checkedAt)) || !finite(r.nextAttemptAt) || !finite(r.failures) || !(r.errorCode === null || typeof r.errorCode === "string" && Object.hasOwn(ERROR_TEXT, r.errorCode))) return emptySnapshot(provider);
  if (r.state === "ok" && (r.collectedAt === null || r.limits.length === 0)) return emptySnapshot(provider);
  const limits = r.limits.map((limit) => ({
    id: limit.id,
    label: label(limit.label),
    category: limit.category,
    percent: limit.percent,
    resetsAt: limit.resetsAt === null ? null : resetTime(limit.resetsAt),
    windowSeconds: limit.windowSeconds,
    remaining: limit.remaining,
    unit: limit.unit === null ? null : label(limit.unit),
    source: "api"
  }));
  return {
    provider,
    state: r.state,
    limits,
    collectedAt: r.collectedAt,
    checkedAt: r.checkedAt,
    nextAttemptAt: Math.max(0, r.nextAttemptAt),
    failures: Math.max(0, r.failures),
    errorCode: r.errorCode,
    ...r.usageInvalidated === true ? { usageInvalidated: true } : {},
    ...Object.hasOwn(r, "plan") ? { plan: parsePlan(provider, r.plan) } : {},
    ...Object.hasOwn(r, "planRefreshPending") ? { planRefreshPending: r.planRefreshPending === true } : {},
    ...Object.hasOwn(r, "tickets") ? { tickets: provider === "gemini" ? null : parseTicketCache(r.tickets) } : {},
    ...Object.hasOwn(r, "ticketRefreshPending") ? { ticketRefreshPending: r.ticketRefreshPending === true } : {}
  };
}
function hasElapsedReset(snapshot, now = Date.now()) {
  return snapshot.limits.some((limit) => {
    const reset = resetTime(limit.resetsAt);
    return reset !== null && Date.parse(reset) <= now;
  });
}
function effectiveSnapshot(snapshot, now = Date.now()) {
  const firstTransient = snapshot.failures === 1 && (snapshot.errorCode === "network" || snapshot.errorCode === "server");
  const cachedFallback = !snapshot.usageInvalidated && (firstTransient || snapshot.errorCode === "tab_access_failed");
  const legacyAgeOnly = snapshot.state === "stale" && snapshot.errorCode === null && snapshot.failures === 0;
  const current = snapshot.state === "ok";
  if (!current && !legacyAgeOnly && !(snapshot.state === "error" && cachedFallback)) return snapshot;
  if (snapshot.usageInvalidated || current && snapshot.errorCode !== null && !cachedFallback) return { ...snapshot, state: "error" };
  const usable = finite(now) && finite(snapshot.collectedAt) && snapshot.collectedAt > 0 && snapshot.collectedAt <= now + 6e4 && snapshot.limits.length > 0 && validLimits(snapshot.limits);
  if (!usable) return current || legacyAgeOnly ? { ...snapshot, state: "error", errorCode: "invalid_response" } : snapshot;
  if (hasElapsedReset(snapshot, now)) return { ...snapshot, state: "error", errorCode: "reset_pending" };
  return current ? snapshot : { ...snapshot, state: "ok" };
}
var SNAPSHOT_KEYS = { chatgpt: "snapshot:v4:chatgpt", claude: "snapshot:v2:claude", gemini: "snapshot:v1:gemini" };
var SETTINGS_KEY = "settings:v2";
function affectsView(changes, areaName) {
  return areaName === "local" && !!changes && Object.keys(changes).some((key) => key === SETTINGS_KEY || Object.values(SNAPSHOT_KEYS).includes(key));
}

// src/shared/display-policy.ts
var displayProvider = (page) => page === "codex" ? "chatgpt" : page;

// src/shared/contracts.ts
function sameFields(left, right) {
  if (left === right) return true;
  if (Array.isArray(left)) return Array.isArray(right) && left.length === right.length && left.every((value, index) => sameFields(value, right[index]));
  const a = record(left), b = record(right);
  return !!a && !!b && Object.keys(a).length === Object.keys(b).length && Object.keys(a).every((key) => Object.hasOwn(b, key) && sameFields(a[key], b[key]));
}
function isReply(input) {
  const r = record(input), view2 = record(r?.view);
  if (r?.ok !== true || !view2 || !isSettings(view2.settings)) return false;
  return PROVIDERS.every((p) => {
    const raw = record(record(view2.snapshots)?.[p]);
    if (!raw || typeof record(view2.permissions)?.[p] !== "boolean") return false;
    const clean = parseSnapshot(raw, p);
    return sameFields(clean, raw);
  });
}
async function request(message) {
  const reply = await chrome.runtime.sendMessage(message);
  if (!isReply(reply)) throw new Error("invalid_extension_response");
  return reply.view;
}

// src/shared/ticket-presentation.ts
var MANAGEMENT_URLS = {
  chatgpt: "https://chatgpt.com/settings/usage?tab=overview",
  claude: "https://claude.ai/new#settings/usage"
};
var KIND_KEYS = {
  full: "ticket_kind_full",
  five_hour: "ticket_kind_five_hour",
  weekly: "ticket_kind_weekly",
  unspecified: "ticket_kind_unspecified"
};
var ticketCount = (count2) => t(count2 === 1 ? "ticket_count_one" : "ticket_count_other", String(count2));
var ticketDate = (value) => localStamp(new Date(value));
function grantDetail(grant, now) {
  const conditions = [];
  if (grant.startsAt && Date.parse(grant.startsAt) > now) conditions.push(t("ticket_starts", ticketDate(grant.startsAt)));
  if (grant.expiresAt) conditions.push(t("ticket_expiry", ticketDate(grant.expiresAt)));
  if (grant.requiresLimit) conditions.push(t("ticket_requires_limit"));
  if (grant.blocked) conditions.push(t("ticket_blocked"));
  if (grant.selected === false) conditions.push(t("ticket_other_first"));
  if (grant.usableNow === false) conditions.push(t("ticket_unavailable_now"));
  if (grant.usableNow === null) conditions.push(t("ticket_availability_unknown"));
  return `${t(KIND_KEYS[grant.kind])} ${ticketCount(grant.count)}${conditions.length ? ` \xB7 ${conditions.join(" \xB7 ")}` : ""}`;
}
function ticketDisplay(snapshot, now = Date.now()) {
  const href = MANAGEMENT_URLS[snapshot.provider], summary = ticketSummary(snapshot, now);
  if (!href || !summary) return null;
  const expiry = summary.expiresAt ? t("ticket_expiry", ticketDate(summary.expiresAt)) : null;
  const count2 = t(summary.held === 1 ? "ticket_total_one" : "ticket_total_other", String(summary.held));
  const entries = summary.grants.length === 1 && !summary.grants[0].expiresAt ? [] : summary.grants.map((grant) => grant.expiresAt ? `${grant.count > 1 ? `${ticketCount(grant.count)} \xB7 ` : ""}${t("ticket_expiry", ticketDate(grant.expiresAt))}` : ticketCount(grant.count));
  const details = summary.grants.map((grant) => grantDetail(grant, now)).join("\n");
  return {
    href,
    count: count2,
    entries,
    expiry,
    details,
    popupAccessible: `${[count2, ...entries].join(", ")}. ${t("ticket_management_action")}`
  };
}

// src/popup/render.ts
function renderCards(container, view2, actions, now = Date.now()) {
  setLanguagePreference(view2.settings.language);
  const d = container.ownerDocument;
  const el = (tag, text, cls) => {
    const e = d.createElement(tag);
    if (text) e.textContent = text;
    if (cls) e.className = cls;
    return e;
  };
  const cards2 = PROVIDERS.map((p) => {
    const s = effectiveSnapshot(view2.snapshots[p], now), enabled = view2.settings.enabled[p];
    const card = el("section", void 0, "card");
    card.dataset.provider = p;
    const title = NAMES[p];
    card.setAttribute("aria-label", t("popup_provider_usage", title));
    const heading = el("div", void 0, "card-heading");
    const identity = el("div", void 0, "provider-name");
    const plan = enabled && view2.permissions[p] ? currentPlanLabel(view2.snapshots[p], now) : null;
    const name = el("h2"), home = el("a", title, "provider-home");
    home.href = HOME_URLS[p];
    home.target = "_blank";
    home.rel = "noopener noreferrer";
    home.setAttribute("aria-label", t("popup_open_site", title));
    name.append(home);
    identity.append(name);
    if (plan) {
      const badge = el("span", plan, "plan-badge");
      badge.setAttribute("aria-label", t("popup_provider_plan", [title, plan]));
      identity.append(badge);
    }
    heading.append(identity);
    card.append(heading);
    if (!enabled || s.state !== "ok") card.append(el("p", enabled ? statusText(s) : t("popup_disabled"), "status"));
    else if (!s.limits.length) card.append(el("p", t("popup_usage_unavailable"), "status"));
    if (enabled && s.limits.length) {
      if (s.state !== "ok") card.append(el("p", t("popup_previous_usage"), "status"));
      const limits = [...s.limits].sort((a, b) => (a.windowSeconds || Infinity) - (b.windowSeconds || Infinity));
      for (const limit of limits) {
        const name2 = localizedLimitLabel(limit, p);
        const row = el("div", void 0, `limit ${s.state === "ok" ? "" : "old"}`), line = el("div", void 0, "limit-line");
        line.append(el("span", name2), el("span", usagePercentLabel(limit.percent), "percent"));
        row.append(line);
        const used = percent(limit.percent);
        if (used !== null) {
          const bar = el("progress");
          bar.max = 100;
          bar.value = used;
          bar.setAttribute("aria-label", t(s.state === "ok" ? "popup_limit_usage" : "popup_limit_previous_usage", name2));
          row.append(bar);
        }
        row.append(el("div", resetLabel(limit.resetsAt, now), "reset"));
        card.append(row);
      }
    }
    const tickets = enabled && view2.permissions[p] ? ticketDisplay(view2.snapshots[p], now) : null;
    if (tickets) {
      const link = el("a", void 0, "ticket-info");
      link.href = tickets.href;
      link.target = "_blank";
      link.rel = "noopener noreferrer";
      link.title = tickets.details;
      link.setAttribute("aria-label", tickets.popupAccessible);
      link.setAttribute("aria-description", tickets.details);
      link.append(el("span", tickets.count, "ticket-count"));
      for (const entry of tickets.entries) link.append(el("span", entry, "ticket-expiry"));
      card.append(link);
    }
    const controls = el("div", void 0, "actions");
    const button = (parent, text, fn, cls) => {
      const b = el("button", text, cls);
      b.type = "button";
      b.addEventListener("click", fn);
      parent.append(b);
      return b;
    };
    if (!enabled || !view2.permissions[p]) button(controls, t(view2.permissions[p] ? "popup_enable" : "popup_grant_enable"), () => actions.enable(p), "grant");
    if (enabled) button(controls, t("popup_disable"), () => actions.disable(p));
    if (view2.permissions[p]) button(controls, t("popup_revoke"), () => actions.revoke(p));
    heading.append(controls);
    return card;
  });
  container.replaceChildren(...cards2);
}

// src/popup/diagnostics.ts
function createDiagnosticReport(view2, extensionVersion2) {
  const providers = {};
  for (const p of PROVIDERS) {
    const snapshot = view2.snapshots[p];
    providers[p] = {
      enabled: view2.settings.enabled[p],
      permission: view2.permissions[p],
      state: snapshot.state,
      errorCode: snapshot.errorCode,
      checkedAt: snapshot.checkedAt,
      collectedAt: snapshot.collectedAt,
      nextAttemptAt: snapshot.nextAttemptAt
    };
  }
  const strips = Object.fromEntries(PAGE_PROVIDERS.map((p) => [p, view2.settings.strips[p]]));
  return { extensionVersion: extensionVersion2, providers, strips };
}
function cleanDisplayReply(value, provider) {
  if (typeof value !== "object" || value === null) return null;
  const raw = value;
  const resolved = raw.provider === provider ? provider : provider === "chatgpt" && raw.provider === "codex" ? "codex" : null;
  if (raw.status !== "ready" || !resolved || raw.contentReady !== true || typeof raw.targetFound !== "boolean" || typeof raw.stripVisible !== "boolean") return null;
  const count2 = (value2) => typeof value2 === "number" && Number.isSafeInteger(value2) && value2 >= 0 && value2 <= 1e4;
  if (!count2(raw.editableCount) || !count2(raw.iframeCount) || !count2(raw.stripCount)) return null;
  return {
    status: "ready",
    provider: resolved,
    contentReady: true,
    editableCount: raw.editableCount,
    iframeCount: raw.iframeCount,
    targetFound: raw.targetFound,
    stripCount: raw.stripCount,
    stripVisible: raw.stripVisible
  };
}
async function readActiveDisplayDiagnostic(view2, api2 = chrome) {
  let provider = null;
  try {
    const [tab] = await api2.tabs.query({ active: true, lastFocusedWindow: true });
    provider = providerFromUrl(tab?.url);
    if (!provider || typeof tab?.id !== "number") return { status: "no_site" };
    const source = displayProvider(provider);
    if (!view2.permissions[source] || !await api2.permissions.contains({ origins: [ORIGINS[source]] })) return { status: "permission_required", provider };
    const reply = await api2.tabs.sendMessage(tab.id, { type: "display-diagnostics" }, { frameId: 0 });
    return cleanDisplayReply(reply, provider) ?? { status: "content_unavailable", provider };
  } catch {
    return provider ? { status: "content_unavailable", provider } : { status: "content_unavailable" };
  }
}
function bindDiagnostics(doc, getView, extensionVersion2, copy = (text) => doc.defaultView.navigator.clipboard.writeText(text), readDisplay = typeof chrome !== "undefined" && chrome.tabs ? readActiveDisplayDiagnostic : void 0) {
  const output = doc.getElementById("diagnostics-output");
  const feedback2 = doc.getElementById("diagnostics-feedback");
  let revision = 0;
  const show = async () => {
    const currentRevision = ++revision;
    const view2 = getView();
    if (!view2) {
      feedback2.textContent = t("diagnostics_not_ready");
      return null;
    }
    const report = createDiagnosticReport(view2, extensionVersion2);
    output.value = JSON.stringify(report, null, 2);
    output.hidden = false;
    if (readDisplay) {
      feedback2.textContent = t("diagnostics_checking_tab");
      try {
        report.display = await readDisplay(view2);
      } catch {
        report.display = { status: "content_unavailable" };
      }
      if (revision !== currentRevision) return null;
    }
    const text = JSON.stringify(report, null, 2);
    output.value = text;
    feedback2.textContent = t("diagnostics_shown");
    return text;
  };
  doc.getElementById("diagnostics-show").addEventListener("click", () => {
    void show();
  });
  doc.getElementById("diagnostics-copy").addEventListener("click", () => {
    void (async () => {
      const text = await show();
      if (text === null) return;
      try {
        await copy(text);
        feedback2.textContent = t("diagnostics_copied");
      } catch {
        output.focus();
        output.select();
        feedback2.textContent = t("diagnostics_copy_failed");
      }
    })();
  });
}

// src/shared/build-mode.ts
var DEVELOPMENT = true;

// src/popup/index.ts
localizeDocument(document);
var view = null;
var busy = false;
var viewDirty = false;
var settingsRevision = 0;
var dirtyFields = /* @__PURE__ */ new Map();
var settingsFields = ["language", "gauge-warning", "gauge-danger", ...PAGE_PROVIDERS.map((p) => `strip-${p}`)];
var pendingSave = null;
var lastValidThresholds = null;
var renderedLanguage = uiLanguage();
var installedManifest = chrome.runtime.getManifest();
var extensionVersion = installedManifest.version_name ?? installedManifest.version;
document.getElementById("extension-version").textContent = `AI Gauge ${extensionVersion}`;
if (DEVELOPMENT) bindDiagnostics(document, () => view, extensionVersion);
var cards = document.getElementById("cards");
var feedback = document.getElementById("feedback");
var field = (id) => document.getElementById(id);
var languageField = document.getElementById("language");
var onboarding = document.getElementById("onboarding");
var preferences = document.getElementById("preferences");
var setupButton = document.getElementById("onboarding-submit");
for (const p of PROVIDERS) {
  const label2 = document.createElement("label");
  label2.className = "toggle";
  const checkbox = document.createElement("input");
  checkbox.type = "checkbox";
  checkbox.id = `choose-${p}`;
  checkbox.checked = true;
  label2.append(checkbox, document.createTextNode(NAMES[p]));
  document.getElementById("provider-choices").append(label2);
}
var selectedProviders = () => PROVIDERS.filter((p) => field(`choose-${p}`).checked);
function renderSetup() {
  setupButton.disabled = busy || selectedProviders().length === 0;
  for (const p of PROVIDERS) field(`choose-${p}`).disabled = busy;
}
var displayNames = { chatgpt: "ChatGPT", codex: "Codex", claude: "Claude", gemini: "Gemini" };
var stripLabels = /* @__PURE__ */ new Map();
for (const p of PAGE_PROVIDERS) {
  const label2 = document.createElement("label");
  label2.className = "toggle";
  const checkbox = document.createElement("input");
  checkbox.type = "checkbox";
  checkbox.id = `strip-${p}`;
  const text = document.createTextNode(t("popup_show_in_composer", displayNames[p]));
  stripLabels.set(p, text);
  label2.append(checkbox, text);
  document.getElementById("strip-settings").append(label2);
}
function render() {
  if (!view) return;
  setLanguagePreference(view.settings.language);
  localizeDocument(document);
  for (const p of PAGE_PROVIDERS) stripLabels.get(p).textContent = t("popup_show_in_composer", displayNames[p]);
  const diagnosticsFeedback = document.getElementById("diagnostics-feedback");
  if (renderedLanguage !== uiLanguage() && diagnosticsFeedback) diagnosticsFeedback.textContent = "";
  renderedLanguage = uiLanguage();
  renderSettingsFeedback();
  const needsSetup = PROVIDERS.every((p) => !view.settings.enabled[p] && !view.permissions[p]);
  onboarding.hidden = !needsSetup;
  cards.hidden = needsSetup;
  preferences.hidden = needsSetup;
  renderSetup();
  renderCards(cards, view, {
    enable: (p) => {
      void enable(p);
    },
    disable: (p) => {
      void run(() => request({ type: "disable", provider: p }));
    },
    revoke: (p) => {
      void run(async () => {
        await chrome.permissions.remove({ origins: [ORIGINS[p]] });
        return request({ type: "view" });
      });
    }
  });
  for (const p of PAGE_PROVIDERS) if (!dirtyFields.has(`strip-${p}`)) field(`strip-${p}`).checked = view.settings.strips[p];
  if (!dirtyFields.has("gauge-warning")) field("gauge-warning").value = String(view.settings.warning);
  if (!dirtyFields.has("gauge-danger")) field("gauge-danger").value = String(view.settings.danger);
  if (!dirtyFields.has("language")) languageField.value = view.settings.language;
  const thresholds = pendingSave?.message ?? view.settings;
  lastValidThresholds = { warning: thresholds.warning, danger: thresholds.danger };
}
async function run(action) {
  if (busy) return;
  busy = true;
  renderSetup();
  try {
    view = await action();
    render();
    feedback.textContent = "";
  } catch {
    feedback.textContent = t("popup_communication_failed");
  } finally {
    busy = false;
    renderSetup();
    if (pendingSave) savePendingSettings();
    else if (viewDirty) {
      viewDirty = false;
      void run(() => request({ type: "read" }));
    }
  }
}
async function enableSelected(providers) {
  if (busy || !providers.length) return;
  let canceled = false;
  await run(async () => {
    if (!await chrome.permissions.request({ origins: providers.map((p) => ORIGINS[p]) })) {
      canceled = true;
      return request({ type: "view" });
    }
    return providers.length === 1 ? request({ type: "enable", provider: providers[0] }) : request({ type: "enable-many", providers });
  });
  if (canceled) feedback.textContent = t("popup_permission_canceled");
}
var enable = (p) => enableSelected([p]);
document.getElementById("onboarding-form").addEventListener("input", renderSetup);
document.getElementById("onboarding-form").addEventListener("submit", (event) => {
  event.preventDefault();
  void enableSelected(selectedProviders());
});
var settingsFeedback = document.getElementById("settings-feedback");
var settingsFeedbackKey = null;
var invalidFields = [];
function renderSettingsFeedback() {
  const invalid = invalidFields;
  settingsFeedback.setAttribute("role", invalid.length ? "alert" : "status");
  settingsFeedback.setAttribute("aria-live", invalid.length ? "assertive" : "polite");
  settingsFeedback.textContent = settingsFeedbackKey ? t(settingsFeedbackKey) : "";
  for (const id of ["gauge-warning", "gauge-danger"]) {
    if (invalid.includes(id)) field(id).setAttribute("aria-invalid", "true");
    else field(id).removeAttribute("aria-invalid");
  }
}
function showSettingsFeedback(key, invalid = []) {
  settingsFeedbackKey = key;
  invalidFields = invalid;
  renderSettingsFeedback();
}
function markSettingsDirty(id) {
  settingsRevision++;
  if (id && settingsFields.includes(id)) dirtyFields.set(id, settingsRevision);
  else if (view) {
    if (languageField.value !== view.settings.language) dirtyFields.set("language", settingsRevision);
    for (const name of ["warning", "danger"]) {
      if (field(`gauge-${name}`).value !== String(view.settings[name])) dirtyFields.set(`gauge-${name}`, settingsRevision);
    }
    for (const p of PAGE_PROVIDERS) {
      if (field(`strip-${p}`).checked !== view.settings.strips[p]) dirtyFields.set(`strip-${p}`, settingsRevision);
    }
  }
}
document.getElementById("settings-form").addEventListener("input", (event) => {
  markSettingsDirty(event.target.id);
  showSettingsFeedback(null);
});
function queueSettingsSave(thresholdChange, fieldId, focusInvalid = false) {
  if (!view) return;
  markSettingsDirty(fieldId);
  const checked = checkUsageThresholds(field("gauge-warning").valueAsNumber, field("gauge-danger").valueAsNumber);
  if (!checked.ok) {
    const fields = checked.fields.map((name) => `gauge-${name}`);
    showSettingsFeedback(checked.reason === "order" ? "popup_threshold_order_error" : "popup_threshold_range_error", fields);
    if (thresholdChange) {
      if (focusInvalid) field(fields[0]).focus();
      return;
    }
  } else {
    lastValidThresholds = checked.value;
    showSettingsFeedback(null);
  }
  const thresholds = lastValidThresholds ?? { warning: view.settings.warning, danger: view.settings.danger };
  const strips = Object.fromEntries(PAGE_PROVIDERS.map((p) => [p, field(`strip-${p}`).checked]));
  pendingSave = {
    message: { type: "display-settings", strips, ...thresholds, language: languageField.value },
    revision: settingsRevision,
    preserveDraft: !checked.ok
  };
  savePendingSettings();
}
function savePendingSettings() {
  if (busy || !pendingSave) return;
  const save = pendingSave;
  pendingSave = null;
  void run(async () => {
    const next = await request(save.message);
    for (const [id, revision] of dirtyFields) {
      if (revision <= save.revision && !(save.preserveDraft && id.startsWith("gauge-"))) dirtyFields.delete(id);
    }
    if (save.revision === settingsRevision && !save.preserveDraft) {
      showSettingsFeedback("popup_settings_saved");
    }
    return next;
  });
}
document.getElementById("settings-form").addEventListener("change", (event) => {
  const target = event.target;
  queueSettingsSave(target.id === "gauge-warning" || target.id === "gauge-danger", target.id);
});
document.getElementById("settings-form").addEventListener("submit", (event) => {
  event.preventDefault();
  queueSettingsSave(true, void 0, true);
});
for (const id of ["gauge-warning", "gauge-danger"]) field(id).addEventListener("keydown", (event) => {
  if (event.key === "Enter") {
    event.preventDefault();
    queueSettingsSave(true, id, true);
  }
});
chrome.storage.onChanged.addListener((changes, areaName) => {
  if (!affectsView(changes, areaName)) return;
  if (busy) viewDirty = true;
  else void run(() => request({ type: "read" }));
});
void run(() => request({ type: "view" }));
setInterval(render, 15e3);
