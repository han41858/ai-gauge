// src/shared/types.ts
var PROVIDERS = ["chatgpt", "claude", "gemini"];
var PAGE_PROVIDERS = ["chatgpt", "codex", "claude", "gemini"];
var ORIGINS = { chatgpt: "https://chatgpt.com/*", claude: "https://claude.ai/*", gemini: "https://gemini.google.com/*" };
var NAMES = { chatgpt: "ChatGPT", claude: "Claude", gemini: "Gemini" };
var GEMINI_RESPONSE_ERRORS = ["gemini_response_type", "gemini_response_read", "gemini_frame_invalid", "gemini_rpc_missing", "gemini_rpc_invalid", "gemini_quota_invalid"];
var isProvider = (v) => PROVIDERS.includes(v);
var SITE_GROUPS = [
  { id: "openai", origin: ORIGINS.chatgpt, providers: ["chatgpt", "codex"] },
  { id: "claude", origin: ORIGINS.claude, providers: ["claude"] },
  { id: "gemini", origin: ORIGINS.gemini, providers: ["gemini"] }
];
function providerFromUrl(url) {
  try {
    const u = new URL(url ?? "");
    if (u.protocol !== "https:") return null;
    if (u.hostname === "claude.ai") return "claude";
    if (u.hostname === "gemini.google.com") return "gemini";
    if (u.hostname === "chatgpt.com") return /^\/(codex|work)(?:\/|$)/.test(u.pathname) ? "codex" : "chatgpt";
    return null;
  } catch {
    return null;
  }
}

// src/shared/validation.ts
function record(v) {
  return v !== null && typeof v === "object" && !Array.isArray(v) ? v : null;
}
var finite = (v) => typeof v === "number" && Number.isFinite(v);
var percent = (v) => finite(v) && v >= 0 && v <= 100 ? v : null;
var nonnegative = (v) => finite(v) && v >= 0 ? v : null;
function label(v) {
  return typeof v === "string" && v.trim().length > 0 && v.length <= 120 && !/[\u0000-\u001f\u007f]/.test(v) ? v.trim() : null;
}
function resetTime(v) {
  if (typeof v !== "string") return null;
  const parts = /^(\d{4})-(\d{2})-(\d{2})T(\d{2}):(\d{2}):(\d{2})(?:\.\d+)?(?:Z|[+-]\d{2}:\d{2})$/.exec(v);
  if (!parts) return null;
  const [year, month, day, hour, minute, second] = parts.slice(1, 7).map(Number);
  if (month < 1 || month > 12 || day < 1 || day > new Date(Date.UTC(year, month, 0)).getUTCDate() || hour > 23 || minute > 59 || second > 59) return null;
  const ms = Date.parse(v);
  return Number.isFinite(ms) && ms > 0 && ms < 41024448e5 ? new Date(ms).toISOString() : null;
}
function unixReset(v) {
  return finite(v) && v > 0 && v < 4102444800 ? new Date(v * 1e3).toISOString() : null;
}

// src/storage/settings.ts
var inRange = (value) => finite(value) && value >= 0 && value <= 100;
function checkUsageThresholds(warning, danger) {
  const fields = ["warning", "danger"].filter((_, index) => !inRange(index === 0 ? warning : danger));
  if (fields.length) return { ok: false, reason: "range", fields };
  if (warning >= danger) return { ok: false, reason: "order", fields: ["warning", "danger"] };
  return { ok: true, value: { warning, danger } };
}
function parseUsageThresholds(warning, danger) {
  const result = checkUsageThresholds(warning, danger);
  return result.ok ? result.value : null;
}
function parseStrips(value) {
  const strips = record(value);
  return strips && Object.keys(strips).length === PAGE_PROVIDERS.length && PAGE_PROVIDERS.every((p) => typeof strips[p] === "boolean") ? Object.fromEntries(PAGE_PROVIDERS.map((p) => [p, strips[p]])) : null;
}
var isLanguagePreference = (value) => value === "system" || value === "en" || value === "ko";
function defaults() {
  return { enabled: { chatgpt: false, claude: false, gemini: false }, strips: { chatgpt: true, codex: true, claude: true, gemini: true }, language: "system", warning: 70, danger: 90 };
}
function parseSettings(value) {
  const out = defaults(), r = record(value);
  if (!r) return out;
  if (isLanguagePreference(r.language)) out.language = r.language;
  for (const p of PROVIDERS) {
    const enabled = record(r.enabled)?.[p];
    if (typeof enabled === "boolean") out.enabled[p] = enabled;
  }
  for (const p of PAGE_PROVIDERS) {
    const strip = record(r.strips)?.[p];
    if (typeof strip === "boolean") out.strips[p] = strip;
  }
  const thresholds = parseUsageThresholds(r.warning, r.danger);
  if (thresholds) Object.assign(out, thresholds);
  return out;
}

// _locales/en/messages.json
var messages_default = {
  badge_disabled: {
    message: "Disabled"
  },
  badge_permission_required: {
    message: "Permission required"
  },
  badge_usage_unknown: {
    message: "Usage unavailable"
  },
  diagnostics_checking_tab: {
    message: "Checking the display in the current tab."
  },
  diagnostics_copied: {
    message: "Diagnostics copied."
  },
  diagnostics_copy: {
    message: "Copy diagnostics"
  },
  diagnostics_copy_failed: {
    message: "Clipboard access was denied. The text is selected so you can copy it manually."
  },
  diagnostics_description: {
    message: "Shows the version, settings, errors, timestamps, and display target and element counts in the current tab. No input, account details, or URLs are included. Nothing is sent automatically."
  },
  diagnostics_not_ready: {
    message: "Status is not available yet. Please try again shortly."
  },
  diagnostics_output_label: {
    message: "Local diagnostics"
  },
  diagnostics_show: {
    message: "Show current status"
  },
  diagnostics_shown: {
    message: "Current status shown. Nothing is sent automatically."
  },
  diagnostics_title: {
    message: "Diagnostics"
  },
  error_access_denied: {
    message: "The site denied access. Security protections are not bypassed."
  },
  error_ambiguous_account: {
    message: "Multiple Claude organizations were found. Check usage settings in your account."
  },
  error_invalid_response: {
    message: "The usage response format could not be recognized."
  },
  error_network: {
    message: "The connection failed or the request timed out."
  },
  error_not_collected: {
    message: "Usage has not been collected yet."
  },
  error_open_tab: {
    message: "Open a signed-in service tab, then reopen the popup."
  },
  error_permission_required: {
    message: "Site access permission is required for this service."
  },
  error_rate_limited: {
    message: "Request limit reached. Please wait until the next retry."
  },
  error_server: {
    message: "The service returned an error. Another attempt will be made shortly."
  },
  error_signed_out: {
    message: "Sign in to the site, then reopen the popup."
  },
  error_tab_access_failed: {
    message: "Usage collection could not run in the open service tab. The last valid usage is kept while automatic retries continue."
  },
  error_unsupported: {
    message: "A safe collection method could not be verified. This service is unsupported."
  },
  extension_description: {
    message: "A local-only extension showing ChatGPT, Claude and Gemini usage and reset times."
  },
  format_duration_left: {
    message: "$1 left"
  },
  format_last_collected: {
    message: "Last successful collection: $1"
  },
  format_less_than_minute: {
    message: "in less than a minute"
  },
  format_not_collected: {
    message: "No successful collection yet"
  },
  format_relative_day_one: {
    message: "in $1 day"
  },
  format_relative_day_other: {
    message: "in $1 days"
  },
  format_relative_hour_one: {
    message: "in $1 hour"
  },
  format_relative_hour_other: {
    message: "in $1 hours"
  },
  format_relative_minute_one: {
    message: "in $1 minute"
  },
  format_relative_minute_other: {
    message: "in $1 minutes"
  },
  format_remaining: {
    message: "$1 remaining"
  },
  format_remaining_unknown: {
    message: "Time remaining unavailable"
  },
  format_reset_countdown: {
    message: "\u{1F552} Resets $1"
  },
  format_reset_pending: {
    message: "Checking after reset"
  },
  format_reset_popup: {
    message: "\u{1F552} Reset: $1"
  },
  format_reset_unavailable: {
    message: "\u{1F552} Reset: $1"
  },
  format_unknown: {
    message: "Unavailable"
  },
  format_usage: {
    message: "Usage: $1"
  },
  format_usage_name: {
    message: "Usage"
  },
  limit_additional: {
    message: "Additional limit"
  },
  limit_days_one: {
    message: "$1 day"
  },
  limit_days_other: {
    message: "$1 days"
  },
  limit_hours_one: {
    message: "$1 hour"
  },
  limit_hours_other: {
    message: "$1 hours"
  },
  limit_legacy_shared: {
    message: "Work / Codex shared"
  },
  limit_primary: {
    message: "Primary limit"
  },
  limit_weekly: {
    message: "Weekly"
  },
  popup_communication_failed: {
    message: "Cannot communicate with the extension. Please reload it."
  },
  popup_danger_threshold: {
    message: "Warning starts at"
  },
  popup_disable: {
    message: "Disable"
  },
  popup_disabled: {
    message: "Off"
  },
  popup_enable: {
    message: "Enable"
  },
  popup_grant_enable: {
    message: "Grant access and enable"
  },
  popup_language: {
    message: "Language"
  },
  popup_language_english: {
    message: "English"
  },
  popup_language_korean: {
    message: "Korean"
  },
  popup_language_system: {
    message: "System default"
  },
  popup_limit_previous_usage: {
    message: "$1 usage (previous value)"
  },
  popup_limit_usage: {
    message: "$1 usage"
  },
  popup_local_only: {
    message: "Local only"
  },
  popup_onboarding_description: {
    message: "Grant access to your selected services together to view usage."
  },
  popup_onboarding_start: {
    message: "Grant access and start"
  },
  popup_onboarding_title: {
    message: "Choose your services"
  },
  popup_open_site: {
    message: "Open $1 (new tab)"
  },
  popup_permission_canceled: {
    message: "Access request canceled."
  },
  popup_previous_usage: {
    message: "Previous usage"
  },
  popup_provider_plan: {
    message: "$1 plan: $2"
  },
  popup_provider_usage: {
    message: "$1 usage"
  },
  popup_revoke: {
    message: "Revoke access"
  },
  popup_settings: {
    message: "Settings"
  },
  popup_settings_saved: {
    message: "Settings saved."
  },
  popup_show_in_composer: {
    message: "Show below $1 input"
  },
  popup_threshold_order_error: {
    message: "The caution threshold must be lower than the warning threshold."
  },
  popup_threshold_range_error: {
    message: "Enter caution and warning thresholds between 0 and 100."
  },
  popup_usage_unavailable: {
    message: "Usage unavailable"
  },
  popup_warning_threshold: {
    message: "Caution starts at"
  },
  status_access_denied: {
    message: "Site access denied"
  },
  status_ambiguous_account: {
    message: "Select a Claude organization"
  },
  status_invalid_response: {
    message: "Usage unavailable"
  },
  status_network: {
    message: "Checking connection"
  },
  status_not_collected: {
    message: "Checking usage"
  },
  status_ok: {
    message: "Successfully collected"
  },
  status_open_tab: {
    message: "Open a service tab"
  },
  status_permission_required: {
    message: "Site permission required"
  },
  status_rate_limited: {
    message: "Check again shortly"
  },
  status_server: {
    message: "Waiting for service"
  },
  status_signed_out: {
    message: "Sign in required"
  },
  status_tab_access_failed: {
    message: "Rechecking usage"
  },
  status_unsupported: {
    message: "Usage collection unsupported"
  },
  ticket_availability_unknown: {
    message: "Availability unknown"
  },
  ticket_blocked: {
    message: "Currently restricted"
  },
  ticket_count_one: {
    message: "$1 ticket"
  },
  ticket_count_other: {
    message: "$1 tickets"
  },
  ticket_expiry: {
    message: "Expires $1"
  },
  ticket_inline: {
    message: "\u{1F3AB} Ticket expires $1"
  },
  ticket_kind_five_hour: {
    message: "5-hour limit"
  },
  ticket_kind_full: {
    message: "All limits"
  },
  ticket_kind_unspecified: {
    message: "Unknown type"
  },
  ticket_kind_weekly: {
    message: "Weekly limit"
  },
  ticket_management_action: {
    message: "Open official usage settings (new tab)"
  },
  ticket_other_first: {
    message: "Another ticket takes priority"
  },
  ticket_requires_limit: {
    message: "Limit must be reached"
  },
  ticket_starts: {
    message: "From $1"
  },
  ticket_total_one: {
    message: "\u{1F3AB} $1 reset ticket"
  },
  ticket_total_other: {
    message: "\u{1F3AB} $1 reset tickets"
  },
  ticket_unavailable_now: {
    message: "Not currently usable"
  }
};

// _locales/ko/messages.json
var messages_default2 = {
  badge_disabled: {
    message: "\uBE44\uD65C\uC131"
  },
  badge_permission_required: {
    message: "\uAD8C\uD55C \uD544\uC694"
  },
  badge_usage_unknown: {
    message: "\uC0AC\uC6A9\uB960 \uD655\uC778 \uBD88\uAC00"
  },
  diagnostics_checking_tab: {
    message: "\uD604\uC7AC \uD0ED\uC758 \uD45C\uC2DC \uC0C1\uD0DC\uB97C \uD655\uC778\uD558\uACE0 \uC788\uC2B5\uB2C8\uB2E4."
  },
  diagnostics_copied: {
    message: "\uC9C4\uB2E8 \uC815\uBCF4\uB97C \uBCF5\uC0AC\uD588\uC2B5\uB2C8\uB2E4."
  },
  diagnostics_copy: {
    message: "\uC9C4\uB2E8 \uC815\uBCF4 \uBCF5\uC0AC"
  },
  diagnostics_copy_failed: {
    message: "\uC790\uB3D9 \uBCF5\uC0AC\uAC00 \uD5C8\uC6A9\uB418\uC9C0 \uC54A\uC544 \uB0B4\uC6A9\uC744 \uC120\uD0DD\uD588\uC2B5\uB2C8\uB2E4. \uC9C1\uC811 \uBCF5\uC0AC\uD574 \uC8FC\uC138\uC694."
  },
  diagnostics_description: {
    message: "\uBC84\uC804\xB7\uC124\uC815\xB7\uC624\uB958\xB7\uC2DC\uAC01\uACFC \uD604\uC7AC \uD0ED\uC758 \uD45C\uC2DC \uB300\uC0C1 \uBC1C\uACAC \uC5EC\uBD80\xB7\uC694\uC18C \uAC1C\uC218\uB9CC \uD655\uC778\uD569\uB2C8\uB2E4. \uC785\uB825 \uB0B4\uC6A9\xB7\uACC4\uC815\xB7URL\uC740 \uD3EC\uD568\uD558\uC9C0 \uC54A\uC73C\uBA70 \uC790\uB3D9\uC73C\uB85C \uC804\uC1A1\uB418\uC9C0 \uC54A\uC2B5\uB2C8\uB2E4."
  },
  diagnostics_not_ready: {
    message: "\uC0C1\uD0DC\uB97C \uC544\uC9C1 \uC77D\uC9C0 \uBABB\uD588\uC2B5\uB2C8\uB2E4. \uC7A0\uC2DC \uD6C4 \uB2E4\uC2DC \uB20C\uB7EC \uC8FC\uC138\uC694."
  },
  diagnostics_output_label: {
    message: "\uB85C\uCEEC \uC9C4\uB2E8 \uC815\uBCF4"
  },
  diagnostics_show: {
    message: "\uD604\uC7AC \uC0C1\uD0DC \uBCF4\uAE30"
  },
  diagnostics_shown: {
    message: "\uD604\uC7AC \uC0C1\uD0DC\uB97C \uD45C\uC2DC\uD588\uC2B5\uB2C8\uB2E4. \uC790\uB3D9\uC73C\uB85C \uC804\uC1A1\uB418\uC9C0 \uC54A\uC2B5\uB2C8\uB2E4."
  },
  diagnostics_title: {
    message: "\uC9C4\uB2E8 \uC815\uBCF4"
  },
  error_access_denied: {
    message: "\uC0AC\uC774\uD2B8\uAC00 \uC811\uADFC\uC744 \uAC70\uBD80\uD588\uC2B5\uB2C8\uB2E4. \uBCF4\uD638\uC7A5\uCE58\uB97C \uC6B0\uD68C\uD558\uC9C0 \uC54A\uC2B5\uB2C8\uB2E4."
  },
  error_ambiguous_account: {
    message: "\uC5EC\uB7EC Claude \uC870\uC9C1\uC774 \uD655\uC778\uB418\uC5B4 \uC120\uD0DD\uD560 \uC218 \uC5C6\uC2B5\uB2C8\uB2E4. \uACC4\uC815\uC758 \uC0AC\uC6A9\uB7C9 \uD654\uBA74\uC744 \uD655\uC778\uD574 \uC8FC\uC138\uC694."
  },
  error_invalid_response: {
    message: "\uC0AC\uC6A9\uB7C9 \uC751\uB2F5 \uD615\uC2DD\uC744 \uD655\uC778\uD560 \uC218 \uC5C6\uC2B5\uB2C8\uB2E4."
  },
  error_network: {
    message: "\uC5F0\uACB0 \uB610\uB294 \uC694\uCCAD \uC2DC\uAC04\uC774 \uCD08\uACFC\uB418\uC5C8\uC2B5\uB2C8\uB2E4."
  },
  error_not_collected: {
    message: "\uC544\uC9C1 \uC218\uC9D1\uD558\uC9C0 \uC54A\uC558\uC2B5\uB2C8\uB2E4."
  },
  error_open_tab: {
    message: "\uB85C\uADF8\uC778\uD55C \uC11C\uBE44\uC2A4 \uD0ED\uC744 \uC5F0 \uB4A4 \uD31D\uC5C5\uC744 \uB2E4\uC2DC \uC5F4\uC5B4 \uC8FC\uC138\uC694."
  },
  error_permission_required: {
    message: "\uC774 \uC11C\uBE44\uC2A4\uC758 \uC0AC\uC774\uD2B8 \uC811\uADFC \uAD8C\uD55C\uC774 \uD544\uC694\uD569\uB2C8\uB2E4."
  },
  error_rate_limited: {
    message: "\uC694\uCCAD \uD55C\uB3C4\uC5D0 \uB3C4\uB2EC\uD588\uC2B5\uB2C8\uB2E4. \uC7AC\uC2DC\uB3C4 \uC2DC\uAC01\uAE4C\uC9C0 \uAE30\uB2E4\uB824 \uC8FC\uC138\uC694."
  },
  error_server: {
    message: "\uC11C\uBE44\uC2A4 \uC624\uB958\uC785\uB2C8\uB2E4. \uC7A0\uC2DC \uD6C4 \uB2E4\uC2DC \uC2DC\uB3C4\uD569\uB2C8\uB2E4."
  },
  error_signed_out: {
    message: "\uC0AC\uC774\uD2B8\uC5D0 \uB85C\uADF8\uC778\uD55C \uB4A4 \uD31D\uC5C5\uC744 \uB2E4\uC2DC \uC5F4\uC5B4 \uC8FC\uC138\uC694."
  },
  error_tab_access_failed: {
    message: "\uC5F4\uB9B0 \uC11C\uBE44\uC2A4 \uD0ED\uC5D0\uC11C \uC218\uC9D1 \uCF54\uB4DC\uB97C \uC2E4\uD589\uD558\uC9C0 \uBABB\uD588\uC2B5\uB2C8\uB2E4. \uB9C8\uC9C0\uB9C9 \uC720\uD6A8 \uC0AC\uC6A9\uB7C9\uC744 \uC720\uC9C0\uD558\uBA70 \uC790\uB3D9\uC73C\uB85C \uB2E4\uC2DC \uC2DC\uB3C4\uD569\uB2C8\uB2E4."
  },
  error_unsupported: {
    message: "\uC548\uC804\uD55C \uC218\uC9D1 \uACC4\uC57D\uC744 \uAC80\uC99D\uD558\uC9C0 \uBABB\uD574 \uBBF8\uC9C0\uC6D0\uC785\uB2C8\uB2E4."
  },
  extension_description: {
    message: "ChatGPT, Claude, Gemini \uC0AC\uC6A9\uB7C9\uACFC \uCD08\uAE30\uD654 \uC2DC\uAC01\uC744 \uBCF4\uC5EC\uC8FC\uB294 \uB85C\uCEEC \uC804\uC6A9 \uD655\uC7A5\uC785\uB2C8\uB2E4."
  },
  format_duration_left: {
    message: "$1 \uB0A8\uC74C"
  },
  format_last_collected: {
    message: "\uB9C8\uC9C0\uB9C9 \uC815\uC0C1 \uC218\uC9D1: $1"
  },
  format_less_than_minute: {
    message: "1\uBD84 \uBBF8\uB9CC"
  },
  format_not_collected: {
    message: "\uC815\uC0C1 \uC218\uC9D1 \uAE30\uB85D \uC5C6\uC74C"
  },
  format_relative_day_one: {
    message: "$1\uC77C \uD6C4"
  },
  format_relative_day_other: {
    message: "$1\uC77C \uD6C4"
  },
  format_relative_hour_one: {
    message: "$1\uC2DC\uAC04 \uD6C4"
  },
  format_relative_hour_other: {
    message: "$1\uC2DC\uAC04 \uD6C4"
  },
  format_relative_minute_one: {
    message: "$1\uBD84 \uD6C4"
  },
  format_relative_minute_other: {
    message: "$1\uBD84 \uD6C4"
  },
  format_remaining: {
    message: "$1 \uB0A8\uC74C"
  },
  format_remaining_unknown: {
    message: "\uB0A8\uC740 \uC2DC\uAC04 \uD655\uC778 \uBD88\uAC00"
  },
  format_reset_countdown: {
    message: "\u{1F552} \uCD08\uAE30\uD654: $1"
  },
  format_reset_pending: {
    message: "\uCD08\uAE30\uD654 \uD6C4 \uD655\uC778 \uC911"
  },
  format_reset_popup: {
    message: "\u{1F552} \uC0AC\uC6A9\uB7C9 \uCD08\uAE30\uD654: $1"
  },
  format_reset_unavailable: {
    message: "\u{1F552} \uCD08\uAE30\uD654: $1"
  },
  format_unknown: {
    message: "\uD655\uC778 \uBD88\uAC00"
  },
  format_usage: {
    message: "\uC0AC\uC6A9\uB7C9: $1"
  },
  format_usage_name: {
    message: "\uC0AC\uC6A9\uB7C9"
  },
  limit_additional: {
    message: "\uCD94\uAC00 \uC81C\uD55C"
  },
  limit_days_one: {
    message: "$1\uC77C"
  },
  limit_days_other: {
    message: "$1\uC77C"
  },
  limit_hours_one: {
    message: "$1\uC2DC\uAC04"
  },
  limit_hours_other: {
    message: "$1\uC2DC\uAC04"
  },
  limit_legacy_shared: {
    message: "Work / Codex \uACF5\uC720"
  },
  limit_primary: {
    message: "\uAE30\uBCF8 \uC81C\uD55C"
  },
  limit_weekly: {
    message: "\uC8FC\uAC04"
  },
  popup_communication_failed: {
    message: "\uD655\uC7A5 \uD504\uB85C\uADF8\uB7A8\uACFC \uD1B5\uC2E0\uD560 \uC218 \uC5C6\uC2B5\uB2C8\uB2E4. \uD655\uC7A5\uC744 \uB2E4\uC2DC \uB85C\uB4DC\uD574 \uC8FC\uC138\uC694."
  },
  popup_danger_threshold: {
    message: "\uACBD\uACE0 \uC2DC\uC791 \uC0AC\uC6A9\uB960"
  },
  popup_disable: {
    message: "\uB044\uAE30"
  },
  popup_disabled: {
    message: "\uAEBC\uC9D0"
  },
  popup_enable: {
    message: "\uCF1C\uAE30"
  },
  popup_grant_enable: {
    message: "\uAD8C\uD55C \uC2B9\uC778 \uBC0F \uCF1C\uAE30"
  },
  popup_language: {
    message: "\uC5B8\uC5B4"
  },
  popup_language_english: {
    message: "\uC601\uC5B4"
  },
  popup_language_korean: {
    message: "\uD55C\uAD6D\uC5B4"
  },
  popup_language_system: {
    message: "\uC2DC\uC2A4\uD15C \uAE30\uBCF8 \uC5B8\uC5B4"
  },
  popup_limit_previous_usage: {
    message: "$1 \uC0AC\uC6A9\uB7C9 (\uC774\uC804 \uAC12)"
  },
  popup_limit_usage: {
    message: "$1 \uC0AC\uC6A9\uB7C9"
  },
  popup_local_only: {
    message: "\uB85C\uCEEC \uC804\uC6A9"
  },
  popup_onboarding_description: {
    message: "\uC120\uD0DD\uD55C \uC11C\uBE44\uC2A4\uC758 \uAD8C\uD55C\uC744 \uD55C \uBC88\uC5D0 \uD5C8\uC6A9\uD558\uACE0 \uC0AC\uC6A9\uB7C9\uC744 \uD655\uC778\uD569\uB2C8\uB2E4."
  },
  popup_onboarding_start: {
    message: "\uAD8C\uD55C \uD5C8\uC6A9 \uBC0F \uC2DC\uC791"
  },
  popup_onboarding_title: {
    message: "\uC0AC\uC6A9\uD560 \uC11C\uBE44\uC2A4\uB97C \uC120\uD0DD\uD558\uC138\uC694"
  },
  popup_open_site: {
    message: "$1 \uC0AC\uC774\uD2B8 \uC5F4\uAE30 (\uC0C8 \uD0ED)"
  },
  popup_permission_canceled: {
    message: "\uAD8C\uD55C \uC2B9\uC778\uC774 \uCDE8\uC18C\uB418\uC5C8\uC2B5\uB2C8\uB2E4."
  },
  popup_previous_usage: {
    message: "\uC774\uC804 \uC218\uC9D1\uAC12"
  },
  popup_provider_plan: {
    message: "$1 \uC694\uAE08\uC81C: $2"
  },
  popup_provider_usage: {
    message: "$1 \uC0AC\uC6A9\uB7C9"
  },
  popup_revoke: {
    message: "\uAD8C\uD55C \uCCA0\uD68C"
  },
  popup_settings: {
    message: "\uC124\uC815"
  },
  popup_settings_saved: {
    message: "\uC124\uC815\uC744 \uC800\uC7A5\uD588\uC2B5\uB2C8\uB2E4."
  },
  popup_show_in_composer: {
    message: "$1 \uC785\uB825\uCC3D\uC5D0 \uD45C\uC2DC"
  },
  popup_threshold_order_error: {
    message: "\uC8FC\uC758 \uC2DC\uC791 \uC0AC\uC6A9\uB960\uC740 \uACBD\uACE0 \uC2DC\uC791 \uC0AC\uC6A9\uB960\uBCF4\uB2E4 \uC791\uC544\uC57C \uD569\uB2C8\uB2E4."
  },
  popup_threshold_range_error: {
    message: "\uC8FC\uC758\xB7\uACBD\uACE0 \uC2DC\uC791 \uC0AC\uC6A9\uB960\uC740 0~100 \uC0AC\uC774\uC758 \uC22B\uC790\uB85C \uC785\uB825\uD574 \uC8FC\uC138\uC694."
  },
  popup_usage_unavailable: {
    message: "\uC0AC\uC6A9\uB7C9 \uD655\uC778 \uBD88\uAC00"
  },
  popup_warning_threshold: {
    message: "\uC8FC\uC758 \uC2DC\uC791 \uC0AC\uC6A9\uB960"
  },
  status_access_denied: {
    message: "\uC0AC\uC774\uD2B8 \uC811\uADFC \uAC70\uBD80"
  },
  status_ambiguous_account: {
    message: "Claude \uC870\uC9C1 \uC120\uD0DD \uD544\uC694"
  },
  status_invalid_response: {
    message: "\uC0AC\uC6A9\uB7C9 \uD655\uC778 \uBD88\uAC00"
  },
  status_network: {
    message: "\uC5F0\uACB0 \uD655\uC778 \uC911"
  },
  status_not_collected: {
    message: "\uC0AC\uC6A9\uB7C9 \uD655\uC778 \uC911"
  },
  status_ok: {
    message: "\uCD5C\uADFC \uC218\uC9D1 \uC131\uACF5"
  },
  status_open_tab: {
    message: "\uC11C\uBE44\uC2A4 \uD0ED \uC5F4\uAE30 \uD544\uC694"
  },
  status_permission_required: {
    message: "\uC0AC\uC774\uD2B8 \uAD8C\uD55C \uD544\uC694"
  },
  status_rate_limited: {
    message: "\uC7A0\uC2DC \uD6C4 \uB2E4\uC2DC \uD655\uC778"
  },
  status_server: {
    message: "\uC11C\uBE44\uC2A4 \uC751\uB2F5 \uB300\uAE30"
  },
  status_signed_out: {
    message: "\uB85C\uADF8\uC778 \uD544\uC694"
  },
  status_tab_access_failed: {
    message: "\uC0AC\uC6A9\uB7C9 \uB2E4\uC2DC \uD655\uC778 \uC911"
  },
  status_unsupported: {
    message: "\uC0AC\uC6A9\uB7C9 \uC218\uC9D1 \uBBF8\uC9C0\uC6D0"
  },
  ticket_availability_unknown: {
    message: "\uC0AC\uC6A9 \uAC00\uB2A5 \uC5EC\uBD80 \uD655\uC778 \uBD88\uAC00"
  },
  ticket_blocked: {
    message: "\uC0AC\uC6A9 \uC81C\uD55C \uC911"
  },
  ticket_count_one: {
    message: "$1\uAC1C"
  },
  ticket_count_other: {
    message: "$1\uAC1C"
  },
  ticket_expiry: {
    message: "$1 \uB9CC\uB8CC"
  },
  ticket_inline: {
    message: "\u{1F3AB} \uD2F0\uCF13 \uB9CC\uB8CC: $1"
  },
  ticket_kind_five_hour: {
    message: "5\uC2DC\uAC04 \uD55C\uB3C4"
  },
  ticket_kind_full: {
    message: "\uC804\uCCB4 \uD55C\uB3C4"
  },
  ticket_kind_unspecified: {
    message: "\uC885\uB958 \uD655\uC778 \uBD88\uAC00"
  },
  ticket_kind_weekly: {
    message: "\uC8FC\uAC04 \uD55C\uB3C4"
  },
  ticket_management_action: {
    message: "\uACF5\uC2DD \uC0AC\uC6A9\uB7C9 \uAD00\uB9AC \uD654\uBA74 \uC5F4\uAE30 (\uC0C8 \uD0ED)"
  },
  ticket_other_first: {
    message: "\uB2E4\uB978 \uD2F0\uCF13 \uC6B0\uC120"
  },
  ticket_requires_limit: {
    message: "\uD55C\uB3C4 \uB3C4\uB2EC \uC870\uAC74"
  },
  ticket_starts: {
    message: "$1\uBD80\uD130"
  },
  ticket_total_one: {
    message: "\u{1F3AB} \uCD08\uAE30\uD654 \uD2F0\uCF13 $1\uAC1C"
  },
  ticket_total_other: {
    message: "\u{1F3AB} \uCD08\uAE30\uD654 \uD2F0\uCF13 $1\uAC1C"
  },
  ticket_unavailable_now: {
    message: "\uD604\uC7AC \uC0AC\uC6A9 \uBD88\uAC00"
  }
};

// src/shared/i18n.ts
var api = globalThis.chrome?.i18n;
var preference = "system";
function setLanguagePreference(language) {
  preference = language === "en" || language === "ko" ? language : "system";
}
function languageForUI(language) {
  return /^ko(?:-|$)/i.test(language) ? "ko" : "en";
}
function uiLanguage() {
  return preference === "system" ? languageForUI(api?.getUILanguage() ?? "en") : preference;
}
function t(key2, substitutions = []) {
  const values = typeof substitutions === "string" ? [substitutions] : substitutions;
  const translated = preference === "system" ? api?.getMessage(key2, values) : "";
  if (translated) return translated;
  const message = (uiLanguage() === "ko" ? messages_default2[key2] : messages_default[key2])?.message ?? messages_default[key2].message;
  return message.replace(/\$(\d+)/g, (_, index) => values[Number(index) - 1] ?? "");
}

// src/shared/limit-label.ts
function localizedLimitLabel(limit, provider) {
  const label2 = provider === "chatgpt" ? limit.label.replace(/^(?:ChatGPT\s*·\s*|Work\s*\/\s*Codex\s*공유\s*(?:[·:–—-]\s*)?)/, "").trim() : limit.label;
  return label2.split(" \xB7 ").map((part) => {
    const period = /^(\d+(?:\.\d+)?)(시간|일)$/.exec(part);
    if (period) {
      const value = period[1], unit = period[2] === "\uC77C" ? "days" : "hours";
      return t(`limit_${unit}_${Number(value) === 1 ? "one" : "other"}`, value);
    }
    if (part === "\uAE30\uBCF8 \uC81C\uD55C") return t("limit_primary");
    if (part === "\uCD94\uAC00 \uC81C\uD55C") return t("limit_additional");
    if (part === "\uC8FC\uAC04") return t("limit_weekly");
    if (part === "Work / Codex \uACF5\uC720") return t("limit_legacy_shared");
    return part;
  }).join(" \xB7 ") || t("format_usage_name");
}

// src/shared/format.ts
var geminiErrorText = (text) => Object.fromEntries(GEMINI_RESPONSE_ERRORS.map((code) => [code, text]));
var usageValue = (limit) => limit.percent !== null ? `${Math.round(limit.percent)}%` : limit.remaining !== null ? t("format_remaining", `${limit.remaining.toLocaleString(uiLanguage())}${limit.unit ?? ""}`) : t("format_unknown");
var usageText = (limit) => `${localizedLimitLabel(limit)}: ${usageValue(limit)}`;
var STATUS_KEYS = {
  not_collected: "status_not_collected",
  signed_out: "status_signed_out",
  access_denied: "status_access_denied",
  rate_limited: "status_rate_limited",
  network: "status_network",
  server: "status_server",
  invalid_response: "status_invalid_response",
  ...geminiErrorText("status_invalid_response"),
  open_tab: "status_open_tab",
  tab_access_failed: "status_tab_access_failed",
  ambiguous_account: "status_ambiguous_account",
  unsupported: "status_unsupported",
  permission_required: "status_permission_required",
  reset_pending: "format_reset_pending"
};
function statusText(snapshot) {
  if (snapshot.state === "ok") return t("status_ok");
  if (snapshot.state === "stale") return t("status_not_collected");
  return snapshot.errorCode ? t(STATUS_KEYS[snapshot.errorCode]) : t("format_unknown");
}

// src/shared/errors.ts
var CollectionError = class extends Error {
  constructor(code, state = "error", retryAfterMs = 0) {
    super(code);
    this.code = code;
    this.state = state;
    this.retryAfterMs = retryAfterMs;
  }
  code;
  state;
  retryAfterMs;
};
function retryAfter(value, now = Date.now()) {
  if (!value) return 0;
  if (/^\d+(?:\.\d+)?$/.test(value)) {
    const ms = Number(value) * 1e3;
    return Number.isFinite(ms) && ms <= Number.MAX_SAFE_INTEGER ? Math.max(0, ms) : 0;
  }
  const time = Date.parse(value);
  return Number.isFinite(time) ? Math.max(0, time - now) : 0;
}
function httpError(status, wait = 0) {
  if (status === 401) return new CollectionError("signed_out", "signed_out");
  if (status === 429) return new CollectionError("rate_limited", "rate_limited", wait);
  if (status === 403) return new CollectionError("access_denied");
  return new CollectionError(status >= 500 ? "server" : "invalid_response");
}
var ERROR_KEYS = {
  not_collected: "error_not_collected",
  signed_out: "error_signed_out",
  access_denied: "error_access_denied",
  rate_limited: "error_rate_limited",
  network: "error_network",
  invalid_response: "error_invalid_response",
  ...geminiErrorText("error_invalid_response"),
  open_tab: "error_open_tab",
  ambiguous_account: "error_ambiguous_account",
  tab_access_failed: "error_tab_access_failed",
  unsupported: "error_unsupported",
  permission_required: "error_permission_required",
  server: "error_server",
  reset_pending: "format_reset_pending"
};
var ERROR_TEXT = Object.defineProperties({}, Object.fromEntries(
  Object.entries(ERROR_KEYS).map(([code, key2]) => [code, { enumerable: true, get: () => t(key2) }])
));

// src/shared/plan.ts
var LABELS = {
  chatgpt: ["Free", "Go", "Plus", "Pro", "Pro 100", "Pro 200", "Pro 500", "Team", "Business", "Enterprise", "Education", "Education (K-12)"],
  claude: ["Free", "Pro", "Max", "Max 5x", "Max 20x", "Team", "Enterprise"],
  gemini: ["Free", "AI Plus", "AI Pro", "AI Ultra", "Workspace"]
};
var PLAN_MAX_AGE_MS = 10 * 6e4;
function knownPlanLabel(provider, input) {
  return typeof input === "string" && LABELS[provider].includes(input) ? input : null;
}
function parsePlan(provider, input) {
  const raw = record(input), label2 = knownPlanLabel(provider, raw?.label);
  return label2 && finite(raw?.checkedAt) && raw.checkedAt > 0 ? { label: label2, checkedAt: raw.checkedAt } : null;
}

// src/shared/tickets.ts
var count = (value) => Number.isSafeInteger(value) && value >= 0;
var nullableBoolean = (value) => value === null || typeof value === "boolean";
var date = (value) => value === null || resetTime(value) !== null;
var kinds = ["full", "five_hour", "weekly", "unspecified"];
function parseTicketInventory(input) {
  const raw = record(input);
  if (!raw || typeof raw.mode !== "string" || !["summary", "detail"].includes(raw.mode) || !Array.isArray(raw.grants) || raw.grants.length > 100 || !(raw.usableCount === null || count(raw.usableCount)) || !date(raw.cooldownUntil)) return null;
  const grants = [];
  for (const value of raw.grants) {
    const grant = record(value);
    if (!grant || typeof grant.kind !== "string" || !kinds.includes(grant.kind) || !count(grant.count) || !date(grant.startsAt) || !date(grant.expiresAt) || !nullableBoolean(grant.usableNow) || !nullableBoolean(grant.requiresLimit) || !nullableBoolean(grant.blocked) || !nullableBoolean(grant.selected) || !Array.isArray(grant.clears) || grant.clears.length > 64 || !grant.clears.every((value2) => typeof value2 === "string" && /^(five_hour|seven_day(?:_[a-z0-9_]+)?)$/.test(value2) && value2.length <= 64)) return null;
    const startsAt = resetTime(grant.startsAt), expiresAt = resetTime(grant.expiresAt);
    if (startsAt && expiresAt && Date.parse(startsAt) >= Date.parse(expiresAt)) return null;
    grants.push({
      kind: grant.kind,
      count: grant.count,
      startsAt,
      expiresAt,
      usableNow: grant.usableNow,
      clears: [...new Set(grant.clears)],
      requiresLimit: grant.requiresLimit,
      blocked: grant.blocked,
      selected: grant.selected
    });
  }
  const total = grants.reduce((sum, grant) => sum + grant.count, 0);
  if (!count(total) || raw.usableCount !== null && raw.usableCount > total) return null;
  if (raw.mode === "summary" && grants.some((grant) => grant.kind !== "unspecified" || grant.startsAt !== null || grant.expiresAt !== null)) return null;
  return {
    mode: raw.mode,
    grants,
    usableCount: raw.usableCount,
    cooldownUntil: resetTime(raw.cooldownUntil)
  };
}
function parseTicketCache(input) {
  const raw = record(input), inventory = parseTicketInventory(raw?.inventory);
  return inventory && finite(raw?.checkedAt) && raw.checkedAt > 0 && count(raw.failures) ? { inventory, checkedAt: raw.checkedAt, failures: raw.failures } : null;
}

// src/storage/snapshots.ts
var FRESH_MS = 10 * 6e4;
function emptySnapshot(provider) {
  return { provider, state: "error", limits: [], collectedAt: null, checkedAt: null, nextAttemptAt: 0, failures: 0, errorCode: "not_collected" };
}
function validLimits(input) {
  return Array.isArray(input) && input.length <= 150 && input.every((x) => {
    const r = record(x);
    return r && typeof r.id === "string" && r.id.length > 0 && r.id.length <= 200 && label(r.label) && ["window", "model", "product"].includes(String(r.category)) && r.source === "api" && (r.percent === null || percent(r.percent) !== null) && (r.resetsAt === null || resetTime(r.resetsAt) !== null) && (r.windowSeconds === null || nonnegative(r.windowSeconds) !== null) && (r.remaining === null || nonnegative(r.remaining) !== null) && (r.unit === null || label(r.unit));
  }) && new Set(input.map((x) => x.id)).size === input.length;
}
var STATES = ["ok", "stale", "signed_out", "permission_required", "rate_limited", "unsupported", "error"];
function parseSnapshot(input, provider) {
  const r = record(input);
  if (!r || r.provider !== provider || !STATES.includes(String(r.state)) || !validLimits(r.limits) || !(r.collectedAt === null || finite(r.collectedAt)) || !(r.checkedAt === null || finite(r.checkedAt)) || !finite(r.nextAttemptAt) || !finite(r.failures) || !(r.errorCode === null || typeof r.errorCode === "string" && Object.hasOwn(ERROR_TEXT, r.errorCode))) return emptySnapshot(provider);
  if (r.state === "ok" && (r.collectedAt === null || r.limits.length === 0)) return emptySnapshot(provider);
  const limits = r.limits.map((limit) => ({
    id: limit.id,
    label: label(limit.label),
    category: limit.category,
    percent: limit.percent,
    resetsAt: limit.resetsAt === null ? null : resetTime(limit.resetsAt),
    windowSeconds: limit.windowSeconds,
    remaining: limit.remaining,
    unit: limit.unit === null ? null : label(limit.unit),
    source: "api"
  }));
  return {
    provider,
    state: r.state,
    limits,
    collectedAt: r.collectedAt,
    checkedAt: r.checkedAt,
    nextAttemptAt: Math.max(0, r.nextAttemptAt),
    failures: Math.max(0, r.failures),
    errorCode: r.errorCode,
    ...r.usageInvalidated === true ? { usageInvalidated: true } : {},
    ...Object.hasOwn(r, "plan") ? { plan: parsePlan(provider, r.plan) } : {},
    ...Object.hasOwn(r, "planRefreshPending") ? { planRefreshPending: r.planRefreshPending === true } : {},
    ...Object.hasOwn(r, "tickets") ? { tickets: provider === "gemini" ? null : parseTicketCache(r.tickets) } : {},
    ...Object.hasOwn(r, "ticketRefreshPending") ? { ticketRefreshPending: r.ticketRefreshPending === true } : {}
  };
}
function hasElapsedReset(snapshot, now = Date.now()) {
  return snapshot.limits.some((limit) => {
    const reset = resetTime(limit.resetsAt);
    return reset !== null && Date.parse(reset) <= now;
  });
}
function effectiveSnapshot(snapshot, now = Date.now()) {
  const firstTransient = snapshot.failures === 1 && (snapshot.errorCode === "network" || snapshot.errorCode === "server");
  const cachedFallback = !snapshot.usageInvalidated && (firstTransient || snapshot.errorCode === "tab_access_failed");
  const legacyAgeOnly = snapshot.state === "stale" && snapshot.errorCode === null && snapshot.failures === 0;
  const current = snapshot.state === "ok";
  if (!current && !legacyAgeOnly && !(snapshot.state === "error" && cachedFallback)) return snapshot;
  if (snapshot.usageInvalidated || current && snapshot.errorCode !== null && !cachedFallback) return { ...snapshot, state: "error" };
  const usable = finite(now) && finite(snapshot.collectedAt) && snapshot.collectedAt > 0 && snapshot.collectedAt <= now + 6e4 && snapshot.limits.length > 0 && validLimits(snapshot.limits);
  if (!usable) return current || legacyAgeOnly ? { ...snapshot, state: "error", errorCode: "invalid_response" } : snapshot;
  if (hasElapsedReset(snapshot, now)) return { ...snapshot, state: "error", errorCode: "reset_pending" };
  return current ? snapshot : { ...snapshot, state: "ok" };
}
async function readSnapshot(provider) {
  await migrateStorage();
  const key2 = snapshotKey(provider);
  return parseSnapshot((await chrome.storage.local.get(key2))[key2], provider);
}
var SNAPSHOT_KEYS = { chatgpt: "snapshot:v4:chatgpt", claude: "snapshot:v2:claude", gemini: "snapshot:v1:gemini" };
var snapshotKey = (provider) => SNAPSHOT_KEYS[provider];
var SETTINGS_KEY = "settings:v2";
var MIGRATION_KEY = "migration:shared-chatgpt:v2";
var migrations = /* @__PURE__ */ new WeakMap();
function legacySettings(input) {
  const old = record(input), enabled = record(old?.enabled), strips = record(old?.strips);
  return parseSettings({
    enabled: { chatgpt: enabled?.work_codex, claude: enabled?.claude },
    strips: { chatgpt: strips?.chatgpt, codex: strips?.work_codex, claude: strips?.claude },
    warning: old?.warning,
    danger: old?.danger
  });
}
async function migrate(local) {
  const sharedKey = snapshotKey("chatgpt");
  const stored = await local.get([MIGRATION_KEY, SETTINGS_KEY, sharedKey, "settings", "snapshot:v2:work_codex"]);
  if (stored[MIGRATION_KEY] === true) return;
  const updates = { [MIGRATION_KEY]: true };
  updates[SETTINGS_KEY] = Object.hasOwn(stored, SETTINGS_KEY) ? parseSettings(stored[SETTINGS_KEY]) : legacySettings(stored.settings);
  if (!Object.hasOwn(stored, sharedKey)) {
    const old = record(stored["snapshot:v2:work_codex"]);
    updates[sharedKey] = old?.provider === "work_codex" ? parseSnapshot({
      provider: "chatgpt",
      state: old.state,
      limits: old.limits,
      collectedAt: old.collectedAt,
      checkedAt: old.checkedAt,
      nextAttemptAt: old.nextAttemptAt,
      failures: old.failures,
      errorCode: old.errorCode
    }, "chatgpt") : emptySnapshot("chatgpt");
  }
  await local.set(updates);
}
function migrateStorage() {
  const local = chrome.storage.local;
  let pending2 = migrations.get(local);
  if (!pending2) {
    pending2 = migrate(local).catch((error) => {
      migrations.delete(local);
      throw error;
    });
    migrations.set(local, pending2);
  }
  return pending2;
}
async function writeSnapshot(snapshot) {
  await migrateStorage();
  await chrome.storage.local.set({ [snapshotKey(snapshot.provider)]: parseSnapshot(snapshot, snapshot.provider) });
}
async function readSettings() {
  await migrateStorage();
  return parseSettings((await chrome.storage.local.get(SETTINGS_KEY))[SETTINGS_KEY]);
}
async function writeSettings(settings) {
  await migrateStorage();
  await chrome.storage.local.set({ [SETTINGS_KEY]: parseSettings(settings) });
}
async function readView() {
  await migrateStorage();
  const [stored, granted] = await Promise.all([
    chrome.storage.local.get([SETTINGS_KEY, ...PROVIDERS.map(snapshotKey)]),
    Promise.all(PROVIDERS.map((p) => chrome.permissions.contains({ origins: [ORIGINS[p]] })))
  ]);
  const settings = parseSettings(stored[SETTINGS_KEY]);
  const permissions = {}, snapshots = {};
  PROVIDERS.forEach((p, index) => {
    permissions[p] = granted[index];
    const s = effectiveSnapshot(parseSnapshot(stored[snapshotKey(p)], p));
    snapshots[p] = permissions[p] ? s : { ...s, state: "permission_required", errorCode: "permission_required" };
  });
  return { settings, snapshots, permissions };
}

// src/shared/display-policy.ts
var displayProvider = (page) => page === "codex" ? "chatgpt" : page;
function shouldShowStrip(view, page) {
  const source = displayProvider(page);
  return view.permissions[source] && view.settings.enabled[source] && view.settings.strips[page];
}
function needsContent(view, pages) {
  return pages.some((page) => shouldShowStrip(view, page));
}
var canRefreshFromPage = (page, source) => displayProvider(page) === source;

// src/shared/contracts.ts
function parseMessage(input) {
  const r = record(input);
  if (!r) return null;
  const keys = Object.keys(r).sort().join(",");
  if ((r.type === "view" || r.type === "read") && keys === "type") return { type: r.type };
  if ((r.type === "enable" || r.type === "disable" || r.type === "context") && keys === "provider,type" && isProvider(r.provider)) return { type: r.type, provider: r.provider };
  if (r.type === "enable-many" && keys === "providers,type" && Array.isArray(r.providers) && r.providers.length > 0 && r.providers.length <= PROVIDERS.length && r.providers.every(isProvider) && new Set(r.providers).size === r.providers.length) {
    return { type: "enable-many", providers: [...r.providers] };
  }
  if (r.type === "display-settings" && keys === "danger,language,strips,type,warning") {
    const strips = parseStrips(r.strips), thresholds = parseUsageThresholds(r.warning, r.danger);
    if (strips && thresholds && isLanguagePreference(r.language)) return { type: "display-settings", strips, language: r.language, ...thresholds };
  }
  if (r.type === "refresh" && keys === "provider,trigger,type" && isProvider(r.provider) && (r.trigger === "manual" || r.trigger === "event")) {
    return { type: "refresh", provider: r.provider, trigger: r.trigger };
  }
  return null;
}
function authorized(message, sender, extensionId) {
  if (sender.id !== extensionId) return false;
  if (sender.tab) {
    const p = providerFromUrl(sender.url);
    if (p === null || providerFromUrl(sender.tab.url) !== p || sender.frameId !== 0) return false;
    return message.type === "view" || message.type === "context" && canRefreshFromPage(p, message.provider) || message.type === "refresh" && canRefreshFromPage(p, message.provider) && message.trigger === "event";
  }
  return message.type !== "context" && sender.url === `chrome-extension://${extensionId}/popup.html`;
}

// src/providers/gemini-transport.ts
async function collectGeminiInPage(workerToken, workerSignal) {
  const result = (status, code = null, wait = null, data = null) => ({ status, code, retryAfter: wait, data });
  const page = workerToken === void 0 ? new URL(location.href) : null;
  if (page && page.origin !== "https://gemini.google.com") return result(0, "open_tab");
  const account = page ? /^\/u\/([^/]+)(?:\/|$)/.exec(page.pathname)?.[1] : void 0;
  if (account !== void 0 && account !== "0" || page?.searchParams.getAll("authuser").some((value) => value !== "0")) return result(200, "unsupported");
  const controller = new AbortController(), timeout = setTimeout(() => controller.abort(), 15e3);
  const signal = workerSignal ? AbortSignal.any([controller.signal, workerSignal]) : controller.signal;
  const fail = (code = "gemini_frame_invalid") => {
    throw new Error(code);
  };
  const sanitize = (payload) => {
    const invalid = () => fail("gemini_quota_invalid");
    if (!Array.isArray(payload) || !Array.isArray(payload[1]) || payload[1].length > 20) return invalid();
    const windows = [], seen = /* @__PURE__ */ new Set();
    for (const row of payload[1]) {
      if (!Array.isArray(row) || !Number.isInteger(row[2])) return invalid();
      const type = row[2];
      if (type !== 1 && type !== 2) continue;
      if (seen.has(type)) return invalid();
      seen.add(type);
      const ratio = row[1];
      if (ratio != null && (typeof ratio !== "number" || !Number.isFinite(ratio) || ratio < 0 || ratio > 1)) return invalid();
      let reset = null;
      if (row[3] != null) {
        const outer = row[3];
        if (!Array.isArray(outer) || outer.length !== 1 || !Array.isArray(outer[0])) return invalid();
        const stamp = outer[0], seconds = stamp[0], nanos = stamp.length === 1 ? 0 : stamp[1];
        if (stamp.length < 1 || stamp.length > 2 || typeof seconds !== "number" || !Number.isSafeInteger(seconds) || seconds <= 0 || seconds >= 4102444800 || typeof nanos !== "number" || !Number.isInteger(nanos) || nanos < 0 || nanos >= 1e9) return invalid();
        reset = [[seconds, nanos]];
      }
      windows.push([null, ratio ?? null, type, reset]);
    }
    if (!windows.length) return invalid();
    return [null, windows];
  };
  const decode = (body, rpc) => {
    if (!body || body.length > 1048576) return fail();
    let text = body.trimStart();
    if (text.startsWith(")]}'")) text = text.slice(4).trimStart();
    if (!text) return fail();
    const frames = [];
    if (text.startsWith("[")) {
      try {
        frames.push(JSON.parse(text));
      } catch {
        const lines = text.split(/\r?\n/).filter((line) => line.trim());
        if (lines.length > 100) return fail();
        for (const line of lines) {
          try {
            frames.push(JSON.parse(line));
          } catch {
            return fail();
          }
        }
      }
    } else {
      let cursor = 0;
      while (cursor < text.length) {
        while (/\s/.test(text[cursor] ?? "") && cursor < text.length) cursor++;
        if (cursor === text.length) break;
        const prefix = /^(\d{1,7})\r?\n/.exec(text.slice(cursor));
        if (!prefix) return fail();
        const length = Number(prefix[1]);
        if (length <= 0 || length > 1048576) return fail();
        let end = -1;
        for (const start of [cursor + prefix[1].length, cursor + prefix[0].length]) {
          const declaredEnd = start + length;
          const missingFinalLF = start === cursor + prefix[1].length && declaredEnd === text.length + 1;
          const candidateEnd = missingFinalLF ? text.length : declaredEnd;
          if (candidateEnd > text.length) continue;
          try {
            const frame = JSON.parse(text.slice(start, candidateEnd));
            if (!Array.isArray(frame)) continue;
            frames.push(frame);
            end = candidateEnd;
            break;
          } catch {
          }
        }
        if (end < 0) return fail();
        cursor = end;
        if (frames.length > 100) return fail();
      }
    }
    let answer = void 0, count3 = 0;
    for (const frame of frames) {
      if (!Array.isArray(frame) || frame.length > 100) return fail();
      for (const row of frame) {
        if (!Array.isArray(row) || typeof row[0] !== "string") return fail();
        if (row[0] !== "wrb.fr" || row[1] !== rpc && row[1] !== null) continue;
        const status = row[5];
        if (status != null) {
          if (Array.isArray(status) && (status[0] === 1037 || status[0] === 1060)) throw new Error("rate_limited");
          throw new Error("unsupported");
        }
        if (row[1] !== rpc) continue;
        if (++count3 !== 1 || typeof row[2] !== "string" || !row[2]) return fail("gemini_rpc_invalid");
        try {
          answer = JSON.parse(row[2]);
        } catch {
          return fail("gemini_rpc_invalid");
        }
      }
    }
    if (count3 !== 1) return fail("gemini_rpc_missing");
    return answer;
  };
  const read = async (response) => {
    if (!/^(?:application\/json|text\/plain)(?:;|$)/i.test(response.headers.get("Content-Type") ?? "")) return fail("gemini_response_type");
    const reader = response.body?.getReader();
    if (!reader) return fail("gemini_response_read");
    const decoder = new TextDecoder("utf-8", { fatal: true });
    let raw = "", bytes = 0;
    try {
      while (true) {
        const chunk = await reader.read().catch(() => fail("network"));
        if (chunk.done) break;
        bytes += chunk.value.byteLength;
        if (bytes > 1048576) {
          await reader.cancel().catch(() => void 0);
          return fail("gemini_response_read");
        }
        try {
          raw += decoder.decode(chunk.value, { stream: true });
        } catch {
          return fail("gemini_response_read");
        }
      }
      try {
        raw += decoder.decode();
      } catch {
        return fail("gemini_response_read");
      }
      return raw;
    } finally {
      reader.releaseLock();
    }
  };
  const policySignals = (payload) => {
    if (!Array.isArray(payload)) return null;
    const known = /* @__PURE__ */ new Set([
      "v3p2_free_policy",
      "v3p2_basic_policy",
      "v3p2_plus_policy",
      "v3p2_pro_policy",
      "v3p2_ultra_policy",
      "v3p2_business_policy",
      "basic_policy",
      "brownfield_basic_policy",
      "brownfield_paid_policy",
      "plus_policy",
      "neon_policy"
    ]);
    const policies = /* @__PURE__ */ new Set(), pending2 = [{ value: payload, depth: 0 }];
    let visited = 0;
    while (pending2.length) {
      const { value, depth } = pending2.pop();
      if (++visited > 4e3 || depth > 20) return null;
      if (typeof value === "string" && known.has(value)) policies.add(value);
      else if (Array.isArray(value)) {
        if (value.length > 1e3 || pending2.length + value.length > 4e3) return null;
        for (const child of value) pending2.push({ value: child, depth: depth + 1 });
      }
    }
    return [...policies];
  };
  try {
    const token = workerToken ?? window.WIZ_global_data?.SNlM0e;
    if (typeof token !== "string" || !token || token.length > 16384) return result(200, "unsupported");
    const request = (rpc, signal2) => fetch(`https://gemini.google.com/_/BardChatUi/data/batchexecute?rpcids=${rpc}&source-path=%2Fusage&rt=c`, {
      method: "POST",
      credentials: "include",
      cache: "no-store",
      redirect: "error",
      signal: signal2,
      headers: { "Content-Type": "application/x-www-form-urlencoded;charset=UTF-8", "X-Same-Domain": "1" },
      body: new URLSearchParams({ "f.req": JSON.stringify([[[rpc, "[]", null, "generic"]]]), at: token }).toString()
    });
    const response = await request("jSf9Qc", signal);
    if (!response.ok) {
      const wait = response.headers.get("Retry-After");
      return result(response.status, null, wait !== null && wait.length <= 100 ? wait : null);
    }
    try {
      const raw = decode(await read(response), "jSf9Qc"), usage = sanitize(raw);
      let plan = null;
      const planController = new AbortController(), planTimeout = setTimeout(() => planController.abort(), 3e3);
      try {
        const policyResponse = await request("otAQ7b", AbortSignal.any([signal, planController.signal]));
        if (policyResponse.ok) {
          const policies = policySignals(decode(await read(policyResponse), "otAQ7b"));
          const planId = Array.isArray(raw) ? raw[0] : null;
          if (policies && (!page || location.href === page.href && window.WIZ_global_data?.SNlM0e === token)) {
            plan = { planId: typeof planId === "number" && Number.isSafeInteger(planId) && planId >= 0 ? planId : null, policies };
          }
        }
      } catch {
      } finally {
        planController.abort();
        clearTimeout(planTimeout);
      }
      return result(200, null, null, { usage, plan });
    } catch (error) {
      if (error instanceof Error && error.message === "rate_limited") return result(429);
      const codes = ["unsupported", "network", "gemini_response_type", "gemini_response_read", "gemini_frame_invalid", "gemini_rpc_missing", "gemini_rpc_invalid", "gemini_quota_invalid"];
      return result(200, error instanceof Error && codes.includes(error.message) ? error.message : "invalid_response");
    }
  } catch {
    return result(0, "network");
  } finally {
    controller.abort();
    clearTimeout(timeout);
  }
}

// src/providers/gemini-bootstrap.ts
var MAX_BYTES = 4 * 1024 * 1024;
var MAX_SCRIPT = 256 * 1024;
var APP_URL = "https://gemini.google.com/app";
function bootstrapToken(script) {
  const assignment = /^\s*(?:window\.)?WIZ_global_data\s*=\s*/.exec(script);
  if (!assignment) return void 0;
  const source = script.slice(assignment[0].length);
  if (!source.startsWith("{")) return null;
  let depth = 0, quoted = false, escaped = false;
  for (let index = 0; index < source.length; index++) {
    const char = source[index];
    if (quoted) {
      if (escaped) escaped = false;
      else if (char === "\\") escaped = true;
      else if (char === '"') quoted = false;
      continue;
    }
    if (char === '"') quoted = true;
    else if (char === "{" || char === "[") depth++;
    else if (char === "}" || char === "]") {
      if (--depth !== 0) continue;
      try {
        const rest = source.slice(index + 1).trimStart();
        if (rest && !rest.startsWith(";")) return null;
        const value = JSON.parse(source.slice(0, index + 1));
        const token = value && typeof value === "object" && !Array.isArray(value) ? value.SNlM0e : null;
        return typeof token === "string" && token.length > 0 && token.length <= 16384 && !/[\u0000-\u001f\u007f]/.test(token) ? token : null;
      } catch {
        return null;
      }
    }
  }
  return void 0;
}
function tagEnd(source) {
  let quote = "";
  for (let index = 1; index < source.length; index++) {
    const char = source[index];
    if (quote) {
      if (char === quote) quote = "";
    } else if (char === '"' || char === "'") quote = char;
    else if (char === ">") return index;
  }
  return -1;
}
function executableScript(attributes) {
  const values = /* @__PURE__ */ new Map();
  const pattern = /([^\s=/>]+)(?:\s*=\s*(?:"([^"]*)"|'([^']*)'|([^\s>]+)))?/g;
  for (const match of attributes.matchAll(pattern)) {
    const name = match[1].toLowerCase();
    if (values.has(name)) return false;
    values.set(name, match[2] ?? match[3] ?? match[4] ?? "");
  }
  if (values.has("src") || values.has("nomodule")) return false;
  const type = values.get("type")?.trim().toLowerCase();
  const language = values.get("language")?.trim().toLowerCase();
  return (type === void 0 || type === "" || type === "text/javascript" || type === "application/javascript") && (language === void 0 || language === "" || language === "javascript");
}
async function readBootstrap(response) {
  if (!/^text\/html(?:;|$)/i.test(response.headers.get("Content-Type") ?? "")) return null;
  const reader = response.body?.getReader();
  if (!reader) return null;
  const decoder = new TextDecoder("utf-8", { fatal: true });
  let buffer = "", bytes = 0;
  let raw = null;
  const inert = [];
  try {
    while (true) {
      const chunk = await reader.read();
      if (chunk.done) return null;
      bytes += chunk.value.byteLength;
      if (bytes > MAX_BYTES) return null;
      buffer += decoder.decode(chunk.value, { stream: true });
      while (buffer) {
        if (raw) {
          const closing2 = new RegExp(`</${raw.name}(?=[\\t\\n\\f\\r />])`, "i").exec(buffer);
          const body = closing2 ? buffer.slice(0, closing2.index) : buffer;
          if (raw.candidate) {
            if (body.length > MAX_SCRIPT) return null;
            const token = bootstrapToken(body);
            if (token !== void 0) return token;
          }
          if (!closing2) break;
          const tail = buffer.slice(closing2.index), end2 = tagEnd(tail);
          if (end2 < 0) break;
          buffer = tail.slice(end2 + 1);
          raw = null;
          continue;
        }
        const start = buffer.indexOf("<");
        if (start < 0) {
          buffer = "";
          break;
        }
        buffer = buffer.slice(start);
        if ("<!--".startsWith(buffer)) break;
        if (buffer.startsWith("<!--")) {
          const end2 = buffer.indexOf("-->");
          if (end2 < 0) break;
          buffer = buffer.slice(end2 + 3);
          continue;
        }
        const end = tagEnd(buffer);
        if (end < 0) break;
        const tag = buffer.slice(0, end + 1);
        buffer = buffer.slice(end + 1);
        const parsed = /^<(\/?)([a-z][a-z0-9:-]*)(?=[\s/>])/i.exec(tag);
        if (!parsed) continue;
        const name = parsed[2].toLowerCase(), closing = parsed[1] === "/";
        if (closing) {
          if (inert.at(-1) === name) inert.pop();
          continue;
        }
        if (name === "template" || name === "svg" || name === "math") {
          inert.push(name);
          continue;
        }
        if (name === "plaintext") return null;
        if (["script", "textarea", "title", "style", "xmp", "iframe", "noembed", "noframes", "noscript"].includes(name)) {
          raw = { name, candidate: name === "script" && inert.length === 0 && executableScript(tag.slice(parsed[0].length, -1)) };
        }
      }
    }
  } finally {
    await reader.cancel().catch(() => void 0);
    reader.releaseLock();
  }
}
function validBootstrap(response) {
  return response.ok && !response.redirected && (!response.url || response.url === APP_URL);
}
function bootstrapRequest(signal) {
  return fetch(APP_URL, { method: "GET", credentials: "include", cache: "no-store", redirect: "error", signal, headers: { Accept: "text/html" } });
}
async function collectGeminiInWorker() {
  const result = (status, code = null, retryAfter2 = null) => ({ status, code, retryAfter: retryAfter2, data: null });
  const controller = new AbortController(), timer = setTimeout(() => controller.abort(), 15e3);
  try {
    const response = await bootstrapRequest(controller.signal);
    if (!response.ok) return result(response.status, null, response.headers.get("Retry-After"));
    if (!validBootstrap(response)) return result(0, "open_tab");
    const token = await readBootstrap(response);
    if (!token) return result(0, "open_tab");
    const collected = await collectGeminiInPage(token, controller.signal);
    const data = collected.data && typeof collected.data === "object" && !Array.isArray(collected.data) ? collected.data : null;
    if (!data?.plan) return collected;
    const verify = new AbortController(), verifyTimer = setTimeout(() => verify.abort(), 3e3);
    try {
      const again = await bootstrapRequest(AbortSignal.any([controller.signal, verify.signal]));
      if (validBootstrap(again) && await readBootstrap(again) === token) return collected;
    } catch {
    } finally {
      verify.abort();
      clearTimeout(verifyTimer);
    }
    return { ...collected, data: { ...data, plan: null } };
  } catch {
    return result(0, "network");
  } finally {
    controller.abort();
    clearTimeout(timer);
  }
}

// src/providers/openai-claude-transport.ts
async function collectInPage(provider, scopeSalt2 = "", mode = "page") {
  const origin = provider === "chatgpt" ? "https://chatgpt.com" : "https://claude.ai";
  if (mode === "page" && location.origin !== origin) return { status: 0, code: "open_tab", retryAfter: null, data: null };
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 15e3);
  const result = (status, code = null, wait = null, data = null) => ({ status, code, retryAfter: wait, data });
  const object = (v) => v !== null && typeof v === "object" && !Array.isArray(v) ? v : null;
  const numeric = (v) => typeof v === "number" && Number.isFinite(v) ? v : null;
  const text = (v) => typeof v === "string" && v.length <= 120 ? v : null;
  const planCode = (v) => typeof v === "string" && /^[a-z][a-z0-9_]{0,63}$/i.test(v) ? v.toLowerCase() : null;
  const count3 = (v) => typeof v === "number" && Number.isSafeInteger(v) && v >= 0 ? v : null;
  const timestamp = (v) => {
    if (typeof v !== "string" || v.length > 64) return null;
    const match = /^(\d{4})-(\d{2})-(\d{2})T(\d{2}):(\d{2}):(\d{2})(?:\.\d+)?(?:Z|[+-]\d{2}:\d{2})$/.exec(v);
    if (!match) return null;
    const [year, month, day, hour, minute, second] = match.slice(1, 7).map(Number);
    if (month < 1 || month > 12 || day < 1 || day > new Date(Date.UTC(year, month, 0)).getUTCDate() || hour > 23 || minute > 59 || second > 59) return null;
    const ms = Date.parse(v);
    return Number.isFinite(ms) && ms > 0 && ms < 41024448e5 ? new Date(ms).toISOString() : null;
  };
  const boolean = (v) => typeof v === "boolean" ? v : null;
  const identity = (v) => typeof v === "string" && v.length > 0 && v.length <= 512 ? v : null;
  const scope = async (id) => {
    if (!id || !/^[a-f0-9]{64}$/.test(scopeSalt2)) return null;
    try {
      return Array.from(new Uint8Array(await crypto.subtle.digest("SHA-256", new TextEncoder().encode(`${scopeSalt2}\0${provider}\0${id}`))), (n) => n.toString(16).padStart(2, "0")).join("");
    } catch {
      return null;
    }
  };
  const summary = (v) => {
    const r = object(v);
    return r ? { available_count: count3(r.available_count), applicable_available_count: count3(r.applicable_available_count) } : null;
  };
  const request = (path, signal, headers = {}) => fetch(
    `${origin}${path}`,
    { method: "GET", credentials: "include", cache: "no-store", redirect: "error", signal, headers: { Accept: "application/json", ...headers } }
  );
  const get = (path, headers = {}) => request(path, controller.signal, headers);
  const errorResult = (r) => result(r.status, null, r.headers.get("Retry-After"));
  const read = async (r) => {
    if (!r.headers.get("content-type")?.includes("application/json")) throw new Error("invalid_response");
    if (Number(r.headers.get("content-length")) > 1048576) throw new Error("invalid_response");
    const body = await r.text();
    if (body.length > 1048576) throw new Error("invalid_response");
    return JSON.parse(body);
  };
  const optional = async (run) => {
    const optionalController = new AbortController();
    let timer;
    const deadline = new Promise((resolve) => {
      timer = setTimeout(() => {
        optionalController.abort();
        resolve({ state: "error" });
      }, 3e3);
    });
    try {
      return await Promise.race([run(optionalController.signal).catch(() => ({ state: "error" })), deadline]);
    } finally {
      if (timer) clearTimeout(timer);
    }
  };
  const optionalFailure = (r) => ({ state: r.status === 401 || r.status === 403 ? "auth" : "error" });
  const chatRate = (value) => {
    const raw = object(value), out = {};
    for (const key2 of ["primary_window", "secondary_window"]) {
      const w = object(raw?.[key2]);
      if (w && ("used_percent" in w || "reset_at" in w)) out[key2] = { used_percent: numeric(w.used_percent), reset_at: numeric(w.reset_at), limit_window_seconds: numeric(w.limit_window_seconds) };
    }
    return out;
  };
  try {
    if (provider === "chatgpt") {
      const sessionResp = await get("/api/auth/session");
      if (!sessionResp.ok) return errorResult(sessionResp);
      const session = object(await read(sessionResp));
      if (typeof session?.accessToken !== "string" || !session.accessToken || session.accessToken.length > 16384) return result(401);
      const usageResp2 = await get("/backend-api/wham/usage", { Authorization: `Bearer ${session.accessToken}` });
      if (!usageResp2.ok) return errorResult(usageResp2);
      const raw2 = object(await read(usageResp2));
      if (!raw2) return result(200, "invalid_response");
      const account = identity(raw2.account_id) ?? identity(raw2.user_id);
      const user = identity(raw2.user_id) ?? (account?.startsWith("user-") ? account : null);
      const proof = await scope(user ? JSON.stringify([account, user]) : null), held = summary(raw2.rate_limit_reset_credits);
      let tickets2 = { state: held ? "ok" : "unavailable", scope: proof, summary: held };
      if (held && held.available_count !== null && held.available_count > 0 && account) {
        const detail = await optional(async (signal) => {
          const detailResponse = await request("/backend-api/wham/rate-limit-reset-credits", signal, { Authorization: `Bearer ${session.accessToken}` });
          if (!detailResponse.ok) return optionalFailure(detailResponse);
          const details = object(await read(detailResponse));
          if (!details || !Array.isArray(details.credits) || details.credits.length > 100) return { state: "error" };
          const againResponse = await request("/backend-api/wham/usage", signal, { Authorization: `Bearer ${session.accessToken}` });
          if (!againResponse.ok) return optionalFailure(againResponse);
          const again = object(await read(againResponse));
          if (!again) return { state: "error" };
          const againAccount = identity(again.account_id) ?? identity(again.user_id);
          const againUser = identity(again.user_id) ?? (againAccount?.startsWith("user-") ? againAccount : null);
          if (againAccount !== account || againUser !== user) return { state: "context_changed", scope: null };
          const current = summary(again.rate_limit_reset_credits);
          if (!current || current.available_count !== held.available_count || count3(details.available_count) !== current.available_count || details.credits.length < current.available_count) return { state: "error", summary: current };
          return { state: "ok", summary: current, detail: {
            available_count: count3(details.available_count),
            credits: details.credits.map((value) => {
              const c = object(value);
              return c ? {
                reset_type: typeof c.reset_type === "string" ? ["codex_rate_limits", "codex_five_hour", "codex_weekly"].includes(c.reset_type) ? c.reset_type : "unknown" : null,
                status: typeof c.status === "string" ? c.status === "available" ? "available" : "other" : null,
                is_supported_by_plan: boolean(c.is_supported_by_plan),
                granted_at: c.granted_at == null ? null : timestamp(c.granted_at) ?? "invalid",
                expires_at: timestamp(c.expires_at)
              } : null;
            })
          } };
        });
        tickets2 = { ...tickets2, ...detail };
      }
      const additional = Array.isArray(raw2.additional_rate_limits) ? raw2.additional_rate_limits.slice(0, 50).map((v) => {
        const r = object(v);
        return { limit_name: text(r?.limit_name), metered_feature: text(r?.metered_feature), rate_limit: chatRate(r?.rate_limit) };
      }) : [];
      return result(200, null, null, { reset_tickets: tickets2, plan_type: planCode(raw2.plan_type), rate_limit: chatRate(raw2.rate_limit), additional_rate_limits: additional });
    }
    const orgResp = await get("/api/organizations");
    if (!orgResp.ok) return errorResult(orgResp);
    const orgs = await read(orgResp);
    if (!Array.isArray(orgs)) return result(200, "invalid_response");
    if (!orgs.length) return result(200, "invalid_response");
    if (orgs.length !== 1) return result(200, "ambiguous_account");
    const org = object(orgs[0]), uuid = org?.uuid;
    if (typeof uuid !== "string" || !/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(uuid)) return result(200, "invalid_response");
    const usagePath = `/api/organizations/${uuid}/usage`;
    let featureFailed = false, usageResp, usageData;
    const queried = await optional(async (signal) => {
      const response = await request(`${usagePath}?cedar_ember=1`, signal);
      return { response, ...response.ok ? { data: await read(response) } : {} };
    });
    if (queried.response instanceof Response && (queried.response.ok || ![400, 403, 404, 422].includes(queried.response.status) && queried.response.status < 500)) {
      usageResp = queried.response;
      if (!usageResp.ok) return errorResult(usageResp);
      usageData = queried.data;
    } else {
      featureFailed = true;
      usageResp = await get(usagePath);
      if (!usageResp.ok) return errorResult(usageResp);
      usageData = await read(usageResp);
    }
    const raw = object(usageData), out = {};
    if (!raw) return result(200, "invalid_response");
    for (const [key2, value] of Object.entries(raw).slice(0, 100)) {
      if (!/^(five_hour|seven_day(?:_[a-z0-9_]+)?)$/.test(key2)) continue;
      const w = object(value);
      if (w && ("utilization" in w || "resets_at" in w)) out[key2] = { utilization: numeric(w.utilization), resets_at: text(w.resets_at) };
    }
    out.limits = Array.isArray(raw.limits) ? raw.limits.slice(0, 50).map((v) => {
      const w = object(v);
      return {
        kind: text(w?.kind),
        percent: numeric(w?.percent),
        resets_at: text(w?.resets_at),
        scope: { model: { display_name: text(object(object(w?.scope)?.model)?.display_name) } }
      };
    }) : [];
    out.plan_metadata = {
      capabilities: Array.isArray(org?.capabilities) ? org.capabilities.slice(0, 100).filter((v) => ["chat", "claude_pro", "claude_max", "pro", "free", "raven", "raven_enterprise"].includes(v)) : [],
      rate_limit_tier: planCode(org?.rate_limit_tier),
      raven_type: org?.raven_type === "team" || org?.raven_type === "enterprise" ? org.raven_type : null
    };
    const cedar = object(raw.cedar_ember);
    let tickets = { state: featureFailed ? "error" : "unavailable", scope: null };
    if (cedar) {
      const detail = await optional(async (signal) => {
        const againResponse = await request("/api/organizations", signal);
        if (!againResponse.ok) return optionalFailure(againResponse);
        const again = await read(againResponse);
        if (!Array.isArray(again) || again.length !== 1 || object(again[0])?.uuid !== uuid) return { state: "context_changed", scope: null };
        if (cedar.eligible !== true) return { state: "unavailable" };
        if (!Array.isArray(cedar.grants) || cedar.grants.length > 100) return { state: "error" };
        const next = identity(cedar.next_grant_id);
        return { state: "ok", detail: {
          eligible: true,
          cooldown_until: cedar.cooldown_until == null ? null : timestamp(cedar.cooldown_until) ?? "invalid",
          grants: cedar.grants.map((value) => {
            const g = object(value);
            if (!g) return null;
            return {
              resets_left: count3(g.resets_left),
              starts_at: g.starts_at == null ? null : timestamp(g.starts_at) ?? "invalid",
              // Missing/invalid expiry remains invalid; only an explicit null has the site's no-grant meaning.
              ends_at: g.ends_at === null ? null : timestamp(g.ends_at) ?? "invalid",
              clears: Array.isArray(g.clears) && g.clears.length <= 64 && g.clears.every((v) => typeof v === "string") ? g.clears.map((v) => /^(five_hour|seven_day(?:_[a-z0-9_]+)?)$/.test(v) && v.length <= 64 ? v : "unknown") : null,
              usable_now: boolean(g.usable_now),
              use_requires_limit: boolean(g.use_requires_limit),
              blocked: Array.isArray(g.blocking) ? g.blocking.length > 0 : null,
              selected: next === null ? null : identity(g.id) === next
            };
          })
        } };
      });
      tickets = { ...tickets, ...detail };
    }
    out.reset_tickets = tickets;
    return result(200, null, null, out);
  } catch (e) {
    return result(0, e instanceof Error && e.message === "invalid_response" ? "invalid_response" : "network");
  } finally {
    clearTimeout(timeout);
  }
}

// src/providers/tab-transport.ts
function unwrapTransport(value) {
  const r = record(value);
  if (!r || typeof r.status !== "number" || !Number.isInteger(r.status) || r.status < 0 || r.status > 599) throw new CollectionError("invalid_response");
  if (r.code !== null) {
    const geminiError = GEMINI_RESPONSE_ERRORS.find((code) => code === r.code);
    if (geminiError) throw new CollectionError(geminiError);
    if (r.code === "unsupported") throw new CollectionError("unsupported", "unsupported");
    if (r.code === "network" || r.code === "invalid_response" || r.code === "open_tab" || r.code === "ambiguous_account") throw new CollectionError(r.code);
    throw new CollectionError("invalid_response");
  }
  if (r.status !== 200) throw httpError(r.status, retryAfter(typeof r.retryAfter === "string" && r.retryAfter.length <= 100 ? r.retryAfter : null));
  return r.data;
}
async function collectionTab(provider) {
  const tabs = await chrome.tabs.query({ url: ORIGINS[provider] });
  const eligible = tabs.filter((tab) => !tab.discarded && !tab.frozen && typeof tab.id === "number");
  if (tabs.length && !eligible.length) throw new CollectionError("open_tab");
  if (eligible.length <= 1) return eligible[0];
  const focused = await chrome.tabs.query({ url: ORIGINS[provider], active: true, lastFocusedWindow: true });
  return eligible.find((tab) => focused.some((candidate) => candidate.id === tab.id && candidate.active)) ?? eligible.sort((a, b) => Number(b.active) - Number(a.active))[0];
}
async function collectFromTab(provider) {
  if (!await chrome.permissions.contains({ origins: [ORIGINS[provider]] })) throw new CollectionError("permission_required", "permission_required");
  const tab = await collectionTab(provider);
  if (typeof tab?.id !== "number") {
    return unwrapTransport(provider === "gemini" ? await collectGeminiInWorker() : await collectInPage(provider, ticketScopeSalt(), "worker"));
  }
  let results;
  try {
    results = provider === "gemini" ? await chrome.scripting.executeScript({ target: { tabId: tab.id }, world: "MAIN", func: collectGeminiInPage }) : await chrome.scripting.executeScript({ target: { tabId: tab.id }, world: "MAIN", func: collectInPage, args: [provider, ticketScopeSalt()] });
  } catch {
    throw new CollectionError("tab_access_failed");
  }
  return unwrapTransport(results[0]?.result);
}
var scopeSalt;
function ticketScopeSalt() {
  try {
    return scopeSalt ??= Array.from(crypto.getRandomValues(new Uint8Array(32)), (n) => n.toString(16).padStart(2, "0")).join("");
  } catch {
    return "";
  }
}

// src/providers/parsers.ts
var InvalidResponse = class extends Error {
  constructor() {
    super("invalid_response");
  }
};
var item = (id, name, category, value, reset, span) => ({ id, label: name, category, percent: percent(value), resetsAt: reset, windowSeconds: span, remaining: null, unit: null, source: "api" });
function parseClaude(input) {
  const data = record(input);
  if (!data) throw new InvalidResponse();
  const items = [];
  for (const [key2, raw] of Object.entries(data).slice(0, 100)) {
    if (!/^(five_hour|seven_day(?:_[a-z0-9_]+)?)$/.test(key2)) continue;
    const w = record(raw);
    if (!w || !("utilization" in w) && !("resets_at" in w)) continue;
    const name = key2 === "five_hour" ? "5\uC2DC\uAC04" : key2 === "seven_day" ? "7\uC77C" : `7\uC77C \xB7 ${key2.slice(10)}`;
    items.push(item(key2, name, key2 === "five_hour" || key2 === "seven_day" ? "window" : "model", w.utilization, resetTime(w.resets_at), key2 === "five_hour" ? 18e3 : 604800));
  }
  if (Array.isArray(data.limits)) {
    for (const raw of data.limits.slice(0, 50)) {
      const w = record(raw), model = record(record(w?.scope)?.model);
      const modelName = label(model?.display_name);
      if (w?.kind !== "weekly_scoped" || !modelName || modelName.length > 100) continue;
      const id = `weekly_scoped:${modelName}`;
      if (items.some((v) => v.id === id)) continue;
      items.push(item(id, `7\uC77C \xB7 ${modelName}`, "model", w.percent, resetTime(w.resets_at), 604800));
    }
  }
  if (!items.length) throw new InvalidResponse();
  return items;
}
function chatWindows(raw, prefix, title, category) {
  const rate = record(raw);
  if (!rate) return [];
  const result = [];
  for (const key2 of ["primary_window", "secondary_window"]) {
    const w = record(rate[key2]);
    if (!w || !("used_percent" in w || "reset_at" in w)) continue;
    const span = nonnegative(w.limit_window_seconds);
    const windowLabel = span === 18e3 ? "5\uC2DC\uAC04" : span === 604800 ? "7\uC77C" : span ? `${span / 3600}\uC2DC\uAC04` : key2 === "primary_window" ? "\uAE30\uBCF8 \uC81C\uD55C" : "\uCD94\uAC00 \uC81C\uD55C";
    result.push(item(`${prefix}:${key2}`, `${title} \xB7 ${windowLabel}`, category, w.used_percent, unixReset(w.reset_at), span));
  }
  return result;
}
function parseChatGPT(input) {
  const data = record(input);
  if (!data) throw new InvalidResponse();
  const items = chatWindows(data.rate_limit, "shared", "ChatGPT", "product");
  if (Array.isArray(data.additional_rate_limits)) {
    for (const raw of data.additional_rate_limits.slice(0, 50)) {
      const bucket = record(raw);
      const name = label(bucket?.limit_name) ?? label(bucket?.metered_feature);
      if (!name || name.length > 100) continue;
      for (const limit of chatWindows(bucket?.rate_limit, `product:${name}`, name, "product")) if (!items.some((i) => i.id === limit.id)) items.push(limit);
    }
  }
  if (!items.length) throw new InvalidResponse();
  return items;
}

// src/providers/openai-claude-plan.ts
var openAIPlans = /* @__PURE__ */ new Map([
  ["free", "Free"],
  ["go", "Go"],
  ["plus", "Plus"],
  ["prolite", "Pro 100"],
  ["pro", "Pro 200"],
  ["promax", "Pro 500"],
  ["team", "Team"],
  ["business", "Business"],
  ["enterprise", "Enterprise"],
  ["education", "Education"],
  ["k12", "Education (K-12)"]
]);
var claudeTiers = /* @__PURE__ */ new Map([
  ["default_claude_max_5x", "Max 5x"],
  ["default_claude_max_20x", "Max 20x"],
  ["claude_max", "Max"],
  ["claude_pro", "Pro"],
  ["claude_team", "Team"],
  ["claude_enterprise", "Enterprise"]
]);
function identifier(value) {
  return typeof value === "string" && /^[a-z][a-z0-9_]{0,63}$/i.test(value) ? value.toLowerCase() : null;
}
function parseChatGPTPlan(input) {
  return openAIPlans.get(identifier(record(input)?.plan_type) ?? "") ?? null;
}
function parseClaudePlan(input) {
  const metadata = record(record(input)?.plan_metadata);
  if (!metadata) return null;
  const capabilities = Array.isArray(metadata.capabilities) ? metadata.capabilities.slice(0, 100) : [];
  const tier = claudeTiers.get(identifier(metadata.rate_limit_tier) ?? "");
  if (metadata.raven_type === "enterprise" || capabilities.includes("raven_enterprise") || tier === "Enterprise") return "Enterprise";
  if (metadata.raven_type === "team" || capabilities.includes("raven") || tier === "Team") return "Team";
  if (capabilities.includes("claude_max")) return tier === "Max 5x" || tier === "Max 20x" ? tier : "Max";
  if (tier) return tier;
  if (capabilities.includes("claude_pro") || capabilities.includes("pro")) return "Pro";
  if (capabilities.includes("free")) return "Free";
  return null;
}

// src/providers/reset-tickets.ts
var count2 = (v) => typeof v === "number" && Number.isSafeInteger(v) && v >= 0;
var date2 = (v) => typeof v === "string" && v.length <= 64 ? resetTime(v) : null;
var bool = (v) => typeof v === "boolean" ? v : null;
var emptyGrant = (kind, amount) => ({
  kind,
  count: amount,
  startsAt: null,
  expiresAt: null,
  usableNow: null,
  clears: [],
  requiresLimit: null,
  blocked: null,
  selected: null
});
function parseChatGPTTicketSummary(value) {
  const raw = record(value);
  if (!raw || !count2(raw.available_count)) return null;
  return {
    mode: "summary",
    grants: raw.available_count ? [emptyGrant("unspecified", raw.available_count)] : [],
    usableCount: count2(raw.applicable_available_count) && raw.applicable_available_count <= raw.available_count ? raw.applicable_available_count : null,
    cooldownUntil: null
  };
}
function parseChatGPTTicketDetail(value, summary, now = Date.now()) {
  const raw = record(value), held = summary.grants.reduce((sum, g) => sum + g.count, 0);
  if (!raw || !Array.isArray(raw.credits) || raw.credits.length > 100 || raw.available_count !== held || raw.credits.length < held) return null;
  const grants = [];
  for (const item2 of raw.credits) {
    const credit = record(item2);
    if (!credit || typeof credit.reset_type !== "string" || typeof credit.status !== "string" || !date2(credit.expires_at) || credit.granted_at != null && !date2(credit.granted_at)) return null;
    if (credit.status !== "available" || credit.is_supported_by_plan === false) continue;
    const expiresAt = date2(credit.expires_at);
    if (Date.parse(expiresAt) <= now) continue;
    const kind = credit.reset_type === "codex_rate_limits" ? "full" : credit.reset_type === "codex_five_hour" ? "five_hour" : credit.reset_type === "codex_weekly" ? "weekly" : null;
    if (!kind) continue;
    grants.push({
      ...emptyGrant(kind, 1),
      startsAt: date2(credit.granted_at),
      expiresAt,
      clears: kind === "full" ? ["five_hour", "seven_day"] : [kind === "weekly" ? "seven_day" : "five_hour"]
    });
  }
  return { mode: "detail", grants, usableCount: grants.length === held ? summary.usableCount : null, cooldownUntil: null };
}
function parseClaudeTickets(value, now = Date.now()) {
  const raw = record(value);
  if (!raw || raw.eligible !== true || !Array.isArray(raw.grants) || raw.grants.length > 100 || raw.cooldown_until != null && !date2(raw.cooldown_until)) return null;
  const grants = [];
  for (const item2 of raw.grants) {
    const grant = record(item2);
    if (!grant || !count2(grant.resets_left) || grant.ends_at !== null && !date2(grant.ends_at) || grant.starts_at != null && !date2(grant.starts_at)) return null;
    if (grant.resets_left === 0 || grant.ends_at === null) continue;
    const expiresAt = date2(grant.ends_at);
    if (Date.parse(expiresAt) <= now) continue;
    if (!Array.isArray(grant.clears) || grant.clears.length > 64 || !grant.clears.every((c) => typeof c === "string" && /^[a-z0-9_]{1,64}$/.test(c))) return null;
    const clears = grant.clears.filter((c) => c === "five_hour" || /^seven_day(?:_[a-z0-9_]+)?$/.test(c));
    const five = clears.includes("five_hour"), weekly = clears.includes("seven_day");
    const kind = five && weekly ? "full" : !five && weekly ? "weekly" : five && !clears.some((c) => c.startsWith("seven_day")) ? "five_hour" : null;
    if (!kind) continue;
    grants.push({
      ...emptyGrant(kind, grant.resets_left),
      startsAt: date2(grant.starts_at),
      expiresAt,
      usableNow: bool(grant.usable_now),
      clears,
      requiresLimit: bool(grant.use_requires_limit),
      blocked: Array.isArray(grant.blocking) ? grant.blocking.length > 0 : bool(grant.blocked),
      // The MAIN transport compares grant IDs and then discards them.
      selected: bool(grant.selected)
    });
  }
  return { mode: "detail", grants, usableCount: null, cooldownUntil: date2(raw.cooldown_until) };
}
function parseCollectedTickets(provider, response, now = Date.now()) {
  const envelope = record(record(response)?.reset_tickets);
  if (!envelope) return void 0;
  const scope = typeof envelope.scope === "string" && /^[a-f0-9]{64}$/.test(envelope.scope) ? envelope.scope : null;
  if (envelope.state === "auth" || envelope.state === "context_changed" || envelope.state === "unavailable") return { state: envelope.state, scope };
  const summary = provider === "chatgpt" ? parseChatGPTTicketSummary(envelope.summary) : null;
  if (envelope.state === "error") return { state: "error", scope, ...summary ? { fallback: summary } : {} };
  if (envelope.state !== "ok") return { state: "error", scope };
  if (provider === "claude") {
    const inventory2 = parseClaudeTickets(envelope.detail, now);
    return inventory2 ? { state: "ok", inventory: inventory2, scope } : { state: "error", scope };
  }
  if (!summary) return { state: "error", scope };
  if (envelope.detail === void 0 || envelope.detail === null) return { state: "ok", inventory: summary, scope };
  const inventory = parseChatGPTTicketDetail(envelope.detail, summary, now);
  return inventory ? { state: "ok", inventory, scope } : { state: "error", scope, fallback: summary };
}

// src/providers/chatgpt.ts
async function collectChatGPT() {
  const response = await collectFromTab("chatgpt");
  const tickets = parseCollectedTickets("chatgpt", response);
  return { limits: parseChatGPT(response), plan: parseChatGPTPlan(response), ...tickets ? { tickets } : {} };
}

// src/providers/gemini-parser.ts
function parseGemini(input) {
  if (!Array.isArray(input) || !Array.isArray(input[1]) || input[1].length > 20) throw new InvalidResponse();
  const limits = [], seen = /* @__PURE__ */ new Set();
  for (const row of input[1]) {
    if (!Array.isArray(row) || !Number.isInteger(row[2])) throw new InvalidResponse();
    const type = row[2];
    if (type !== 1 && type !== 2) continue;
    if (seen.has(type)) throw new InvalidResponse();
    seen.add(type);
    const ratio = row[1];
    if (ratio != null && (typeof ratio !== "number" || !Number.isFinite(ratio) || ratio < 0 || ratio > 1)) throw new InvalidResponse();
    let resetsAt = null;
    const reset = row[3];
    if (reset != null) {
      if (!Array.isArray(reset) || reset.length !== 1 || !Array.isArray(reset[0])) throw new InvalidResponse();
      const stamp = reset[0];
      const seconds = stamp[0], nanos = stamp.length === 1 ? 0 : stamp[1];
      if (stamp.length < 1 || stamp.length > 2 || typeof seconds !== "number" || !Number.isSafeInteger(seconds) || seconds <= 0 || seconds >= 4102444800 || typeof nanos !== "number" || !Number.isInteger(nanos) || nanos < 0 || nanos >= 1e9) throw new InvalidResponse();
      resetsAt = new Date(seconds * 1e3 + Math.floor(nanos / 1e6)).toISOString();
    }
    limits.push({
      id: type === 1 ? "five_hour" : "seven_day",
      label: type === 1 ? "5\uC2DC\uAC04" : "7\uC77C",
      category: "window",
      percent: ratio == null ? null : ratio * 100,
      resetsAt,
      windowSeconds: type === 1 ? 18e3 : 604800,
      remaining: null,
      unit: null,
      source: "api"
    });
  }
  if (!limits.length) throw new InvalidResponse();
  return limits;
}

// src/providers/gemini-plan.ts
var POLICY_LABELS = {
  v3p2_free_policy: "Free",
  v3p2_basic_policy: "Free",
  v3p2_plus_policy: "AI Plus",
  v3p2_pro_policy: "AI Pro",
  v3p2_ultra_policy: "AI Ultra",
  v3p2_business_policy: "Workspace",
  basic_policy: "Free",
  brownfield_basic_policy: "Free",
  brownfield_paid_policy: "AI Plus",
  plus_policy: "AI Pro",
  neon_policy: "AI Ultra"
};
var GEMINI_POLICY_IDS = Object.keys(POLICY_LABELS);
function parseGeminiPlan(input) {
  if (!input || typeof input !== "object" || Array.isArray(input)) return null;
  const policies = input.policies;
  if (!Array.isArray(policies) || policies.length > 20) return null;
  const labels = /* @__PURE__ */ new Set();
  for (const policy of policies) {
    if (typeof policy !== "string" || policy.length > 80) return null;
    if (Object.hasOwn(POLICY_LABELS, policy)) labels.add(POLICY_LABELS[policy]);
  }
  return labels.size === 1 ? [...labels][0] : null;
}

// src/providers/gemini.ts
async function collectGemini() {
  const response = record(await collectFromTab("gemini"));
  return { limits: parseGemini(response?.usage), plan: parseGeminiPlan(response?.plan) };
}

// src/providers/claude.ts
async function collectClaude() {
  const response = await collectFromTab("claude");
  const tickets = parseCollectedTickets("claude", response);
  return { limits: parseClaude(response), plan: parseClaudePlan(response), ...tickets ? { tickets } : {} };
}

// src/providers/index.ts
var collect = (p) => ({ chatgpt: collectChatGPT, claude: collectClaude, gemini: collectGemini })[p]();

// src/background/scheduler.ts
function backoff(failures) {
  return Math.min(60 * 6e4, 6e4 * 2 ** Math.min(6, Math.max(0, failures - 1)));
}
function due(s, trigger, now) {
  if (s.state === "error" && s.errorCode === "open_tab" && trigger === "tab") return true;
  if (now < s.nextAttemptAt) return false;
  if (s.checkedAt !== null && now - s.checkedAt < 6e4) return false;
  if (trigger !== "manual" && ["signed_out", "permission_required", "unsupported"].includes(s.state)) return false;
  return trigger === "manual" || s.collectedAt === null || s.state !== "ok" || s.planRefreshPending === true || hasElapsedReset(s, now) || s.collectedAt > now + 6e4 || now - s.collectedAt >= (trigger === "periodic" ? FRESH_MS : 6e4);
}
function success(previous, limits, now, plan = null) {
  const label2 = knownPlanLabel(previous.provider, plan);
  const { usageInvalidated: _usageInvalidated, ...retained } = previous;
  return {
    ...retained,
    limits,
    state: "ok",
    collectedAt: now,
    checkedAt: now,
    failures: 0,
    nextAttemptAt: now + 6e4,
    errorCode: null,
    plan: label2 ? { label: label2, checkedAt: now } : null,
    planRefreshPending: false
  };
}
function failure(previous, error, now) {
  previous = { ...previous, plan: null, planRefreshPending: false };
  const e = error instanceof CollectionError ? error : new CollectionError("invalid_response");
  const invalidatesUsage = (code) => code !== null && ["signed_out", "access_denied", "permission_required", "ambiguous_account", "unsupported"].includes(code);
  if (invalidatesUsage(e.code) || invalidatesUsage(previous.errorCode) || ["signed_out", "permission_required", "unsupported"].includes(previous.state)) previous = { ...previous, usageInvalidated: true };
  if (Object.hasOwn(previous, "tickets")) previous = {
    ...previous,
    tickets: ["signed_out", "access_denied", "permission_required", "ambiguous_account", "unsupported"].includes(e.code) ? null : previous.tickets ?? null,
    ticketRefreshPending: true
  };
  if (e.code === "open_tab") return { ...previous, state: "error", checkedAt: now, nextAttemptAt: now + 6e4, failures: 0, errorCode: e.code };
  const failures = previous.failures + 1;
  return { ...previous, state: e.state, checkedAt: now, failures, nextAttemptAt: now + Math.max(backoff(failures), e.retryAfterMs), errorCode: e.code };
}
var Scheduler = class {
  constructor(io) {
    this.io = io;
  }
  io;
  flights = /* @__PURE__ */ new Map();
  writes = /* @__PURE__ */ new Map();
  planEpoch = /* @__PURE__ */ new Map();
  ticketEpoch = /* @__PURE__ */ new Map();
  ticketScopes = /* @__PURE__ */ new Map();
  update(p, change, updateTrust = false) {
    const task = (this.writes.get(p) ?? Promise.resolve()).catch(() => void 0).then(async () => {
      const after = change(await this.io.read(p));
      if (updateTrust) await this.io.writeTicketTrust?.(p, false).catch(() => void 0);
      await this.io.write(after);
      if (updateTrust && after.tickets && !after.ticketRefreshPending && after.tickets.failures < 2)
        await this.io.writeTicketTrust?.(p, true).catch(() => void 0);
    });
    this.writes.set(p, task);
    return task.finally(() => {
      if (this.writes.get(p) === task) this.writes.delete(p);
    });
  }
  invalidatePlan(p) {
    this.planEpoch.set(p, (this.planEpoch.get(p) ?? 0) + 1);
    this.ticketEpoch.set(p, (this.ticketEpoch.get(p) ?? 0) + 1);
    this.ticketScopes.delete(p);
    return this.update(p, (current) => ({
      ...current,
      plan: null,
      planRefreshPending: true,
      ...Object.hasOwn(current, "tickets") ? { tickets: null, ticketRefreshPending: true } : {}
    }), true);
  }
  invalidateTickets(p, preserveCache = false) {
    this.ticketEpoch.set(p, (this.ticketEpoch.get(p) ?? 0) + 1);
    this.ticketScopes.delete(p);
    return this.update(p, (current) => Object.hasOwn(current, "tickets") ? { ...current, tickets: preserveCache ? current.tickets ?? null : null, ticketRefreshPending: true } : current, true);
  }
  async prepareTickets() {
    await Promise.all(["chatgpt", "claude"].map(async (p) => {
      if (await this.io.readTicketTrust?.(p).catch(() => false)) return;
      await this.invalidateTickets(p, true);
    }));
  }
  tickets(previous, after, result, now) {
    if (after.provider === "gemini" || !result) {
      if (Object.hasOwn(previous, "tickets")) return { ...after, tickets: null, ticketRefreshPending: false };
      return after;
    }
    const p = after.provider;
    const scope = typeof result.scope === "string" && /^[a-f0-9]{64}$/.test(result.scope) ? result.scope : null;
    const remembered = this.ticketScopes.get(p);
    const same = scope !== null && scope === remembered;
    const changed = remembered !== void 0 && scope !== remembered;
    const old = same && !previous.ticketRefreshPending ? parseTicketCache(previous.tickets) : null;
    const inventory = result.state === "ok" ? parseTicketInventory(result.inventory) : null;
    if (inventory) {
      if (scope) this.ticketScopes.set(p, scope);
      else this.ticketScopes.delete(p);
      return { ...after, tickets: { inventory, checkedAt: now, failures: 0 }, ticketRefreshPending: false };
    }
    if (result.state === "error" || result.state === "ok") {
      const reported = parseTicketInventory(result.fallback);
      const reportedCount = reported?.mode === "summary" ? reported.grants.reduce((sum, grant) => sum + grant.count, 0) : null;
      if (reported?.mode === "summary" && reportedCount === 0) {
        if (scope) this.ticketScopes.set(p, scope);
        else this.ticketScopes.delete(p);
        return { ...after, tickets: { inventory: reported, checkedAt: now, failures: 0 }, ticketRefreshPending: false };
      }
      if (old) {
        const cachedCount = old.inventory.grants.filter((grant) => grant.expiresAt === null || Date.parse(grant.expiresAt) > now).reduce((sum, grant) => sum + grant.count, 0);
        if (reportedCount === null || reportedCount === cachedCount)
          return { ...after, tickets: { ...old, failures: old.failures + 1 }, ticketRefreshPending: false };
      }
      const fallback = !changed && previous.tickets?.inventory.mode !== "detail" ? reported : null;
      if (fallback?.mode === "summary") {
        if (scope) this.ticketScopes.set(p, scope);
        else this.ticketScopes.delete(p);
        return { ...after, tickets: { inventory: fallback, checkedAt: now, failures: 0 }, ticketRefreshPending: false };
      }
    }
    this.ticketScopes.delete(p);
    return { ...after, tickets: null, ticketRefreshPending: false };
  }
  refresh(p, trigger) {
    const active = this.flights.get(p);
    if (active) return active;
    const task = this.run(p, trigger).finally(() => this.flights.delete(p));
    this.flights.set(p, task);
    return task;
  }
  async run(p, trigger) {
    const epoch = this.planEpoch.get(p) ?? 0;
    const ticketEpoch = this.ticketEpoch.get(p) ?? 0;
    const before = await this.io.read(p);
    if (!await this.io.enabled(p) || !due(before, trigger, this.io.now())) return before;
    await this.update(p, (current) => ({ ...current, checkedAt: this.io.now(), nextAttemptAt: this.io.now() + 6e4, errorCode: before.errorCode === "open_tab" ? "not_collected" : before.errorCode }));
    let after;
    try {
      const result = await this.io.collect(p), now = this.io.now();
      if (!result || !validLimits(result.limits) || !result.limits.length) throw new CollectionError("invalid_response");
      after = success(before, result.limits, now, result.plan);
      after = this.tickets(before, after, result.tickets, now);
    } catch (e) {
      this.ticketScopes.delete(p);
      after = failure(before, e, this.io.now());
    }
    if (!await this.io.enabled(p)) return before;
    await this.update(p, () => {
      if (epoch !== (this.planEpoch.get(p) ?? 0)) after = { ...after, plan: null, planRefreshPending: true };
      if (ticketEpoch !== (this.ticketEpoch.get(p) ?? 0) && Object.hasOwn(after, "tickets")) {
        this.ticketScopes.delete(p);
        after = { ...after, tickets: null, ticketRefreshPending: true };
      }
      return after;
    }, Object.hasOwn(after, "tickets"));
    return after;
  }
};

// src/shared/usage-selection.ts
function highestUsageLimit(limits) {
  let highest = null;
  let highestPercent = -1;
  for (const limit of limits) {
    const used = percent(limit.percent);
    if (used !== null && used > highestPercent) {
      highest = limit;
      highestPercent = used;
    }
  }
  return highest;
}

// src/background/badge.ts
var SERVICE_COLORS = { chatgpt: "#0D8669", claude: "#B16046", gemini: "#3569C8" };
var EMPTY = { text: "", color: "#697386", textColor: "#FFFFFF", title: "AI Gauge" };
function badge(view, activeUrl, now = Date.now()) {
  setLanguagePreference(view.settings.language);
  const page = providerFromUrl(activeUrl);
  if (!page) return EMPTY;
  const p = displayProvider(page);
  const s = effectiveSnapshot(view.snapshots[p], now), limit = highestUsageLimit(s.limits);
  if (!view.settings.enabled[p] || !view.permissions[p] || s.state !== "ok" || !limit || limit.percent === null) {
    const reason = !view.settings.enabled[p] ? t("badge_disabled") : !view.permissions[p] ? t("badge_permission_required") : s.state !== "ok" ? statusText(s) : t("badge_usage_unknown");
    return { text: "\u2014", color: "#697386", textColor: "#FFFFFF", title: `AI Gauge \xB7 ${NAMES[p]} \xB7 ${reason}` };
  }
  return { text: `${Math.round(limit.percent)}%`, color: SERVICE_COLORS[p], textColor: "#FFFFFF", title: `AI Gauge \xB7 ${NAMES[p]} \xB7 ${usageText(limit)}` };
}
var written = /* @__PURE__ */ new Map();
var globalCleared = false;
async function writeTab(view, id) {
  let tab;
  try {
    tab = await chrome.tabs.get(id);
  } catch {
    written.delete(id);
    return;
  }
  const value = badge(view, tab.url), key2 = JSON.stringify(value);
  if (written.get(id) === key2) return;
  const results = await Promise.allSettled([
    chrome.action.setBadgeText({ tabId: id, text: value.text }),
    chrome.action.setBadgeBackgroundColor({ tabId: id, color: value.color }),
    chrome.action.setBadgeTextColor({ tabId: id, color: value.textColor }),
    chrome.action.setTitle({ tabId: id, title: value.title })
  ]);
  if (results.every((result) => result.status === "fulfilled")) written.set(id, key2);
  else written.delete(id);
}
async function renderBadges(view, only) {
  if (!globalCleared) {
    await Promise.allSettled([
      chrome.action.setBadgeText({ text: "" }),
      chrome.action.setBadgeBackgroundColor({ color: EMPTY.color }),
      chrome.action.setBadgeTextColor({ color: EMPTY.textColor }),
      chrome.action.setTitle({ title: EMPTY.title })
    ]);
    globalCleared = true;
  }
  let ids;
  if (only) ids = [...only];
  else {
    try {
      ids = (await chrome.tabs.query({})).flatMap((tab) => typeof tab.id === "number" ? [tab.id] : []);
    } catch {
      return;
    }
    const open = new Set(ids);
    for (const id of written.keys()) if (!open.has(id)) written.delete(id);
  }
  await Promise.all(ids.map((id) => writeTab(view, id)));
}
var pending = null;
var badgeFlight = null;
async function flushBadges() {
  try {
    while (pending) {
      const { view, only } = pending;
      pending = null;
      await renderBadges(view, only);
    }
  } finally {
    badgeFlight = null;
  }
}
function updateBadge(view, tabIds) {
  const only = tabIds ? new Set(tabIds) : null;
  const merged = !pending ? only : !pending.only || !only ? null : /* @__PURE__ */ new Set([...pending.only, ...only]);
  pending = { view, only: merged };
  badgeFlight ??= flushBadges();
  return badgeFlight;
}

// src/background/content-registration.ts
async function reconcileContent(view) {
  const existing = await chrome.scripting.getRegisteredContentScripts();
  const currentIds = new Set(SITE_GROUPS.map((site) => `ai-gauge-${site.id}`));
  const observerId = "ai-gauge-chatgpt-observer";
  const retired = existing.filter((s) => s.id.startsWith("ai-gauge-") && !currentIds.has(s.id)).map((s) => s.id);
  if (retired.length) await chrome.scripting.unregisterContentScripts({ ids: retired });
  const observing = existing.some((s) => s.id === observerId);
  if (view.permissions.chatgpt && observing) {
    const tabs = await chrome.tabs.query({ url: "https://chatgpt.com/*" });
    await Promise.all(tabs.filter((t2) => typeof t2.id === "number" && !t2.discarded && !t2.frozen).map((t2) => chrome.scripting.executeScript({ target: { tabId: t2.id }, world: "MAIN", func: () => {
      document.dispatchEvent(new Event("ai-gauge-chatgpt-stop"));
    } }).catch(() => void 0)));
  }
  for (const site of SITE_GROUPS) {
    const id = `ai-gauge-${site.id}`, present = existing.some((s) => s.id === id);
    const enabled = needsContent(view, site.providers);
    if (!enabled && present) await chrome.scripting.unregisterContentScripts({ ids: [id] });
    if (enabled && !present) await chrome.scripting.registerContentScripts([{ id, matches: [site.origin], js: ["content.js"], runAt: "document_start", persistAcrossSessions: true }]);
    if (enabled && present && existing.find((s) => s.id === id)?.runAt === "document_idle") await chrome.scripting.updateContentScripts([{ id, js: ["content.js"], runAt: "document_start" }]);
    if (enabled) {
      const tabs = await chrome.tabs.query({ url: site.origin });
      const live = tabs.filter((t2) => typeof t2.id === "number" && !t2.discarded && !t2.frozen);
      await Promise.all(live.map((t2) => chrome.scripting.executeScript({ target: { tabId: t2.id }, files: ["content.js"] }).catch(() => void 0)));
    }
  }
}

// src/storage/ticket-trust.ts
var key = (provider) => `ticket-trust:v1:${provider}`;
async function readTicketTrust(provider) {
  try {
    const storage = chrome.storage.session;
    return !!storage && (await storage.get(key(provider)))[key(provider)] === true;
  } catch {
    return false;
  }
}
async function writeTicketTrust(provider, trusted) {
  try {
    await chrome.storage.session?.set({ [key(provider)]: trusted });
  } catch {
  }
}

// src/background/index.ts
var scheduler = new Scheduler({
  read: readSnapshot,
  write: writeSnapshot,
  collect,
  readTicketTrust,
  writeTicketTrust,
  now: Date.now,
  enabled: async (p) => (await readSettings()).enabled[p] && await chrome.permissions.contains({ origins: [ORIGINS[p]] })
});
var ticketReadiness = scheduler.prepareTickets();
async function readView2() {
  await ticketReadiness;
  return readView();
}
var ALARM = "ai-gauge-refresh";
var setupFlight = null;
var setupDirty = false;
function reconcile() {
  setupDirty = true;
  if (setupFlight) return setupFlight;
  setupFlight = (async () => {
    while (setupDirty) {
      setupDirty = false;
      await reconcileContent(await readView2());
    }
  })().finally(() => {
    setupFlight = null;
  });
  return setupFlight;
}
var publishedKey = null;
async function publish(force = false) {
  const view = await readView2(), key2 = JSON.stringify(view);
  if (!force && key2 === publishedKey) return view;
  publishedKey = key2;
  await updateBadge(view);
  await Promise.all(SITE_GROUPS.map(async (site) => {
    if (!site.providers.some((p) => view.permissions[displayProvider(p)])) return;
    const tabs = await chrome.tabs.query({ url: site.origin });
    await Promise.all(tabs.filter((t2) => typeof t2.id === "number" && !t2.discarded).map((t2) => chrome.tabs.sendMessage(t2.id, { type: "invalidate" }).catch(() => void 0)));
  }));
  return view;
}
async function publishTab(tabId) {
  const view = await publish();
  await updateBadge(view, [tabId]);
}
async function refresh(p, trigger) {
  await ticketReadiness;
  await scheduler.refresh(p, trigger);
}
async function refreshAll(trigger) {
  await Promise.all(PROVIDERS.map((p) => refresh(p, trigger)));
  await publish();
}
var settingsWrites = Promise.resolve();
function queueSettingsWrite(write) {
  const task = settingsWrites.then(write);
  settingsWrites = task.catch(() => void 0);
  return task;
}
function changeSettings(change) {
  return queueSettingsWrite(async () => {
    const settings = await readSettings();
    await change(settings);
    await writeSettings(parseSettings(settings));
  });
}
async function enableProviders(providers) {
  const granted = [];
  await changeSettings(async (settings) => {
    for (const provider of providers) {
      if (await chrome.permissions.contains({ origins: [ORIGINS[provider]] })) {
        settings.enabled[provider] = true;
        granted.push(provider);
      }
    }
  });
  if (!granted.length) return;
  await reconcile();
  await Promise.all(granted.map((provider) => refresh(provider, "manual")));
}
async function initialize() {
  if ((await chrome.alarms.get(ALARM))?.periodInMinutes !== 1) await chrome.alarms.create(ALARM, { periodInMinutes: 1 });
  await queueSettingsWrite(async () => {
    await migrateStorage();
  });
  await reconcile();
  await publish(true);
  await refreshAll("periodic");
}
chrome.runtime.onMessage.addListener((input, sender, sendResponse) => {
  const message = parseMessage(input);
  if (!message || !authorized(message, sender, chrome.runtime.id)) {
    sendResponse({ ok: false });
    return false;
  }
  void (async () => {
    if (sender.tab) {
      const p = providerFromUrl(sender.url);
      if (!await chrome.permissions.contains({ origins: [ORIGINS[displayProvider(p)]] })) return { ok: false };
    }
    if (message.type === "display-settings" || message.type === "disable") {
      await changeSettings((settings2) => {
        if (message.type === "display-settings") {
          settings2.strips = { ...message.strips };
          settings2.language = message.language;
          settings2.warning = message.warning;
          settings2.danger = message.danger;
        } else settings2.enabled[message.provider] = false;
      });
      const settings = await readSettings();
      await Promise.all(PROVIDERS.filter((provider) => !settings.enabled[provider]).map((provider) => scheduler.invalidateTickets(provider)));
      await reconcile();
    }
    if (message.type === "enable") await enableProviders([message.provider]);
    if (message.type === "enable-many") await enableProviders(message.providers);
    if (message.type === "context") await refresh(message.provider, "event");
    if (message.type === "refresh") await refresh(message.provider, message.trigger);
    if (message.type === "view" && !sender.tab) void refreshAll("event").catch(() => void 0);
    const view = message.type === "view" || message.type === "read" ? await readView2() : await publish();
    return { ok: true, view };
  })().then(sendResponse).catch(() => sendResponse({ ok: false }));
  return true;
});
chrome.alarms.onAlarm.addListener((a) => {
  if (a.name === ALARM) void refreshAll("periodic").catch(() => void 0);
});
chrome.runtime.onInstalled.addListener(() => {
  void initialize().catch(() => void 0);
});
chrome.runtime.onStartup.addListener(() => {
  void initialize().catch(() => void 0);
});
chrome.tabs.onActivated.addListener(({ tabId }) => {
  void chrome.tabs.get(tabId).then(async (tab) => {
    const p = providerFromUrl(tab.url);
    if (p) await refresh(displayProvider(p), "tab");
    await publishTab(tabId);
  }).catch(() => void 0);
});
chrome.tabs.onUpdated.addListener((tabId, change, tab) => {
  if (change.status === "loading" || change.status === "complete" || change.url) void (async () => {
    const p = providerFromUrl(change.url ?? tab.url);
    if (p) {
      if (change.status === "loading") await scheduler.invalidatePlan(displayProvider(p));
      if (tab.active && change.status !== "loading") await refresh(displayProvider(p), "tab");
    }
    await publishTab(tabId);
  })().catch(() => void 0);
});
chrome.windows.onFocusChanged.addListener((windowId) => {
  if (windowId !== -1) void updateBadgeFromFocus().catch(() => void 0);
});
async function updateBadgeFromFocus() {
  const [tab] = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
  const p = providerFromUrl(tab?.url);
  if (p) await refresh(displayProvider(p), "tab");
  if (typeof tab?.id === "number") await publishTab(tab.id);
  else await publish();
}
chrome.permissions.onAdded.addListener((added) => {
  const providers = PROVIDERS.filter((provider) => added.origins?.includes(ORIGINS[provider]));
  void (async () => {
    await enableProviders(providers);
    await reconcile();
    await publish(true);
  })().catch(() => void 0);
});
chrome.permissions.onRemoved.addListener((removed) => {
  const origins = (removed?.origins ?? []).filter((origin) => SITE_GROUPS.some((site) => site.origin === origin));
  const notice = { type: "permissions-revoked", origins };
  void chrome.tabs.query({}).then((tabs) => Promise.all(tabs.filter((t2) => typeof t2.id === "number").map((t2) => chrome.tabs.sendMessage(t2.id, notice).catch(() => void 0)))).catch(() => void 0);
  void Promise.all(PROVIDERS.filter((provider) => origins.includes(ORIGINS[provider])).map((provider) => scheduler.invalidateTickets(provider))).then(reconcile).then(() => publish(true)).catch(() => void 0);
});
void initialize().catch(() => void 0);
