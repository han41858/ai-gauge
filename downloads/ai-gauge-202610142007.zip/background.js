var __defProp = Object.defineProperty;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __esm = (fn, res) => function __init() {
  return fn && (res = (0, fn[__getOwnPropNames(fn)[0]])(fn = 0)), res;
};
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};

// src/shared/types.ts
var types_exports = {};
__export(types_exports, {
  HOME_URLS: () => HOME_URLS,
  NAMES: () => NAMES,
  ORIGINS: () => ORIGINS,
  PAGE_PROVIDERS: () => PAGE_PROVIDERS,
  PROVIDERS: () => PROVIDERS,
  SITE_GROUPS: () => SITE_GROUPS,
  isProvider: () => isProvider,
  providerFromUrl: () => providerFromUrl
});
function providerFromUrl(url) {
  try {
    const u = new URL(url ?? "");
    if (u.protocol !== "https:") return null;
    if (u.hostname === "claude.ai") return "claude";
    if (u.hostname === "gemini.google.com") return "gemini";
    if (u.hostname === "chatgpt.com") return /^\/(codex|work)(?:\/|$)/.test(u.pathname) ? "codex" : "chatgpt";
    return null;
  } catch {
    return null;
  }
}
var PROVIDERS, PAGE_PROVIDERS, ORIGINS, NAMES, HOME_URLS, isProvider, SITE_GROUPS;
var init_types = __esm({
  "src/shared/types.ts"() {
    "use strict";
    PROVIDERS = ["chatgpt", "claude", "gemini"];
    PAGE_PROVIDERS = ["chatgpt", "codex", "claude", "gemini"];
    ORIGINS = { chatgpt: "https://chatgpt.com/*", claude: "https://claude.ai/*", gemini: "https://gemini.google.com/*" };
    NAMES = { chatgpt: "ChatGPT", claude: "Claude", gemini: "Gemini" };
    HOME_URLS = { chatgpt: "https://chatgpt.com/", claude: "https://claude.ai/", gemini: "https://gemini.google.com/" };
    isProvider = (v) => PROVIDERS.includes(v);
    SITE_GROUPS = [
      { id: "openai", origin: ORIGINS.chatgpt, providers: ["chatgpt", "codex"] },
      { id: "claude", origin: ORIGINS.claude, providers: ["claude"] },
      { id: "gemini", origin: ORIGINS.gemini, providers: ["gemini"] }
    ];
  }
});

// src/background/index.ts
init_types();

// src/shared/contracts.ts
init_types();

// src/shared/validation.ts
function record(v) {
  return v !== null && typeof v === "object" && !Array.isArray(v) ? v : null;
}
var finite = (v) => typeof v === "number" && Number.isFinite(v);
var percent = (v) => finite(v) && v >= 0 && v <= 100 ? v : null;
var nonnegative = (v) => finite(v) && v >= 0 ? v : null;
function label(v) {
  return typeof v === "string" && v.trim().length > 0 && v.length <= 120 && !/[\u0000-\u001f\u007f]/.test(v) ? v.trim() : null;
}
function resetTime(v) {
  if (typeof v !== "string") return null;
  const parts = /^(\d{4})-(\d{2})-(\d{2})T(\d{2}):(\d{2}):(\d{2})(?:\.\d+)?(?:Z|[+-]\d{2}:\d{2})$/.exec(v);
  if (!parts) return null;
  const [year, month, day, hour, minute, second] = parts.slice(1, 7).map(Number);
  if (month < 1 || month > 12 || day < 1 || day > new Date(Date.UTC(year, month, 0)).getUTCDate() || hour > 23 || minute > 59 || second > 59) return null;
  const ms = Date.parse(v);
  return Number.isFinite(ms) && ms > 0 && ms < 41024448e5 ? new Date(ms).toISOString() : null;
}
function unixReset(v) {
  return finite(v) && v > 0 && v < 4102444800 ? new Date(v * 1e3).toISOString() : null;
}

// src/storage/settings.ts
init_types();
function defaults() {
  return { enabled: { chatgpt: false, claude: false, gemini: false }, strips: { chatgpt: true, codex: true, claude: true, gemini: true }, defaultProvider: "chatgpt", selectedLimit: { chatgpt: null, claude: null, gemini: null }, followTab: false, warning: 70, danger: 90 };
}
function parseSettings(value) {
  const out = defaults(), r = record(value);
  if (!r) return out;
  for (const p of PROVIDERS) {
    const enabled = record(r.enabled)?.[p];
    if (typeof enabled === "boolean") out.enabled[p] = enabled;
    const selected = record(r.selectedLimit)?.[p];
    if (selected === null || typeof selected === "string" && selected.length <= 200) out.selectedLimit[p] = selected;
  }
  for (const p of PAGE_PROVIDERS) {
    const strip = record(r.strips)?.[p];
    if (typeof strip === "boolean") out.strips[p] = strip;
  }
  if (isProvider(r.defaultProvider)) out.defaultProvider = r.defaultProvider;
  if (typeof r.followTab === "boolean") out.followTab = r.followTab;
  if (finite(r.warning) && finite(r.danger) && r.warning >= 0 && r.warning < r.danger && r.danger <= 100) {
    out.warning = r.warning;
    out.danger = r.danger;
  }
  return out;
}
function isSettings(value) {
  const r = record(value);
  if (!r || !isProvider(r.defaultProvider) || typeof r.followTab !== "boolean") return false;
  if (!finite(r.warning) || !finite(r.danger) || r.warning < 0 || r.warning >= r.danger || r.danger > 100) return false;
  return PROVIDERS.every((p) => typeof record(r.enabled)?.[p] === "boolean" && (record(r.selectedLimit)?.[p] === null || typeof record(r.selectedLimit)?.[p] === "string" && String(record(r.selectedLimit)?.[p]).length <= 200)) && PAGE_PROVIDERS.every((p) => typeof record(r.strips)?.[p] === "boolean");
}

// src/storage/snapshots.ts
init_types();

// src/shared/errors.ts
var CollectionError = class extends Error {
  constructor(code, state = "error", retryAfterMs = 0) {
    super(code);
    this.code = code;
    this.state = state;
    this.retryAfterMs = retryAfterMs;
  }
};
function retryAfter(value, now = Date.now()) {
  if (!value) return 0;
  if (/^\d+(?:\.\d+)?$/.test(value)) {
    const ms = Number(value) * 1e3;
    return Number.isFinite(ms) && ms <= Number.MAX_SAFE_INTEGER ? Math.max(0, ms) : 0;
  }
  const time = Date.parse(value);
  return Number.isFinite(time) ? Math.max(0, time - now) : 0;
}
function httpError(status, wait = 0) {
  if (status === 401) return new CollectionError("signed_out", "signed_out");
  if (status === 429) return new CollectionError("rate_limited", "rate_limited", wait);
  if (status === 403) return new CollectionError("access_denied");
  return new CollectionError(status >= 500 ? "server" : "invalid_response");
}
var ERROR_TEXT = {
  not_collected: "\uC544\uC9C1 \uC218\uC9D1\uD558\uC9C0 \uC54A\uC558\uC2B5\uB2C8\uB2E4.",
  signed_out: "\uC0AC\uC774\uD2B8\uC5D0 \uB85C\uADF8\uC778\uD55C \uB4A4 \uC218\uB3D9 \uAC31\uC2E0\uD574 \uC8FC\uC138\uC694.",
  access_denied: "\uC0AC\uC774\uD2B8\uAC00 \uC811\uADFC\uC744 \uAC70\uBD80\uD588\uC2B5\uB2C8\uB2E4. \uBCF4\uD638\uC7A5\uCE58\uB97C \uC6B0\uD68C\uD558\uC9C0 \uC54A\uC2B5\uB2C8\uB2E4.",
  rate_limited: "\uC694\uCCAD \uD55C\uB3C4\uC5D0 \uB3C4\uB2EC\uD588\uC2B5\uB2C8\uB2E4. \uC7AC\uC2DC\uB3C4 \uC2DC\uAC01\uAE4C\uC9C0 \uAE30\uB2E4\uB824 \uC8FC\uC138\uC694.",
  network: "\uC5F0\uACB0 \uB610\uB294 \uC694\uCCAD \uC2DC\uAC04\uC774 \uCD08\uACFC\uB418\uC5C8\uC2B5\uB2C8\uB2E4.",
  invalid_response: "\uC0AC\uC6A9\uB7C9 \uC751\uB2F5 \uD615\uC2DD\uC744 \uD655\uC778\uD560 \uC218 \uC5C6\uC2B5\uB2C8\uB2E4.",
  open_tab: "\uB85C\uADF8\uC778\uD55C \uC11C\uBE44\uC2A4 \uD0ED\uC744 \uC5F4\uACE0 \uAC31\uC2E0\uD574 \uC8FC\uC138\uC694.",
  ambiguous_account: "\uC5EC\uB7EC Claude \uC870\uC9C1\uC774 \uD655\uC778\uB418\uC5B4 \uC120\uD0DD\uD560 \uC218 \uC5C6\uC2B5\uB2C8\uB2E4. \uACC4\uC815\uC758 \uC0AC\uC6A9\uB7C9 \uD654\uBA74\uC744 \uD655\uC778\uD574 \uC8FC\uC138\uC694.",
  tab_access_failed: "\uC5F4\uB9B0 \uC11C\uBE44\uC2A4 \uD0ED\uC5D0\uC11C \uC218\uC9D1 \uCF54\uB4DC\uB97C \uC2E4\uD589\uD558\uC9C0 \uBABB\uD588\uC2B5\uB2C8\uB2E4. Chrome \uD655\uC7A5 \uD504\uB85C\uADF8\uB7A8\uC758 \uD574\uB2F9 \uC0AC\uC774\uD2B8 \uC811\uADFC \uC124\uC815\uC744 \uD655\uC778\uD55C \uB4A4 \uD655\uC7A5\uACFC \uD0ED\uC744 \uC0C8\uB85C\uACE0\uCE68\uD574 \uC8FC\uC138\uC694.",
  unsupported: "\uC548\uC804\uD55C \uC218\uC9D1 \uACC4\uC57D\uC744 \uAC80\uC99D\uD558\uC9C0 \uBABB\uD574 \uBBF8\uC9C0\uC6D0\uC785\uB2C8\uB2E4.",
  permission_required: "\uC774 \uC11C\uBE44\uC2A4\uC758 \uC0AC\uC774\uD2B8 \uC811\uADFC \uAD8C\uD55C\uC774 \uD544\uC694\uD569\uB2C8\uB2E4.",
  server: "\uC11C\uBE44\uC2A4 \uC624\uB958\uC785\uB2C8\uB2E4. \uC7A0\uC2DC \uD6C4 \uB2E4\uC2DC \uC2DC\uB3C4\uD569\uB2C8\uB2E4."
};

// src/storage/snapshots.ts
var FRESH_MS = 10 * 6e4;
function emptySnapshot(provider) {
  return { provider, state: "error", limits: [], collectedAt: null, checkedAt: null, nextAttemptAt: 0, failures: 0, errorCode: "not_collected" };
}
function validLimits(input) {
  return Array.isArray(input) && input.length <= 150 && input.every((x) => {
    const r = record(x);
    return r && typeof r.id === "string" && r.id.length > 0 && r.id.length <= 200 && label(r.label) && ["window", "model", "product"].includes(String(r.category)) && r.source === "api" && (r.percent === null || percent(r.percent) !== null) && (r.resetsAt === null || resetTime(r.resetsAt) !== null) && (r.windowSeconds === null || nonnegative(r.windowSeconds) !== null) && (r.remaining === null || nonnegative(r.remaining) !== null) && (r.unit === null || label(r.unit));
  }) && new Set(input.map((x) => x.id)).size === input.length;
}
function parseSnapshot(input, provider) {
  const r = record(input);
  if (!r || r.provider !== provider || !["ok", "stale", "signed_out", "permission_required", "rate_limited", "unsupported", "error"].includes(String(r.state)) || !validLimits(r.limits) || !(r.collectedAt === null || finite(r.collectedAt)) || !(r.checkedAt === null || finite(r.checkedAt)) || !finite(r.nextAttemptAt) || !finite(r.failures) || !(r.errorCode === null || typeof r.errorCode === "string" && Object.hasOwn(ERROR_TEXT, r.errorCode))) return emptySnapshot(provider);
  if (r.state === "ok" && (r.collectedAt === null || r.limits.length === 0)) return emptySnapshot(provider);
  const limits = r.limits.map((limit) => ({
    id: limit.id,
    label: label(limit.label),
    category: limit.category,
    percent: limit.percent,
    resetsAt: limit.resetsAt === null ? null : resetTime(limit.resetsAt),
    windowSeconds: limit.windowSeconds,
    remaining: limit.remaining,
    unit: limit.unit === null ? null : label(limit.unit),
    source: "api"
  }));
  return { provider, state: r.state, limits, collectedAt: r.collectedAt, checkedAt: r.checkedAt, nextAttemptAt: Math.max(0, r.nextAttemptAt), failures: Math.max(0, r.failures), errorCode: r.errorCode };
}
function effectiveSnapshot(snapshot, now = Date.now()) {
  return snapshot.state === "ok" && (snapshot.collectedAt === null || now - snapshot.collectedAt >= FRESH_MS || snapshot.collectedAt > now + 6e4) ? { ...snapshot, state: "stale" } : snapshot;
}
async function readSnapshot(provider) {
  await migrateStorage();
  const key = snapshotKey(provider);
  return parseSnapshot((await chrome.storage.local.get(key))[key], provider);
}
var SNAPSHOT_KEYS = { chatgpt: "snapshot:v4:chatgpt", claude: "snapshot:v2:claude", gemini: "snapshot:v1:gemini" };
var snapshotKey = (provider) => SNAPSHOT_KEYS[provider];
var SETTINGS_KEY = "settings:v2";
var MIGRATION_KEY = "migration:shared-chatgpt:v2";
var migrations = /* @__PURE__ */ new WeakMap();
function legacySettings(input) {
  const old = record(input), enabled = record(old?.enabled), strips = record(old?.strips), selected = record(old?.selectedLimit);
  return parseSettings({
    enabled: { chatgpt: enabled?.work_codex, claude: enabled?.claude },
    strips: { chatgpt: strips?.chatgpt, codex: strips?.work_codex, claude: strips?.claude },
    selectedLimit: { chatgpt: selected?.work_codex, claude: selected?.claude },
    defaultProvider: old?.defaultProvider === "work_codex" ? "chatgpt" : old?.defaultProvider === "claude" ? "claude" : "chatgpt",
    followTab: old?.followTab,
    warning: old?.warning,
    danger: old?.danger
  });
}
async function migrate(local) {
  const sharedKey = snapshotKey("chatgpt");
  const stored = await local.get([MIGRATION_KEY, SETTINGS_KEY, sharedKey, "settings", "snapshot:v2:work_codex"]);
  if (stored[MIGRATION_KEY] === true) return;
  const updates = { [MIGRATION_KEY]: true };
  updates[SETTINGS_KEY] = Object.hasOwn(stored, SETTINGS_KEY) ? parseSettings(stored[SETTINGS_KEY]) : legacySettings(stored.settings);
  if (!Object.hasOwn(stored, sharedKey)) {
    const old = record(stored["snapshot:v2:work_codex"]);
    updates[sharedKey] = old?.provider === "work_codex" ? parseSnapshot({
      provider: "chatgpt",
      state: old.state,
      limits: old.limits,
      collectedAt: old.collectedAt,
      checkedAt: old.checkedAt,
      nextAttemptAt: old.nextAttemptAt,
      failures: old.failures,
      errorCode: old.errorCode
    }, "chatgpt") : emptySnapshot("chatgpt");
  }
  await local.set(updates);
}
function migrateStorage() {
  const local = chrome.storage.local;
  let pending = migrations.get(local);
  if (!pending) {
    pending = migrate(local).catch((error) => {
      migrations.delete(local);
      throw error;
    });
    migrations.set(local, pending);
  }
  return pending;
}
async function writeSnapshot(snapshot) {
  await migrateStorage();
  await chrome.storage.local.set({ [snapshotKey(snapshot.provider)]: parseSnapshot(snapshot, snapshot.provider) });
}
async function readSettings() {
  await migrateStorage();
  return parseSettings((await chrome.storage.local.get(SETTINGS_KEY))[SETTINGS_KEY]);
}
async function writeSettings(settings) {
  await migrateStorage();
  await chrome.storage.local.set({ [SETTINGS_KEY]: parseSettings(settings) });
}
async function readView() {
  const settings = await readSettings();
  const permissions = {}, snapshots = {};
  const { ORIGINS: ORIGINS2 } = await Promise.resolve().then(() => (init_types(), types_exports));
  await Promise.all(PROVIDERS.map(async (p) => {
    permissions[p] = await chrome.permissions.contains({ origins: [ORIGINS2[p]] });
    const s = effectiveSnapshot(await readSnapshot(p));
    snapshots[p] = permissions[p] ? s : { ...s, state: "permission_required", errorCode: "permission_required" };
  }));
  return { settings, snapshots, permissions };
}

// src/shared/display-policy.ts
var displayProvider = (page) => page === "codex" ? "chatgpt" : page;
function shouldShowStrip(view, page) {
  const source = displayProvider(page);
  return view.permissions[source] && view.settings.enabled[source] && view.settings.strips[page];
}
function needsContent(view, pages) {
  return pages.some((page) => shouldShowStrip(view, page));
}
var canRefreshFromPage = (page, source) => displayProvider(page) === source;

// src/shared/contracts.ts
function parseMessage(input) {
  const r = record(input);
  if (!r) return null;
  const keys = Object.keys(r).sort().join(",");
  if (r.type === "view" && keys === "type") return { type: "view" };
  if ((r.type === "enable" || r.type === "disable") && keys === "provider,type" && isProvider(r.provider)) return { type: r.type, provider: r.provider };
  if (r.type === "strips" && keys === "strips,type") {
    const strips = record(r.strips);
    if (strips && Object.keys(strips).length === PAGE_PROVIDERS.length && PAGE_PROVIDERS.every((p) => typeof strips[p] === "boolean")) {
      return { type: "strips", strips: Object.fromEntries(PAGE_PROVIDERS.map((p) => [p, strips[p]])) };
    }
  }
  if (r.type === "refresh" && keys === "provider,trigger,type" && isProvider(r.provider) && (r.trigger === "manual" || r.trigger === "event")) return { type: "refresh", provider: r.provider, trigger: r.trigger };
  if (r.type === "settings" && keys === "settings,type" && isSettings(r.settings)) return { type: "settings", settings: r.settings };
  return null;
}
function authorized(message, sender, extensionId) {
  if (sender.id !== extensionId) return false;
  if (sender.tab) {
    const p = providerFromUrl(sender.url);
    return p !== null && providerFromUrl(sender.tab.url) === p && sender.frameId === 0 && (message.type === "view" || message.type === "refresh" && canRefreshFromPage(p, message.provider) && message.trigger === "event");
  }
  return sender.url === `chrome-extension://${extensionId}/popup.html`;
}

// src/providers/tab-transport.ts
init_types();

// src/providers/gemini-transport.ts
async function collectGeminiInPage() {
  const result = (status, code = null, wait = null, data = null) => ({ status, code, retryAfter: wait, data });
  if (location.origin !== "https://gemini.google.com") return result(0, "open_tab");
  const page = new URL(location.href);
  const account = /^\/u\/([^/]+)(?:\/|$)/.exec(page.pathname)?.[1];
  if (account !== void 0 && account !== "0" || page.searchParams.getAll("authuser").some((value) => value !== "0")) return result(200, "unsupported");
  const controller = new AbortController(), timeout = setTimeout(() => controller.abort(), 15e3);
  const fail = () => {
    throw new Error("invalid_response");
  };
  const sanitize = (payload) => {
    if (!Array.isArray(payload) || !Array.isArray(payload[1]) || payload[1].length > 20) return fail();
    const windows = [], seen = /* @__PURE__ */ new Set();
    for (const row of payload[1]) {
      if (!Array.isArray(row) || !Number.isInteger(row[2])) return fail();
      const type = row[2];
      if (type !== 1 && type !== 2) continue;
      if (seen.has(type)) return fail();
      seen.add(type);
      const ratio = row[1];
      if (ratio != null && (typeof ratio !== "number" || !Number.isFinite(ratio) || ratio < 0 || ratio > 1)) return fail();
      let reset = null;
      if (row[3] != null) {
        const outer = row[3];
        if (!Array.isArray(outer) || outer.length !== 1 || !Array.isArray(outer[0])) return fail();
        const stamp = outer[0], seconds = stamp[0], nanos = stamp.length === 1 ? 0 : stamp[1];
        if (stamp.length < 1 || stamp.length > 2 || typeof seconds !== "number" || !Number.isSafeInteger(seconds) || seconds <= 0 || seconds >= 4102444800 || typeof nanos !== "number" || !Number.isInteger(nanos) || nanos < 0 || nanos >= 1e9) return fail();
        reset = [[seconds, nanos]];
      }
      windows.push([null, ratio ?? null, type, reset]);
    }
    if (!windows.length) return fail();
    return [null, windows];
  };
  const decode = (body) => {
    if (!body || body.length > 1048576) return fail();
    let text = body.trimStart();
    if (text.startsWith(")]}'")) text = text.slice(4).trimStart();
    const frames = [];
    if (text.startsWith("[")) frames.push(JSON.parse(text));
    else {
      let cursor = 0;
      while (cursor < text.length) {
        while (/\s/.test(text[cursor] ?? "") && cursor < text.length) cursor++;
        if (cursor === text.length) break;
        const prefix = /^(\d{1,7})\r?\n/.exec(text.slice(cursor));
        if (!prefix) return fail();
        const length = Number(prefix[1]);
        cursor += prefix[0].length;
        if (length <= 0 || length > 1048576 || cursor + length > text.length) return fail();
        frames.push(JSON.parse(text.slice(cursor, cursor + length)));
        cursor += length;
        if (cursor < text.length && !/\s/.test(text[cursor])) return fail();
        if (frames.length > 100) return fail();
      }
    }
    let answer = void 0, count = 0;
    for (const frame of frames) {
      if (!Array.isArray(frame) || frame.length > 100) return fail();
      for (const row of frame) {
        if (!Array.isArray(row) || typeof row[0] !== "string") return fail();
        if (row[0] !== "wrb.fr" || row[1] !== "jSf9Qc" && row[1] !== null) continue;
        const status = row[5];
        if (status != null) {
          if (Array.isArray(status) && (status[0] === 1037 || status[0] === 1060)) throw new Error("rate_limited");
          throw new Error("unsupported");
        }
        if (row[1] !== "jSf9Qc") continue;
        if (++count !== 1 || typeof row[2] !== "string" || !row[2]) return fail();
        answer = JSON.parse(row[2]);
      }
    }
    if (count !== 1) return fail();
    return sanitize(answer);
  };
  try {
    const token = window.WIZ_global_data?.SNlM0e;
    if (typeof token !== "string" || !token || token.length > 16384) return result(200, "unsupported");
    const body = new URLSearchParams({ "f.req": JSON.stringify([[["jSf9Qc", "[]", null, "generic"]]]), at: token });
    const response = await fetch("https://gemini.google.com/_/BardChatUi/data/batchexecute?rpcids=jSf9Qc&source-path=%2Fusage&rt=c", {
      method: "POST",
      credentials: "include",
      cache: "no-store",
      redirect: "error",
      signal: controller.signal,
      headers: { "Content-Type": "application/x-www-form-urlencoded;charset=UTF-8", "X-Same-Domain": "1" },
      body: body.toString()
    });
    if (!response.ok) {
      const wait = response.headers.get("Retry-After");
      return result(response.status, null, wait !== null && wait.length <= 100 ? wait : null);
    }
    if (!/^(?:application\/json|text\/plain)(?:;|$)/i.test(response.headers.get("Content-Type") ?? "")) return result(200, "invalid_response");
    const reader = response.body?.getReader();
    if (!reader) return result(200, "invalid_response");
    const decoder = new TextDecoder("utf-8", { fatal: true });
    let raw = "", bytes = 0;
    try {
      while (true) {
        const chunk = await reader.read();
        if (chunk.done) break;
        bytes += chunk.value.byteLength;
        if (bytes > 1048576) {
          await reader.cancel().catch(() => void 0);
          return result(200, "invalid_response");
        }
        try {
          raw += decoder.decode(chunk.value, { stream: true });
        } catch {
          return result(200, "invalid_response");
        }
      }
      try {
        raw += decoder.decode();
      } catch {
        return result(200, "invalid_response");
      }
    } finally {
      reader.releaseLock();
    }
    try {
      return result(200, null, null, decode(raw));
    } catch (error) {
      if (error instanceof Error && error.message === "rate_limited") return result(429);
      return result(200, error instanceof Error && error.message === "unsupported" ? "unsupported" : "invalid_response");
    }
  } catch {
    return result(0, "network");
  } finally {
    controller.abort();
    clearTimeout(timeout);
  }
}

// src/providers/tab-transport.ts
async function collectInPage(provider) {
  const origin = provider === "chatgpt" ? "https://chatgpt.com" : "https://claude.ai";
  if (location.origin !== origin) return { status: 0, code: "open_tab", retryAfter: null, data: null };
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 15e3);
  const result = (status, code = null, wait = null, data = null) => ({ status, code, retryAfter: wait, data });
  const object = (v) => v !== null && typeof v === "object" && !Array.isArray(v) ? v : null;
  const numeric = (v) => typeof v === "number" && Number.isFinite(v) ? v : null;
  const text = (v) => typeof v === "string" && v.length <= 120 ? v : null;
  const get = (path, headers = {}) => fetch(`${origin}${path}`, { method: "GET", credentials: "include", cache: "no-store", redirect: "error", signal: controller.signal, headers: { Accept: "application/json", ...headers } });
  const errorResult = (r) => result(r.status, null, r.headers.get("Retry-After"));
  const read = async (r) => {
    if (!r.headers.get("content-type")?.includes("application/json")) throw new Error("invalid_response");
    return r.json();
  };
  const chatRate = (value) => {
    const raw = object(value), out = {};
    for (const key of ["primary_window", "secondary_window"]) {
      const w = object(raw?.[key]);
      if (w && ("used_percent" in w || "reset_at" in w)) out[key] = { used_percent: numeric(w.used_percent), reset_at: numeric(w.reset_at), limit_window_seconds: numeric(w.limit_window_seconds) };
    }
    return out;
  };
  try {
    if (provider === "chatgpt") {
      const sessionResp = await get("/api/auth/session");
      if (!sessionResp.ok) return errorResult(sessionResp);
      const session = object(await read(sessionResp));
      if (typeof session?.accessToken !== "string" || !session.accessToken || session.accessToken.length > 16384) return result(401);
      const usageResp2 = await get("/backend-api/wham/usage", { Authorization: `Bearer ${session.accessToken}` });
      if (!usageResp2.ok) return errorResult(usageResp2);
      const raw2 = object(await read(usageResp2));
      if (!raw2) return result(200, "invalid_response");
      return result(200, null, null, { rate_limit: chatRate(raw2.rate_limit), additional_rate_limits: Array.isArray(raw2.additional_rate_limits) ? raw2.additional_rate_limits.slice(0, 50).map((v) => {
        const r = object(v);
        return { limit_name: text(r?.limit_name), metered_feature: text(r?.metered_feature), rate_limit: chatRate(r?.rate_limit) };
      }) : [] });
    }
    const orgResp = await get("/api/organizations");
    if (!orgResp.ok) return errorResult(orgResp);
    const orgs = await read(orgResp);
    if (!Array.isArray(orgs)) return result(200, "invalid_response");
    if (!orgs.length) return result(200, "invalid_response");
    if (orgs.length !== 1) return result(200, "ambiguous_account");
    const uuid = object(orgs[0])?.uuid;
    if (typeof uuid !== "string" || !/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(uuid)) return result(200, "invalid_response");
    const usageResp = await get(`/api/organizations/${uuid}/usage`);
    if (!usageResp.ok) return errorResult(usageResp);
    const raw = object(await read(usageResp)), out = {};
    if (!raw) return result(200, "invalid_response");
    for (const [key, value] of Object.entries(raw).slice(0, 100)) {
      if (!/^(five_hour|seven_day(?:_[a-z0-9_]+)?)$/.test(key)) continue;
      const w = object(value);
      if (w && ("utilization" in w || "resets_at" in w)) out[key] = { utilization: numeric(w.utilization), resets_at: text(w.resets_at) };
    }
    out.limits = Array.isArray(raw.limits) ? raw.limits.slice(0, 50).map((v) => {
      const w = object(v);
      return { kind: text(w?.kind), percent: numeric(w?.percent), resets_at: text(w?.resets_at), scope: { model: { display_name: text(object(object(w?.scope)?.model)?.display_name) } } };
    }) : [];
    return result(200, null, null, out);
  } catch (e) {
    return result(0, e instanceof Error && e.message === "invalid_response" ? "invalid_response" : "network");
  } finally {
    clearTimeout(timeout);
  }
}
function unwrapTransport(value) {
  const r = record(value);
  if (!r || typeof r.status !== "number" || !Number.isInteger(r.status) || r.status < 0 || r.status > 599) throw new CollectionError("invalid_response");
  if (r.code !== null) {
    if (r.code === "unsupported") throw new CollectionError("unsupported", "unsupported");
    if (r.code === "network" || r.code === "invalid_response" || r.code === "open_tab" || r.code === "ambiguous_account") throw new CollectionError(r.code);
    throw new CollectionError("invalid_response");
  }
  if (r.status !== 200) throw httpError(r.status, retryAfter(typeof r.retryAfter === "string" && r.retryAfter.length <= 100 ? r.retryAfter : null));
  return r.data;
}
async function collectionTab(provider) {
  const eligible = (await chrome.tabs.query({ url: ORIGINS[provider] })).filter((tab) => !tab.discarded && !tab.frozen && typeof tab.id === "number");
  if (eligible.length <= 1) return eligible[0];
  const focused = await chrome.tabs.query({ url: ORIGINS[provider], active: true, lastFocusedWindow: true });
  return eligible.find((tab) => focused.some((candidate) => candidate.id === tab.id && candidate.active)) ?? eligible.sort((a, b) => Number(b.active) - Number(a.active))[0];
}
async function collectFromTab(provider) {
  if (!await chrome.permissions.contains({ origins: [ORIGINS[provider]] })) throw new CollectionError("permission_required", "permission_required");
  const tab = await collectionTab(provider);
  if (typeof tab?.id !== "number") throw new CollectionError("open_tab");
  let results;
  try {
    results = provider === "gemini" ? await chrome.scripting.executeScript({ target: { tabId: tab.id }, world: "MAIN", func: collectGeminiInPage }) : await chrome.scripting.executeScript({ target: { tabId: tab.id }, world: "MAIN", func: collectInPage, args: [provider] });
  } catch {
    throw new CollectionError("tab_access_failed");
  }
  return unwrapTransport(results[0]?.result);
}

// src/providers/parsers.ts
var InvalidResponse = class extends Error {
  constructor() {
    super("invalid_response");
  }
};
var item = (id, name, category, value, reset, span) => ({ id, label: name, category, percent: percent(value), resetsAt: reset, windowSeconds: span, remaining: null, unit: null, source: "api" });
function parseClaude(input) {
  const data = record(input);
  if (!data) throw new InvalidResponse();
  const items = [];
  for (const [key, raw] of Object.entries(data).slice(0, 100)) {
    if (!/^(five_hour|seven_day(?:_[a-z0-9_]+)?)$/.test(key)) continue;
    const w = record(raw);
    if (!w || !("utilization" in w) && !("resets_at" in w)) continue;
    const name = key === "five_hour" ? "5\uC2DC\uAC04" : key === "seven_day" ? "7\uC77C" : `7\uC77C \xB7 ${key.slice(10)}`;
    items.push(item(key, name, key === "five_hour" || key === "seven_day" ? "window" : "model", w.utilization, resetTime(w.resets_at), key === "five_hour" ? 18e3 : 604800));
  }
  if (Array.isArray(data.limits)) {
    for (const raw of data.limits.slice(0, 50)) {
      const w = record(raw), model = record(record(w?.scope)?.model);
      const modelName = label(model?.display_name);
      if (w?.kind !== "weekly_scoped" || !modelName || modelName.length > 100) continue;
      const id = `weekly_scoped:${modelName}`;
      if (items.some((v) => v.id === id)) continue;
      items.push(item(id, `7\uC77C \xB7 ${modelName}`, "model", w.percent, resetTime(w.resets_at), 604800));
    }
  }
  if (!items.length) throw new InvalidResponse();
  return items;
}
function chatWindows(raw, prefix, title, category) {
  const rate = record(raw);
  if (!rate) return [];
  const result = [];
  for (const key of ["primary_window", "secondary_window"]) {
    const w = record(rate[key]);
    if (!w || !("used_percent" in w || "reset_at" in w)) continue;
    const span = nonnegative(w.limit_window_seconds);
    const windowLabel = span === 18e3 ? "5\uC2DC\uAC04" : span === 604800 ? "7\uC77C" : span ? `${span / 3600}\uC2DC\uAC04` : key === "primary_window" ? "\uAE30\uBCF8 \uC81C\uD55C" : "\uCD94\uAC00 \uC81C\uD55C";
    result.push(item(`${prefix}:${key}`, `${title} \xB7 ${windowLabel}`, category, w.used_percent, unixReset(w.reset_at), span));
  }
  return result;
}
function parseChatGPT(input) {
  const data = record(input);
  if (!data) throw new InvalidResponse();
  const items = chatWindows(data.rate_limit, "shared", "ChatGPT", "product");
  if (Array.isArray(data.additional_rate_limits)) {
    for (const raw of data.additional_rate_limits.slice(0, 50)) {
      const bucket = record(raw);
      const name = label(bucket?.limit_name) ?? label(bucket?.metered_feature);
      if (!name || name.length > 100) continue;
      for (const limit of chatWindows(bucket?.rate_limit, `product:${name}`, name, "product")) if (!items.some((i) => i.id === limit.id)) items.push(limit);
    }
  }
  if (!items.length) throw new InvalidResponse();
  return items;
}

// src/providers/chatgpt.ts
async function collectChatGPT() {
  return parseChatGPT(await collectFromTab("chatgpt"));
}

// src/providers/gemini-parser.ts
function parseGemini(input) {
  if (!Array.isArray(input) || !Array.isArray(input[1]) || input[1].length > 20) throw new InvalidResponse();
  const limits = [], seen = /* @__PURE__ */ new Set();
  for (const row of input[1]) {
    if (!Array.isArray(row) || !Number.isInteger(row[2])) throw new InvalidResponse();
    const type = row[2];
    if (type !== 1 && type !== 2) continue;
    if (seen.has(type)) throw new InvalidResponse();
    seen.add(type);
    const ratio = row[1];
    if (ratio != null && (typeof ratio !== "number" || !Number.isFinite(ratio) || ratio < 0 || ratio > 1)) throw new InvalidResponse();
    let resetsAt = null;
    const reset = row[3];
    if (reset != null) {
      if (!Array.isArray(reset) || reset.length !== 1 || !Array.isArray(reset[0])) throw new InvalidResponse();
      const stamp = reset[0];
      const seconds = stamp[0], nanos = stamp.length === 1 ? 0 : stamp[1];
      if (stamp.length < 1 || stamp.length > 2 || typeof seconds !== "number" || !Number.isSafeInteger(seconds) || seconds <= 0 || seconds >= 4102444800 || typeof nanos !== "number" || !Number.isInteger(nanos) || nanos < 0 || nanos >= 1e9) throw new InvalidResponse();
      resetsAt = new Date(seconds * 1e3 + Math.floor(nanos / 1e6)).toISOString();
    }
    limits.push({
      id: type === 1 ? "five_hour" : "seven_day",
      label: type === 1 ? "5\uC2DC\uAC04" : "7\uC77C",
      category: "window",
      percent: ratio == null ? null : ratio * 100,
      resetsAt,
      windowSeconds: type === 1 ? 18e3 : 604800,
      remaining: null,
      unit: null,
      source: "api"
    });
  }
  if (!limits.length) throw new InvalidResponse();
  return limits;
}

// src/providers/gemini.ts
async function collectGemini() {
  return parseGemini(await collectFromTab("gemini"));
}

// src/providers/claude.ts
async function collectClaude() {
  return parseClaude(await collectFromTab("claude"));
}

// src/providers/index.ts
var collect = (p) => ({ chatgpt: collectChatGPT, claude: collectClaude, gemini: collectGemini })[p]();

// src/background/scheduler.ts
function backoff(failures) {
  return Math.min(60 * 6e4, 6e4 * 2 ** Math.min(6, Math.max(0, failures - 1)));
}
function due(s, trigger, now) {
  if (s.state === "error" && s.errorCode === "open_tab" && trigger === "tab") return true;
  if (now < s.nextAttemptAt) return false;
  if (s.checkedAt !== null && now - s.checkedAt < 6e4) return false;
  if (trigger !== "manual" && ["signed_out", "permission_required", "unsupported"].includes(s.state)) return false;
  return trigger === "manual" || s.collectedAt === null || now - s.collectedAt >= (trigger === "periodic" ? FRESH_MS : 6e4);
}
function success(previous, limits, now) {
  return { ...previous, limits, state: "ok", collectedAt: now, checkedAt: now, failures: 0, nextAttemptAt: now + 6e4, errorCode: null };
}
function failure(previous, error, now) {
  const e = error instanceof CollectionError ? error : new CollectionError("invalid_response");
  if (e.code === "open_tab") return { ...previous, state: "error", checkedAt: now, nextAttemptAt: now + 6e4, failures: 0, errorCode: e.code };
  const failures = previous.failures + 1;
  return { ...previous, state: e.state, checkedAt: now, failures, nextAttemptAt: now + Math.max(backoff(failures), e.retryAfterMs), errorCode: e.code };
}
var Scheduler = class {
  constructor(io) {
    this.io = io;
  }
  flights = /* @__PURE__ */ new Map();
  refresh(p, trigger) {
    const active = this.flights.get(p);
    if (active) return active;
    const task = this.run(p, trigger).finally(() => this.flights.delete(p));
    this.flights.set(p, task);
    return task;
  }
  async run(p, trigger) {
    const before = await this.io.read(p);
    if (!await this.io.enabled(p) || !due(before, trigger, this.io.now())) return before;
    await this.io.write({ ...before, checkedAt: this.io.now(), nextAttemptAt: this.io.now() + 6e4, errorCode: before.errorCode === "open_tab" ? "not_collected" : before.errorCode });
    let after;
    try {
      const result = await this.io.collect(p), now = this.io.now();
      if (!validLimits(result) || !result.length) throw new CollectionError("invalid_response");
      after = success(before, result, now);
    } catch (e) {
      after = failure(before, e, this.io.now());
    }
    if (!await this.io.enabled(p)) return before;
    await this.io.write(after);
    return after;
  }
};

// src/background/badge.ts
init_types();

// src/shared/usage-selection.ts
function highestUsageLimit(limits) {
  let highest = null;
  let highestPercent = -1;
  for (const limit of limits) {
    const used = percent(limit.percent);
    if (used !== null && used > highestPercent) {
      highest = limit;
      highestPercent = used;
    }
  }
  return highest;
}

// src/shared/format.ts
var usageValue = (limit) => limit.percent !== null ? `${Math.round(limit.percent)}%` : limit.remaining !== null ? `${limit.remaining.toLocaleString()}${limit.unit ?? ""} \uB0A8\uC74C` : "\uD655\uC778 \uBD88\uAC00";
var usageText = (limit) => `${limit.label}: ${usageValue(limit)}`;
function statusText(snapshot) {
  if (snapshot.state === "ok") return "\uCD5C\uADFC \uC218\uC9D1 \uC131\uACF5";
  if (snapshot.state === "stale") return "\uC624\uB798\uB41C \uC815\uBCF4 \xB7 \uAC31\uC2E0 \uD544\uC694";
  return snapshot.errorCode ? ERROR_TEXT[snapshot.errorCode] : "\uD655\uC778 \uBD88\uAC00";
}

// src/background/badge.ts
var SERVICE_COLORS = { chatgpt: "#0D8669", claude: "#B16046", gemini: "#3569C8" };
function selectedLimit(snapshot, _settings) {
  return highestUsageLimit(snapshot.limits);
}
function badge(view, activeUrl, now = Date.now()) {
  const page = providerFromUrl(activeUrl);
  if (!page) return { text: "", color: "#697386", textColor: "#FFFFFF", title: "AI Gauge" };
  const p = displayProvider(page);
  const s = effectiveSnapshot(view.snapshots[p], now), limit = selectedLimit(s, view.settings);
  if (!view.settings.enabled[p] || !view.permissions[p] || s.state !== "ok" || !limit || limit.percent === null) {
    const reason = !view.settings.enabled[p] ? "\uBE44\uD65C\uC131" : !view.permissions[p] ? "\uAD8C\uD55C \uD544\uC694" : s.state !== "ok" ? statusText(s) : "\uC0AC\uC6A9\uB960 \uD655\uC778 \uBD88\uAC00";
    return { text: "\u2014", color: "#697386", textColor: "#FFFFFF", title: `AI Gauge \xB7 ${NAMES[p]} \xB7 ${reason}` };
  }
  return { text: `${Math.round(limit.percent)}%`, color: SERVICE_COLORS[p], textColor: "#FFFFFF", title: `AI Gauge \xB7 ${NAMES[p]} \xB7 ${usageText(limit)}` };
}
async function renderBadges(view) {
  await Promise.allSettled([
    chrome.action.setBadgeText({ text: "" }),
    chrome.action.setBadgeBackgroundColor({ color: "#697386" }),
    chrome.action.setBadgeTextColor({ color: "#FFFFFF" }),
    chrome.action.setTitle({ title: "AI Gauge" })
  ]);
  let tabs;
  try {
    tabs = await chrome.tabs.query({});
  } catch {
    return;
  }
  await Promise.all(tabs.filter((tab) => typeof tab.id === "number").map(async ({ id }) => {
    let tab;
    try {
      tab = await chrome.tabs.get(id);
    } catch {
      return;
    }
    const value = badge(view, tab.url);
    await Promise.allSettled([
      chrome.action.setBadgeText({ tabId: id, text: value.text }),
      chrome.action.setBadgeBackgroundColor({ tabId: id, color: value.color }),
      chrome.action.setBadgeTextColor({ tabId: id, color: value.textColor }),
      chrome.action.setTitle({ tabId: id, title: value.title })
    ]);
  }));
}
var pendingView = null;
var badgeFlight = null;
async function flushBadges() {
  try {
    while (pendingView) {
      const view = pendingView;
      pendingView = null;
      await renderBadges(view);
    }
  } finally {
    badgeFlight = null;
  }
}
function updateBadge(view) {
  pendingView = view;
  badgeFlight ??= flushBadges();
  return badgeFlight;
}

// src/background/content-registration.ts
init_types();
async function reconcileContent(view) {
  const existing = await chrome.scripting.getRegisteredContentScripts();
  const currentIds = new Set(SITE_GROUPS.map((site) => `ai-gauge-${site.id}`));
  const observerId = "ai-gauge-chatgpt-observer";
  const retired = existing.filter((s) => s.id.startsWith("ai-gauge-") && !currentIds.has(s.id)).map((s) => s.id);
  if (retired.length) await chrome.scripting.unregisterContentScripts({ ids: retired });
  const observing = existing.some((s) => s.id === observerId);
  if (view.permissions.chatgpt && observing) {
    const tabs = await chrome.tabs.query({ url: "https://chatgpt.com/*" });
    await Promise.all(tabs.filter((t) => typeof t.id === "number" && !t.discarded && !t.frozen).map((t) => chrome.scripting.executeScript({ target: { tabId: t.id }, world: "MAIN", func: () => {
      document.dispatchEvent(new Event("ai-gauge-chatgpt-stop"));
    } }).catch(() => void 0)));
  }
  for (const site of SITE_GROUPS) {
    const id = `ai-gauge-${site.id}`, present = existing.some((s) => s.id === id);
    const enabled = needsContent(view, site.providers);
    if (!enabled && present) await chrome.scripting.unregisterContentScripts({ ids: [id] });
    if (enabled && !present) await chrome.scripting.registerContentScripts([{ id, matches: [site.origin], js: ["content.js"], runAt: "document_start", persistAcrossSessions: true }]);
    if (enabled && present && existing.find((s) => s.id === id)?.runAt === "document_idle") await chrome.scripting.updateContentScripts([{ id, js: ["content.js"], runAt: "document_start" }]);
    if (enabled) {
      const tabs = await chrome.tabs.query({ url: site.origin });
      await Promise.all(tabs.filter((t) => typeof t.id === "number" && !t.discarded && !t.frozen).map((t) => chrome.scripting.executeScript({ target: { tabId: t.id }, files: ["content.js"] }).catch(() => void 0)));
    }
  }
}

// src/background/index.ts
var scheduler = new Scheduler({ read: readSnapshot, write: writeSnapshot, collect, now: Date.now, enabled: async (p) => (await readSettings()).enabled[p] && await chrome.permissions.contains({ origins: [ORIGINS[p]] }) });
var ALARM = "ai-gauge-refresh";
var setupFlight = null;
var setupDirty = false;
function reconcile() {
  setupDirty = true;
  if (setupFlight) return setupFlight;
  setupFlight = (async () => {
    while (setupDirty) {
      setupDirty = false;
      await reconcileContent(await readView());
    }
  })().finally(() => {
    setupFlight = null;
  });
  return setupFlight;
}
async function publish() {
  const view = await readView();
  await updateBadge(view);
  await Promise.all(SITE_GROUPS.map(async (site) => {
    if (!site.providers.some((p) => view.permissions[displayProvider(p)])) return;
    const tabs = await chrome.tabs.query({ url: site.origin });
    await Promise.all(tabs.filter((t) => typeof t.id === "number" && !t.discarded).map((t) => chrome.tabs.sendMessage(t.id, { type: "invalidate" }).catch(() => void 0)));
  }));
  return view;
}
async function refresh(p, trigger) {
  await scheduler.refresh(p, trigger);
}
async function refreshAll(trigger) {
  await Promise.all(PROVIDERS.map((p) => refresh(p, trigger)));
  await publish();
}
var settingsWrites = Promise.resolve();
function queueSettingsWrite(write) {
  const task = settingsWrites.then(write);
  settingsWrites = task.catch(() => void 0);
  return task;
}
function changeSettings(change) {
  return queueSettingsWrite(async () => {
    const settings = await readSettings();
    await change(settings);
    await writeSettings(parseSettings(settings));
  });
}
async function enableProvider(provider) {
  let granted = false;
  await changeSettings(async (settings) => {
    granted = await chrome.permissions.contains({ origins: [ORIGINS[provider]] });
    if (granted) settings.enabled[provider] = true;
  });
  if (!granted) return;
  await reconcile();
  await refresh(provider, "manual");
}
async function initialize() {
  if (!await chrome.alarms.get(ALARM)) await chrome.alarms.create(ALARM, { periodInMinutes: 10 });
  await queueSettingsWrite(async () => {
    await migrateStorage();
  });
  await reconcile();
  await publish();
}
chrome.runtime.onMessage.addListener((input, sender, sendResponse) => {
  const message = parseMessage(input);
  if (!message || !authorized(message, sender, chrome.runtime.id)) {
    sendResponse({ ok: false });
    return false;
  }
  void (async () => {
    if (sender.tab) {
      const p = providerFromUrl(sender.url);
      if (!await chrome.permissions.contains({ origins: [ORIGINS[displayProvider(p)]] })) return { ok: false };
    }
    if (message.type === "settings" || message.type === "strips" || message.type === "disable") {
      await changeSettings((settings) => {
        if (message.type === "strips") settings.strips = { ...message.strips };
        else if (message.type === "disable") settings.enabled[message.provider] = false;
        else Object.assign(settings, parseSettings(message.settings));
      });
      await reconcile();
    }
    if (message.type === "enable") await enableProvider(message.provider);
    if (message.type === "refresh") await refresh(message.provider, message.trigger);
    if (message.type === "view" && !sender.tab) void refreshAll("event").catch(() => void 0);
    const view = message.type === "view" ? await readView() : await publish();
    return { ok: true, view };
  })().then(sendResponse).catch(() => sendResponse({ ok: false }));
  return true;
});
chrome.alarms.onAlarm.addListener((a) => {
  if (a.name === ALARM) void refreshAll("periodic").catch(() => void 0);
});
chrome.runtime.onInstalled.addListener(() => {
  void initialize().catch(() => void 0);
});
chrome.runtime.onStartup.addListener(() => {
  void initialize().catch(() => void 0);
});
chrome.tabs.onActivated.addListener(({ tabId }) => {
  void chrome.tabs.get(tabId).then(async (tab) => {
    const p = providerFromUrl(tab.url);
    if (p) await refresh(displayProvider(p), "tab");
    await publish();
  }).catch(() => void 0);
});
chrome.tabs.onUpdated.addListener((_tabId, change, tab) => {
  if (change.status === "complete" || change.url) void (async () => {
    const p = providerFromUrl(tab.url);
    if (p && tab.active) await refresh(displayProvider(p), "tab");
    await publish();
  })().catch(() => void 0);
});
chrome.windows.onFocusChanged.addListener(() => {
  void updateBadgeFromFocus().catch(() => void 0);
});
async function updateBadgeFromFocus() {
  const tabs = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
  const p = providerFromUrl(tabs[0]?.url);
  if (p) await refresh(displayProvider(p), "tab");
  await publish();
}
chrome.permissions.onAdded.addListener((added) => {
  const providers = PROVIDERS.filter((provider) => added.origins?.includes(ORIGINS[provider]));
  void (async () => {
    await Promise.all(providers.map(enableProvider));
    await reconcile();
    await publish();
  })().catch(() => void 0);
});
chrome.permissions.onRemoved.addListener((removed) => {
  const origins = (removed?.origins ?? []).filter((origin) => SITE_GROUPS.some((site) => site.origin === origin));
  void chrome.tabs.query({}).then((tabs) => Promise.all(tabs.filter((t) => typeof t.id === "number").map((t) => chrome.tabs.sendMessage(t.id, { type: "permissions-revoked", origins }).catch(() => void 0)))).catch(() => void 0);
  void reconcile().then(publish).catch(() => void 0);
});
void initialize().catch(() => void 0);
